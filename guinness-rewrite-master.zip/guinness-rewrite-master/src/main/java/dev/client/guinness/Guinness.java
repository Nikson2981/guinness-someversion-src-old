package dev.client.guinness;

import dev.client.guinness.util.client.SoundUtil;
import net.minecraftforge.client.IClientCommand;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;

import dev.client.guinness.commands.*;
import dev.client.guinness.event.ForgeEvent;
import dev.client.guinness.gui.main.Window;
import dev.client.guinness.gui.theme.Theme;
import dev.client.guinness.util.client.GuinnessFont;
import dev.client.guinness.util.config.FileUtil;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

import java.util.Arrays;
import java.util.List;

/**
 * @author bon
 * @since 11/12/20
 */

@Mod(modid = Guinness.MODID, name = Guinness.NAME, version = Guinness.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class Guinness {

    public static final String MODID = "guinness";
    public static final String NAME = "Guinness";
    public static String SPOOFNAME = "Guinness";
    public static final String VERSION = "0.3";
    public static final Logger LOGGER;

    public static GuinnessFont smallFont;
    public static GuinnessFont customFont;
    public static GuinnessFont largeFont;
    public static GuinnessFont largeLargeFont;
    public static GuinnessFont blu3Font;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        Display.setTitle("Guinness v" + Guinness.VERSION);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        this.register();
        SoundUtil.registerSounds();
        LOGGER.info("Mod Initialized!");
        Window.initGui();
        LOGGER.info("ClickGui Initialized!");
        Theme.initThemes();
        LOGGER.info("Gui Themes Initialized!");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.info("Saving everything...");
            FileUtil.saveAll();
            LOGGER.info("Files Saved!");
        }));

        LOGGER.info("Shutdown Hook Initialized!");
    }

    @Mod.EventHandler
    public void postInit(FMLPostInitializationEvent event) {
        this.registerCommands();
        LOGGER.info("Commands Initialized!");
        FileUtil.createDirectory();
        FileUtil.loadAll();
        LOGGER.info("Files Initialized!");
    }

    public void register() {
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(new ForgeEvent());
    }

    public void registerCommands() {
        ClientCommandHandler.instance.registerCommand(new AutoKit());
        ClientCommandHandler.instance.registerCommand(new Bind());
        ClientCommandHandler.instance.registerCommand(new ClientSpoof());
        ClientCommandHandler.instance.registerCommand(new Friend());
        ClientCommandHandler.instance.registerCommand(new Suffix());
        ClientCommandHandler.instance.registerCommand(new Toggle());
    }

    static {
        LOGGER = LogManager.getLogger("Guinness");

        smallFont = new GuinnessFont("Futura", 18.0f);
        customFont = new GuinnessFont("Futura", 20.0f);
        largeFont = new GuinnessFont("Futura", 22.0f);
        largeLargeFont = new GuinnessFont("Futura", 56.0f);
        blu3Font = new GuinnessFont("DilleniaUPC", 35);
    }
}
