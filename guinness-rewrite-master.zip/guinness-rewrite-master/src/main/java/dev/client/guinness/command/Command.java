package dev.client.guinness.command;

import dev.client.guinness.util.Wrapper;

/**
 * @author blu3
 * @since 2021-02-07
 */

public class Command implements Wrapper {

    private final String name;

    public Command(String name) {
        this.name = name;
    }

    public void execute(String[] args) {

    }

    public String getName() {
        return name;
    }
}
