package dev.client.guinness.command;

import dev.client.guinness.command.commands.AutoKitCmd;

import java.util.Arrays;
import java.util.List;

/**
 * @author blu3
 * @since 2021-02-07
 */

public class CommandManager {

    private static final List<Command> commands = Arrays.asList(
            new AutoKitCmd()
    );

    public static Command getCommandByName(String name) {
        for (Command cmd : commands) {
            if (cmd.getName().equalsIgnoreCase("name")) return cmd;
        }
        throw new NullPointerException("Command does not exist");
    }
}
