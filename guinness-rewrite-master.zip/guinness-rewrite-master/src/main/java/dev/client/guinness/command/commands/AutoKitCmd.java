package dev.client.guinness.command.commands;

import dev.client.guinness.command.Command;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.config.FileUtil;

public class AutoKitCmd extends Command {
    public AutoKitCmd() {
        super("AutoKit");
    }

    public void execute(String[] args) {
        if(args.length == 0) MessageUtil.sendClientMessage("Usage: autokit [save/load]");
        if(args.length == 1) {
            if(args[0].equalsIgnoreCase("save")) {
                FileUtil.saveKit();
                MessageUtil.sendClientMessage("Saved your current kit!");
            } else if(args[0].equalsIgnoreCase("load")) {
                FileUtil.loadKit();
                MessageUtil.sendClientMessage("Loaded your kit!");
            }
        }
    }
}
