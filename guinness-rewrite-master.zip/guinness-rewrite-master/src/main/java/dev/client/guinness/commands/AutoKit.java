package dev.client.guinness.commands;

import dev.client.guinness.module.modules.misc.ChatSuffix;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.config.FileUtil;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.client.IClientCommand;

public class AutoKit extends CommandBase implements IClientCommand {
	
	@Override
	public String getName() {
		return "autokit";
	}
	
	@Override
	public String getUsage(ICommandSender sender) {
		return null;
	}
	
	@Override
	public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
		if(args.length == 0) MessageUtil.sendClientMessage("Usage: /autokit [save/load]");
		if(args.length == 1) {
			if(args[0].equalsIgnoreCase("save")) {
				FileUtil.saveKit();
				MessageUtil.sendClientMessage("Saved your current kit!");
			} else if(args[0].equalsIgnoreCase("load")) {
				FileUtil.loadKit();
				MessageUtil.sendClientMessage("Loaded your kit!");
			}
		}
	}
	
	@Override
	public boolean allowUsageWithoutPrefix(ICommandSender sender, String message) {
		return false;
	}
	
	@Override
	public boolean checkPermission(MinecraftServer server, ICommandSender sender){
        return true;
    }
}