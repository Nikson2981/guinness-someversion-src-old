package dev.client.guinness.commands;

import org.lwjgl.input.Keyboard;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.config.FileUtil;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.client.IClientCommand;

public class Bind extends CommandBase implements IClientCommand {

	@Override
	public String getName() {
		return "bind";
	}

	@Override
	public String getUsage(ICommandSender sender) {
		return null;
	}

	@Override
	public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
		if(args.length == 0 || args.length > 2) MessageUtil.sendClientMessage("Usage: /bind [module] [key] or /bind [module] none");
		if(args.length == 1) {
			ClientModule m = ModuleManager.getModuleByName(args[0]);
			if(m == null) {
				MessageUtil.sendClientMessage("A module by the name of " + args[0] + " does not exist.");
				return;
			} else {
				MessageUtil.sendClientMessage(m.getName() + " is currently bound to " + m.getKeybind().getDisplayName());
			}
		}
		
		if(args.length == 2) {
			ClientModule m = ModuleManager.getModuleByName(args[0]);
			if(m == null) {
				MessageUtil.sendClientMessage("A module by the name of " + args[0] + " does not exist.");
				return;
			} else {
				if(args[1].equalsIgnoreCase("none")) {
					m.getKeybind().setKeyCode(Keyboard.KEY_NONE);
					FileUtil.saveBinds();
					MessageUtil.sendClientMessage("Successfully unbound " + m.getName());
					return;
				}
				m.getKeybind().setKeyCode(Keyboard.getKeyIndex(args[1].toUpperCase()));
				MessageUtil.sendClientMessage("Successfuly bound " + m.getName() + " to " + args[1].toUpperCase());
				FileUtil.saveBinds();
			}
		}
	}

	@Override
	public boolean allowUsageWithoutPrefix(ICommandSender sender, String message) {
		return false;
	}
	
	@Override
	public boolean checkPermission(MinecraftServer server, ICommandSender sender){
        return true;
    }

}
