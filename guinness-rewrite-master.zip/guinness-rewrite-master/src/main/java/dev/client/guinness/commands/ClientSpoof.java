package dev.client.guinness.commands;

import dev.client.guinness.Guinness;
import dev.client.guinness.gui.theme.themes.GuinnessTheme;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.client.IClientCommand;

public class ClientSpoof extends CommandBase implements IClientCommand {
	
	@Override
	public String getName() {
		return "clientspoof";
	}
	
	@Override
	public String getUsage(ICommandSender sender) {
		return null;
	}
	
	@Override
	public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
		if(args.length == 0) MessageUtil.sendClientMessage("Usage: /clientspoof [client name]");
		if(args.length == 1) Guinness.SPOOFNAME = args[0];
	}
	
	@Override
	public boolean allowUsageWithoutPrefix(ICommandSender sender, String message) {
		return false;
	}
	
	@Override
	public boolean checkPermission(MinecraftServer server, ICommandSender sender){
        return true;
    }
}
