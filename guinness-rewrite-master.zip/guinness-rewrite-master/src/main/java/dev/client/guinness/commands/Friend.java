package dev.client.guinness.commands;

import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.config.FileUtil;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.client.IClientCommand;

/**
 * @author bon
 * @since 12/05/20
 */

public class Friend extends CommandBase implements IClientCommand {
	
	@Override
	public String getName() {
		return "friend";
	}
	
	@Override
	public String getUsage(ICommandSender sender) {
		return null;
	}
	
	@Override
	public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
		if(args.length == 0 || args.length > 2) MessageUtil.sendClientMessage("Usage: /friend add [name] or /friend del [name]");
		if(args.length == 1) {
			if(FriendUtil.isFriend(args[0])) {
				MessageUtil.sendClientMessage(args[0] + " is a friend.");
			} else {
				MessageUtil.sendClientMessage(args[0] + " is not a friend.");
			}
		}
		
		//Add friend
		if(args.length == 2 && args[0].equalsIgnoreCase("add")) {
			if(!FriendUtil.isFriend(args[1])) {
				FriendUtil.addFriend(args[1]);
				FileUtil.saveFriends();
				MessageUtil.sendClientMessage("Successfully added " + args[1] + " as a friend.");
			} else if (FriendUtil.isFriend(args[1])){
				MessageUtil.sendClientMessage(args[1] + " is already a friend.");
			}
		}
		
		//Delete friend
		if(args.length == 2 && args[0].equalsIgnoreCase("del")) {
			if(FriendUtil.isFriend(args[1])) {
				FriendUtil.delFriend(args[1]);
				FileUtil.saveFriends();
				MessageUtil.sendClientMessage("Successfully removed " + args[1] + " from the friends list.");
			} else if (!FriendUtil.isFriend(args[1])){
				MessageUtil.sendClientMessage(args[1] + " is not a friend.");
			}
		}
		
	}

	@Override
	public boolean allowUsageWithoutPrefix(ICommandSender sender, String message) {
		return false;
	}
	
	@Override
	public boolean checkPermission(MinecraftServer server, ICommandSender sender){
        return true;
    }

}
