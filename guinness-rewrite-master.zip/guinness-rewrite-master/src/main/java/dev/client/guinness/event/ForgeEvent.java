package dev.client.guinness.event;

import org.lwjgl.input.Keyboard;

import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.util.Wrapper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ForgeEvent implements Wrapper {
	
	@SubscribeEvent
	public void onTick(TickEvent.ClientTickEvent event) {
		FinalColor.updateColors();
		ModuleManager.getModules().stream()
		.filter(m -> m.isEnabled())
		.forEach(m -> {
			try { m.onUpdate(); }
			catch (Exception e) { e.printStackTrace(); }
		});
	}
	
	@SubscribeEvent
	public void onFastTick(TickEvent event) {
		ModuleManager.getModules().stream()
		.filter(m -> m.isEnabled())
		.forEach(m -> {
			try { m.onFastUpdate(); }
			catch (Exception e) { e.printStackTrace(); }
		});
	}
	
	@SubscribeEvent
	public void onKeyInput(InputEvent.KeyInputEvent event) {
		if(mc.currentScreen == null) {
			ModuleManager.getModules().stream()
			.forEach(m -> {
				try {
					if(Keyboard.isKeyDown(m.getKeybind().getKeyCode()) && !Keyboard.isKeyDown(Keyboard.KEY_NONE) && !m.isKeyDown()) {
						m.setKeyDown(true);
						m.toggle();
					} else if(!Keyboard.isKeyDown(m.getKeybind().getKeyCode()) && m.isKeyDown()) {
						m.setKeyDown(false);
					}
				} catch (Exception e) {}
			});
		}
	}

}
