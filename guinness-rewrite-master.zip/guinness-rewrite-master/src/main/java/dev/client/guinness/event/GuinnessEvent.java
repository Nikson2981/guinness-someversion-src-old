package dev.client.guinness.event;

import net.minecraftforge.fml.common.eventhandler.Event;

public class GuinnessEvent extends Event {
	
	private Stage s;
	
	public GuinnessEvent() {
		
	}
	
	public GuinnessEvent(Stage s) {
		this.s = s;
	}
	
	public Stage getStage() {
		return this.s;
	}
	
	public enum Stage {
		PRE,
		POST
	}
	
}
