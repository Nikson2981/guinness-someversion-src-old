package dev.client.guinness.event.events;

import dev.client.guinness.event.GuinnessEvent;
import net.minecraft.client.gui.GuiScreen;

public class GuiScreenEvent extends GuinnessEvent {
	
	private GuiScreen screen;
	
	public GuiScreenEvent(GuiScreen screen) {
		this.screen = screen;
	}
	
	public GuiScreen getScreen() {
		return this.screen;
	}

}
