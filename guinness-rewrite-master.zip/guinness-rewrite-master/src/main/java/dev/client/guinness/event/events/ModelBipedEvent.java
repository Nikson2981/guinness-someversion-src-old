package dev.client.guinness.event.events;


import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Event;

public class ModelBipedEvent extends Event {

    public float headYaw, headPitch;
    private final Entity entity;

    public ModelBipedEvent(float headYaw, float headPitch, Entity entity) {
        this.headYaw = headYaw;
        this.headPitch = headPitch;
        this.entity = entity;
    }

    public Entity getEntity() {
        return entity;
    }

    public float getPitch() {
        return headPitch;
    }

    public float getYaw() {
        return headYaw;
    }
}
