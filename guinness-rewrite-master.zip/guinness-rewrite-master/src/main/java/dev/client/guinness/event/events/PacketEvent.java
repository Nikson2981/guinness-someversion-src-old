package dev.client.guinness.event.events;

import dev.client.guinness.event.GuinnessEvent;
import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

public class PacketEvent extends GuinnessEvent {

	private final Packet<?> packet;
	
	public PacketEvent(final Packet<?> packet, final Stage stage) {
		super(stage);
		this.packet = packet;
	}
	
	public Packet<?> getPacket(){
		return this.packet;
	}
	
	@Cancelable
	public static class PacketReceiveEvent extends PacketEvent {

		public PacketReceiveEvent(final Packet<?> packet, final Stage stage) {
			super(packet, stage);
		}
		
	}
	
	@Cancelable
	public static class PacketSendEvent extends PacketEvent {
		
		public PacketSendEvent(final Packet<?> packet, final Stage stage) {
			super(packet, stage);
		}
		
	}
	
}
