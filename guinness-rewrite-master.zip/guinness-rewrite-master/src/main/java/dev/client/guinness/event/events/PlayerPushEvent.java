package dev.client.guinness.event.events;

import dev.client.guinness.event.GuinnessEvent;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class PlayerPushEvent extends GuinnessEvent {
	
	public Entity e;
	
	public PlayerPushEvent(Entity e) {
		super();
		this.e = e;
	}

}
