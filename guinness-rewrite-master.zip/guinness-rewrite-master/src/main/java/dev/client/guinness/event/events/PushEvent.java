package dev.client.guinness.event.events;

import dev.client.guinness.event.GuinnessEvent;
import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class PushEvent extends GuinnessEvent {

	public Entity e;
	
	public double X, Y, Z;

	public PushEvent(double x, double y, double z) {
		super();
    
		X = x;
		Y = y;
    	Z = z;
	}
	
}
