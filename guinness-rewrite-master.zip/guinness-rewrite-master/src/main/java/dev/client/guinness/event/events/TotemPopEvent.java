package dev.client.guinness.event.events;

import dev.client.guinness.event.GuinnessEvent;
import net.minecraft.entity.player.EntityPlayer;

public class TotemPopEvent extends GuinnessEvent {
	
	private EntityPlayer player;
	
	public TotemPopEvent(EntityPlayer player) {
		this.player = player;
	}
	
	public EntityPlayer getPlayer() {
		return this.player;
	}

}
