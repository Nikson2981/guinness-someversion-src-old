package dev.client.guinness.event.events;

import dev.client.guinness.event.GuinnessEvent;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class WaterPushEvent extends GuinnessEvent {
	
	public WaterPushEvent() {
		super();
	}

}
