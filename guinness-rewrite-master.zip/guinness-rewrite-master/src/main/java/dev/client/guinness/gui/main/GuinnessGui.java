package dev.client.guinness.gui.main;

import java.io.IOException;

import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.client.ClickGui;
import dev.client.guinness.util.client.GuiUtil;
import dev.client.guinness.util.config.FileUtil;
import net.minecraft.client.gui.GuiScreen;

/**
 * @author bon
 * @since 11/16/20
 */

public class GuinnessGui extends GuiScreen {
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		super.drawScreen(mouseX, mouseY, partialTicks);
		for(Window w : Window.windows) {
			w.drawGui(mouseX, mouseY);
		}
		GuiUtil.updateMousePos(mouseX, mouseY);
	}
	
	@Override
	public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		super.mouseClicked(mouseX, mouseY, mouseButton);
		if(mouseButton == 0) {
			for(Window w : Window.windows) {
				w.updateLeftClick();
			}
			GuiUtil.updateLeftClick();
		}
		if(mouseButton == 1) {
			GuiUtil.updateRightClick();
		}
	}
	
	@Override
	public void mouseReleased(int mouseX, int mouseY, int state) {
		super.mouseReleased(mouseX, mouseY, state);
		if(state == 0) {
			for(Window w : Window.windows) {
				w.updateMouseState();
			}
			GuiUtil.updateMouseState();
		}
	}
	
	@Override
	public void keyTyped(char typedChar, int keyCode) throws IOException {
		super.keyTyped(typedChar, keyCode);
		GuiUtil.updateKeyState(keyCode);
	}
	
	@Override
	public void onGuiClosed() {
		super.onGuiClosed();
		ModuleManager.getModuleByClass(ClickGui.class).disable();
		if(mc.entityRenderer.isShaderActive()) {
			mc.entityRenderer.shaderGroup.deleteShaderGroup();
		}
		FileUtil.saveAll();
	}
	
	@Override
	public boolean doesGuiPauseGame() {
		return false;
	}
}
