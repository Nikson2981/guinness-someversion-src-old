package dev.client.guinness.gui.main;

import java.util.ArrayList;
import java.util.List;

import dev.client.guinness.gui.theme.Theme;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.ClientModule.ModuleCategory;
import dev.client.guinness.module.modules.client.ClickGui;
import dev.client.guinness.util.Wrapper;
import dev.client.guinness.util.client.GuiUtil;

/**
 * @author bon
 * @since 11/16/20
 */

public class Window implements Wrapper {
	
	public int x;
	public int y;
	
	private int lastMouseX;
	private int lastMouseY;
	private String name;
	private boolean dragging;
	private List<ClientModule> modules;
	public static final List<Window> windows = new ArrayList<>();
	
	/**
	 * @param name The title of the module tabs
	 * @param x The (top right) original x position
	 * @param y The (top right) original y position
	 * @param category The category the window represents
	 * 
	 * Maybe at some point add an x and a y modifier to themes so they aren't stuck at
	 * a final value.
	 */
	public Window(String name, int x, int y, ModuleCategory category) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.modules = ModuleManager.getModulesInCategory(category);
	}
	
	public static void initGui() {
		windows.add(new Window(ModuleCategory.CLIENT.getName(), 12, 42, ModuleCategory.CLIENT));
		windows.add(new Window(ModuleCategory.COMBAT.getName(), 122, 42, ModuleCategory.COMBAT));
		windows.add(new Window(ModuleCategory.EXPLOIT.getName(), 232, 42, ModuleCategory.EXPLOIT));
		windows.add(new Window(ModuleCategory.MISC.getName(), 342, 42, ModuleCategory.MISC));
		windows.add(new Window(ModuleCategory.MOVEMENT.getName(), 452, 42, ModuleCategory.MOVEMENT));
		windows.add(new Window(ModuleCategory.RENDER.getName(), 562, 42, ModuleCategory.RENDER));
		windows.add(new Window(ModuleCategory.DISPENSERPVP.getName(), 672, 42, ModuleCategory.DISPENSERPVP));
	}
	
	public String getName() {
		return this.name;
	}
	
	public void drawGui(int mouseX, int mouseY) {
		updateMousePos();
		String currentTheme = ClickGui.theme.getValue();
		Theme current = Theme.getThemeByName(currentTheme);
		current.drawTitles(name, x, y);
		current.drawModules(modules, x, y);
	}
	
	private void updateMousePos() {
		if(dragging) {
			x = GuiUtil.mX - (lastMouseX - x);
			y = GuiUtil.mY - (lastMouseY - y);
		}
		lastMouseX = GuiUtil.mX;
		lastMouseY = GuiUtil.mY;
	}
	
	public void updateLeftClick() {
		String currentTheme = ClickGui.theme.getValue();
		Theme current = Theme.getThemeByName(currentTheme);
		if(GuiUtil.mouseOver(x, y, x + current.getThemeWidth(), y + current.getThemeHeight())) {
			dragging = true;
		}
	}
	
	public void updateMouseState() {
		dragging = false;
	}
	
}
