package dev.client.guinness.gui.theme;

import dev.client.guinness.module.modules.client.ClickGui;
import dev.client.guinness.util.client.ColorUtil;

public final class FinalColor {

	public static int COLOR;
	public static boolean GRADIENT;
	public static boolean RAINBOWONLY;
	
	public static void updateColors() {
		if(ClickGui.rainbow.getValue() && ClickGui.gradient.getValue())
		{
			GRADIENT = true;
			RAINBOWONLY = true;
		} 
		else if(ClickGui.rainbow.getValue() && !ClickGui.gradient.getValue())
		{
			GRADIENT = false;
			RAINBOWONLY = true;
		} 
		else if((!ClickGui.rainbow.getValue() && !ClickGui.gradient.getValue()) || !ClickGui.rainbow.getValue() && ClickGui.gradient.getValue())
		{
			GRADIENT = false;
			RAINBOWONLY = false;
		}
	}
	
	public static int BESTCOLOR(int alpha, int boost) {
		return FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(boost, alpha) : ColorUtil.rainbow(1, alpha)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), alpha));
	}
	
}
