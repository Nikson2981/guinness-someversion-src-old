package dev.client.guinness.gui.theme;

import java.util.ArrayList;
import java.util.List;

import dev.client.guinness.gui.theme.themes.*;
import dev.client.guinness.module.ClientModule;

/**
 * @author bon
 * @since 11/18/20
 */

public abstract class Theme {
	
	private String name;
	private int width;
	private int height;
	public static final List<Theme> themes = new ArrayList<>();
	
	public Theme(String name, int width, int height) {
		this.name = name;
		this.width = width;
		this.height = height;
	}
	
	/**
	 * The theme must have these 2 methods
	 */
	public abstract void drawTitles(String name, int left, int top);
	public abstract void drawModules(List<ClientModule> modules, int left, int top);
	
	/**
	 * Make sure to add any new themes you create in this arraylist.
	 */
	public static void initThemes() {
		themes.add(new GuinnessTheme());
		themes.add(new GuinnessCleanTheme());
		themes.add(new GuinnessThinTheme());
		themes.add(new CliffbaseTheme());
	}
	
	public void addTheme(Theme theme) { Theme.themes.add(theme); }
	
	public String getThemeName() { 
		return this.name; 
	}
	
	public int getThemeWidth() { 
		return this.width; 
	}
	
	public int getThemeHeight() { 
		return this.height; 
	}
	
	public static Theme getThemeByName(String name) {
		return themes.stream().filter(theme -> theme.getThemeName().equalsIgnoreCase(name)).findFirst().orElse(null);
	}

}
