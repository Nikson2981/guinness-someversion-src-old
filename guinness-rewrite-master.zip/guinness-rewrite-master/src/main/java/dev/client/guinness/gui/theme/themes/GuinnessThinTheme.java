package dev.client.guinness.gui.theme.themes;

import java.util.List;

import org.lwjgl.input.Keyboard;

import dev.client.guinness.Guinness;
import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.gui.theme.Theme;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.modules.client.ClickGui;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SDouble;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.setting.settings.Setting;
import dev.client.guinness.setting.subsettings.SubBoolean;
import dev.client.guinness.setting.subsettings.SubDouble;
import dev.client.guinness.setting.subsettings.SubInteger;
import dev.client.guinness.setting.subsettings.SubMode;
import dev.client.guinness.setting.subsettings.SubSetting;
import dev.client.guinness.util.Wrapper;
import dev.client.guinness.util.client.ColorUtil;
import dev.client.guinness.util.client.GuiUtil;
import dev.client.guinness.util.client.GuinnessFont;
import dev.client.guinness.util.client.MathUtil;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.init.SoundEvents;

public class GuinnessThinTheme extends Theme implements Wrapper {
	private static int boost = 0;
	
	public static final String name = "GuinnessThin";
	public static final int width = 90;
	public static final int height = 12;
	private static GuinnessFont font = Guinness.customFont;
	
	public GuinnessThinTheme() {
		super(name, width, height);
	}
	
	public static int BESTCOLOR(int alpha) {
		return FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(boost, alpha) : ColorUtil.rainbow(1, alpha)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), alpha));
	}
	
	@Override
	public void drawTitles(String name, int x, int y) {
		//Sides
		GuiScreen.drawRect(x - 1, y, x, y + height, FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(1, 255) : ColorUtil.rainbow(1, 255)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), 255)));
		GuiScreen.drawRect(x + width, y, x + width + 1, y + height, FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(1, 255) : ColorUtil.rainbow(1, 255)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), 255)));
		//Top & Bottom
		GuiScreen.drawRect(x, y, x + width, y + 1, FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(1, 255) : ColorUtil.rainbow(1, 255)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), 255)));
		GuiScreen.drawRect(x, y + height - 1, x + width, y + height, FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(1, 255) : ColorUtil.rainbow(1, 255)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), 255)));
		//Main
		GuiScreen.drawRect(x, y + 1, x + width, y + height - 1, FinalColor.RAINBOWONLY ? ( FinalColor.GRADIENT ? ColorUtil.rainbow(1, 195) : ColorUtil.rainbow(1, 195)) : (ColorUtil.toRGBA(ClickGui.r.getValue().intValue(), ClickGui.g.getValue().intValue(), ClickGui.b.getValue().intValue(), 195)));
		Guinness.largeFont.drawStringWithShadow(name, (x + ((x + width) - x) / 2 - Guinness.largeFont.getStringWidth(name) / 2), y + 1, -1);
		
		GuiScreen.drawRect(0, 0, 4096, 32, 0x22202020);
		GuiScreen.drawRect(0, 0, 4096, 1, FinalColor.BESTCOLOR(255, 0));
        Guinness.largeLargeFont.drawStringWithShadow(Guinness.SPOOFNAME + " v" + Guinness.VERSION, 1, 3, -1);
	}

	@Override
	public void drawModules(List<ClientModule> modules, int x, int y) {
		boost = 0;
		for(ClientModule m : modules) {
			int color = 0xFF212121;
			if(m.isEnabled()) { color = 0xFFE30C0C; }
			if(GuiUtil.mouseOver(x, y + height + (boost * height) + 1, (x + width), y + height*2 + (boost * height))) {
				if(GuiUtil.ldown) {
					if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
					m.toggle(); 
				}
				if(GuiUtil.rdown) {
					if(ClickGui.click.getValue())
						mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
					m.setOpen(!m.isOpened()); 
				}
			}
			//Sides
			GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height) + 2, BESTCOLOR(255));
			GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height) + 2, BESTCOLOR(255));
			//Main
			GuiScreen.drawRect(x + 1, y + height + (boost * height) + 1, (x + width) - 1, y + height*2 + (boost * height), m.isEnabled() ? BESTCOLOR(190) : 0x76000000);
			//Top & Bottom
			font.drawStringWithShadow(m.getName(), x + 2, y + height + 1 + (boost * height) + 1, -1);
			if(m.isOpened()) {
				if(m.hasSettings()) drawDropdown(m, x, y + 1);
				boost++;
				renderKeybind(m, GuiUtil.keydown, x, y + 1);
			}
			boost++;
		}
		GuiScreen.drawRect(x - 1, y + height + (boost * height) + 1, x + width + 1, y + height + (boost * height) + 2, BESTCOLOR(255));
	}
	
	public static void drawDropdown(ClientModule m, int x, int y) {
		for(Setting<?> s : m.getSettings()) {
			boost++;
			if(s instanceof SBoolean) {
				SBoolean b = (SBoolean) s;
				renderBoolean(b, x, y);
			}
			if(s instanceof SInteger) {
				SInteger si = (SInteger) s;
				renderInteger(si, x, y);
			}
			if(s instanceof SDouble) {
				SDouble sd = (SDouble) s;
				renderDouble(sd, x, y);
			}
			if(s instanceof SMode) {
				SMode sm = (SMode) s;
				renderMode(sm, x, y);
			}
			if(s.isOpened()) {
				for(SubSetting<?> ss : s.getSubSettings()) {
					boost++;
					if(ss instanceof SubBoolean) {
						SubBoolean sb = (SubBoolean) ss;
						renderSubBoolean(sb, x, y);
					}
					if(ss instanceof SubMode) {
						SubMode sm = (SubMode) ss;
						renderSubMode(sm, x, y);
					}
					if(ss instanceof SubInteger) {
						SubInteger si = (SubInteger) ss;
						renderSubInteger(si, x, y);
					}
					if(ss instanceof SubDouble) {
						SubDouble sd = (SubDouble) ss;
						renderSubDouble(sd, x, y);
					}
				}
			}
		}
	}

	private static void renderBoolean(Setting<Boolean> s, int x, int y) {
		if(GuiUtil.mouseOver(x, y + height + (boost * height), (x + width), (y + height) + height - 1 + (boost * height))) {	
			if(GuiUtil.ldown) { 
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				s.setValue(!s.getValue());
			}
			if(GuiUtil.rdown) { 
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				s.setOpened(!s.isOpened()); 
			}
		}
		//Sides
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		//Main
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, y + height*2 + (boost * height) - 1, 0x76000000);
		//Box
		GuiScreen.drawRect(x + 4, y + height + (boost * height) + 2, x + 11, y + height + (boost * height) + 9, 0xFF000000);
		GuiScreen.drawRect(x + 5, y + height + (boost * height) + 3, x + 10, y + height + (boost * height) + 8, s.getValue() ? BESTCOLOR(190) : 0xFF000000);
		Guinness.smallFont.drawStringWithShadow(s.getName(), x + 14, (y + height) + 2 + (boost * height), -1);
	}
	
	private static void renderSubBoolean(SubBoolean ss, int x, int y) {
		if(GuiUtil.mouseOver(x, y + height + (boost * height), (x + width), (y + height) + height - 1 + (boost * height))) {	
			if(GuiUtil.ldown) { 
				if(ClickGui.click.getValue())
				mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				ss.setValue(!ss.getValue()); 
			}
		}
		//Sides
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		//Main
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		//Box
		GuiScreen.drawRect(x + 8, y + height + (boost * height) + 2, x + 15, y + height + (boost * height) + 9, 0xFF000000);
		GuiScreen.drawRect(x + 9, y + height + (boost * height) + 3, x + 14, y + height + (boost * height) + 8, ss.getValue() ? BESTCOLOR(190) : 0xFF000000);
		Guinness.smallFont.drawStringWithShadow(ss.getName(), x + 20, (y + height) + 2 + (boost * height), -1);
	}
	
	private static void renderMode(SMode s, int x, int y) {
		if(GuiUtil.mouseOver(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) { 
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				s.setMode(s.getNextMode());
			}
			if(GuiUtil.rdown) { s.setOpened(s.isOpened()); }
		}
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		Guinness.smallFont.drawStringWithShadow(s.getName(), x + 3, (y + height) + 2 + (boost * height), -1);
		Guinness.smallFont.drawStringWithShadow(s.getValue(), x + width - Guinness.smallFont.getStringWidth(s.getValue()) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
	}
	
	private static void renderSubMode(SubMode ss, int x, int y) {
		if(GuiUtil.mouseOver(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) {
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				ss.setMode(ss.getNextMode());
			}
		}
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		Guinness.smallFont.drawStringWithShadow(ss.getName(), x + 20, (y + height) + 2 + (boost * height), -1);
		Guinness.smallFont.drawStringWithShadow(ss.getValue(), x + width - Guinness.smallFont.getStringWidth(ss.getValue()) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
	}
	
	private static void renderInteger(SInteger s, int x, int y) {
		int pixAdd = (int) (((x + width) - x) * (s.getValue() - s.getMinValue()) / (s.getMaxValue() - s.getMinValue()));
		if(GuiUtil.mouseOver(x + 1, y + height + (boost * height) + 1, (x + width) - 1, (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) {
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
			}
			if(GuiUtil.lheld) {
				int percentError = (GuiUtil.mX - (x)) * 100 / ((x + width - 4) - x);
				s.setValue((int) (percentError * ((s.getMaxValue() - s.getMinValue()) / 100.0D) + s.getMinValue()));
			}
			if(GuiUtil.rdown) { 
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				s.setOpened(!s.isOpened()); 
			}
		}
		if(pixAdd < 3) pixAdd = 3;
		if(pixAdd > width - 1) pixAdd = width - 1;
		//Sides
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		//Main
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		GuiScreen.drawRect(x + 2, y + height + (boost * height) + 1, (x -1 ) + pixAdd, (y + height) + height + (boost * height) - 2, BESTCOLOR(190));
		Guinness.smallFont.drawStringWithShadow(s.getName(), x + 3, (y + height) + 2 + (boost * height), -1);
		Guinness.smallFont.drawStringWithShadow(String.valueOf(s.getValue()), x + width - Guinness.smallFont.getStringWidth(String.valueOf(s.getValue())) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
	}
	
	private static void renderSubInteger(SubInteger ss, int x, int y) {
		int pixAdd = (int) (((x + width) - x) * (ss.getValue() - ss.getMinValue()) / (ss.getMaxValue() - ss.getMinValue()));
		if(GuiUtil.mouseOver(x, y + height + (boost * height), (x + width), (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) {
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
			}
			if(GuiUtil.lheld) { 
				int percentError = (GuiUtil.mX - (x)) * 100 / ((x + width) - x);
				ss.setValue((int) (percentError * ((ss.getMaxValue() - ss.getMinValue()) / 100.0D) + ss.getMinValue()));
			}
		}
		if(pixAdd < 4) pixAdd = 4;
		//Sides
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
				
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		GuiScreen.drawRect(x + 2, y + height + (boost * height) + 1, (x - 2) + pixAdd, (y + height) + height + (boost * height) - 2, BESTCOLOR(190));
		Guinness.smallFont.drawStringWithShadow(ss.getName(), x + 20, (y + height) + 2 + (boost * height), -1);
		Guinness.smallFont.drawStringWithShadow(String.valueOf(ss.getValue()), x + width - Guinness.smallFont.getStringWidth(String.valueOf(ss.getValue())) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
	}
	
	private static void renderDouble(SDouble s, int x, int y) {
		int pixAdd = (int) (((x + width) - x) * (s.getValue() - s.getMinValue()) / (s.getMaxValue() - s.getMinValue()));
		if(GuiUtil.mouseOver(x + 1, y + height + (boost * height) + 1, (x + width) - 1, (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) {
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
			}
			if(GuiUtil.lheld) {
				int percentError = (GuiUtil.mX - (x)) * 100 / ((x + width - 4) - x);
				s.setValue(MathUtil.roundDouble(percentError * ((s.getMaxValue() - s.getMinValue()) / 100.0D) + s.getMinValue(), s.getRoundingScale()));
			}
			if(GuiUtil.rdown) { 
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				s.setOpened(!s.isOpened());
			}
		}
		if(pixAdd < 3) pixAdd = 3;
		if(pixAdd > width - 1) pixAdd = width - 1;
		if(s.getValue() > s.getMaxValue()) s.setValue(s.getMaxValue());
		//Sides
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		//Main
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		GuiScreen.drawRect(x + 2, y + height + (boost * height) + 1, (x -1 ) + pixAdd, (y + height) + height + (boost * height) - 2, BESTCOLOR(190));
		Guinness.smallFont.drawStringWithShadow(s.getName(), x + 3, (y + height) + 2 + (boost * height), -1);
		Guinness.smallFont.drawStringWithShadow(String.valueOf(s.getValue()), x + width - Guinness.smallFont.getStringWidth(String.valueOf(s.getValue())) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
	}

	private static void renderSubDouble(SubDouble ss, int x, int y) {
		int pixAdd = (int) (((x + width) - x) * (ss.getValue() - ss.getMinValue()) / (ss.getMaxValue() - ss.getMinValue()));
		if(GuiUtil.mouseOver(x, y + height + (boost * height), (x + width), (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) {
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
			}
			if(GuiUtil.lheld) { 
				int percentError = (GuiUtil.mX - (x)) * 100 / ((x + width) - x);
				ss.setValue(MathUtil.roundDouble(percentError * ((ss.getMaxValue() - ss.getMinValue()) / 100.0D) + ss.getMinValue(), ss.getRoundingScale()));
			}
		}
		if(pixAdd < 4) pixAdd = 4;
		//Sides
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
				
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		GuiScreen.drawRect(x + 2, y + height + (boost * height) + 1, (x - 2) + pixAdd, (y + height) + height + (boost * height) - 2, BESTCOLOR(190));
		Guinness.smallFont.drawStringWithShadow(ss.getName(), x + 20, (y + height) + 2 + (boost * height), -1);
		Guinness.smallFont.drawStringWithShadow(String.valueOf(ss.getValue()), x + width - Guinness.smallFont.getStringWidth(String.valueOf(ss.getValue())) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
	}
	
	public static void renderKeybind(ClientModule m, int key, int x, int y) {
		if(GuiUtil.mouseOver(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height - 1 + (boost * height))) {
			if(GuiUtil.ldown) {
				if(ClickGui.click.getValue())
					mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F, 0.1F));
				m.setBinding(true);
			}
		}
		if(m.isBinding() && key != -1 && key != Keyboard.KEY_ESCAPE && key != Keyboard.KEY_DELETE) {
			m.getKeybind().setKeyCode((key == Keyboard.KEY_DELETE || key == Keyboard.KEY_BACK) ? Keyboard.KEY_NONE : key);
			m.setBinding(false);
		}
		if(m.isBinding() && key == Keyboard.KEY_ESCAPE) m.setBinding(false);
		GuiScreen.drawRect(x - 1, y + height + (boost * height), x, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + width, y + height + (boost * height), x + width + 1, y + height*2 + (boost * height), BESTCOLOR(255));
		GuiScreen.drawRect(x + 1, y + height + (boost * height), (x + width) - 1, (y + height) + height + (boost * height) - 1, 0x76000000);
		if(!m.isBinding()) {
			Guinness.smallFont.drawStringWithShadow("Keybind", x + 4, (y + height) + 2 + (boost * height), -1);
			String displayName = m.getKeybind().getDisplayName().equalsIgnoreCase("NONE") ? "None" : m.getKeybind().getDisplayName();
			Guinness.smallFont.drawStringWithShadow(displayName, x + width - Guinness.smallFont.getStringWidth(displayName) - 2, (y + height) + 2 + (boost * height), 0xFF767676);
		} else {
			Guinness.smallFont.drawStringWithShadow("Listening...", x + 4, (y + height) + 2 + (boost * height), 0xFF767676);
		}
	}
	
}