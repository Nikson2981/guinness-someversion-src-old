package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.movement.NoWeb;
import net.minecraft.block.BlockWeb;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

@Mixin(BlockWeb.class)
public class MixinBlockWeb {

	@Inject(method = "onEntityCollidedWithBlock", at = @At("HEAD"), cancellable = true)
		public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn, CallbackInfo ci) {
			if(ModuleManager.getModuleByClass(NoWeb.class).isEnabled()) {
				ci.cancel();
			}
		}
	
}
