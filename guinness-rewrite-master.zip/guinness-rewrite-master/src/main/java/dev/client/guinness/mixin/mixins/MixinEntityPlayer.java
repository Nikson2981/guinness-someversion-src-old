package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import dev.client.guinness.event.events.PlayerPushEvent;
import dev.client.guinness.event.events.WaterPushEvent;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.misc.NoCooldown;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;

@Mixin(EntityPlayer.class)
public abstract class MixinEntityPlayer extends EntityLivingBase {

	public MixinEntityPlayer(World worldIn) {
		super(worldIn);
	}
	
	@Inject(method = "isPushedByWater()Z", at = @At("HEAD"), cancellable = true)
	public void isPushedByWater(CallbackInfoReturnable<Boolean> ci) {
	    WaterPushEvent event = new WaterPushEvent();
	    MinecraftForge.EVENT_BUS.post(event);
	    if (event.isCanceled())
	        ci.setReturnValue(false);
	}
	    
	@Inject(method = "applyEntityCollision", at = @At("HEAD"), cancellable = true)
	public void applyEntityCollision(Entity p, CallbackInfo ci) {
	    PlayerPushEvent event = new PlayerPushEvent(p);
	    MinecraftForge.EVENT_BUS.post(event);
	    if(event.isCanceled())
	    	ci.cancel();
	}
	
	@Inject(method = "resetCooldown", at = @At("HEAD"), cancellable = true)
	public void resetCooldown(CallbackInfo ci) {
		if(ModuleManager.getModuleByClass(NoCooldown.class).isEnabled()) {
			ci.cancel();
		}
	}

}
