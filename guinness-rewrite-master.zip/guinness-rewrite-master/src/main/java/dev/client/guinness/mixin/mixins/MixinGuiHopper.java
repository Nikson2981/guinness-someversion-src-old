package dev.client.guinness.mixin.mixins;

import java.io.IOException;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;

@Mixin(GuiHopper.class)
public abstract class MixinGuiHopper extends GuiContainer {

	public MixinGuiHopper(Container inventorySlotsIn) {
		super(inventorySlotsIn);
	}

	@Inject(method = "drawScreen", at = @At("TAIL"))
	public void drawScreen(CallbackInfo ci) {
		this.buttonList.add(new GuiButton(69420, (width - xSize) / 2 + 82, (height - ySize) / 2 + 5, 44, 12, "Swap"));
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		if(button.id == 69420) {
			mc.player.dropItem(true);
			mc.playerController.windowClick(mc.player.openContainer.windowId, 0, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
		}
    }

}
