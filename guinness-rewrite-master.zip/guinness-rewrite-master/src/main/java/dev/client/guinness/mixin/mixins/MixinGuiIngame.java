package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.client.HUD;
import dev.client.guinness.module.modules.render.NoRender;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;

@Mixin(GuiIngame.class)
public class MixinGuiIngame extends Gui {
	
	@Inject(method = "renderPortal", at = @At("HEAD"), cancellable = true)
    protected void renderPortalHook(float n, ScaledResolution scaledResolution, CallbackInfo ci) {
        if (ModuleManager.getModuleByClass(NoRender.class).isEnabled() && NoRender.portal.getValue()) {
           ci.cancel();
        }
    }
    
    @Inject(method = "renderPumpkinOverlay", at = @At("HEAD"), cancellable = true)
    protected void renderPumpkinOverlayHook(ScaledResolution scaledRes, CallbackInfo ci) {
        if (ModuleManager.getModuleByClass(NoRender.class).isEnabled() && NoRender.pumpkin.getValue()) {
           ci.cancel();
        }
    }
    
    @Inject(method = "renderPotionEffects", at = @At("HEAD"), cancellable = true)
    protected void renderPotionEffectsHook(ScaledResolution scaledRes, CallbackInfo ci) {
        if (ModuleManager.getModuleByClass(HUD.class).isEnabled() && HUD.potions.getValue()) {
           ci.cancel();
        }
    }
	

}
