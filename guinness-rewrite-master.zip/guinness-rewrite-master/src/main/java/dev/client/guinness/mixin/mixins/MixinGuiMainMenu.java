package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.Guinness;
import dev.client.guinness.util.client.ColorUtil;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiScreen;

/**
 * @author bon
 * @since 11/12/20
 */

//TODO: Figure out how to properly do mixin priority for good compatibility
@Mixin(value = GuiMainMenu.class, priority = 10006)
public class MixinGuiMainMenu extends GuiScreen {
	
	String s = "Custom Base";
	
	@Inject(method = "drawScreen", at = @At("TAIL"), cancellable = true)
	public void drawText(int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
		Guinness.customFont.drawStringWithShadow("Guinness Client", 2, 2, ColorUtil.rainbow(1, 255));
	}
	
}
