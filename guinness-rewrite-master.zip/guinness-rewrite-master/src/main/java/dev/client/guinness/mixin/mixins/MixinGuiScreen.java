package dev.client.guinness.mixin.mixins;

import net.minecraft.client.renderer.entity.RenderPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.misc.ShulkerPeek;
import dev.client.guinness.module.modules.render.NoRender;
import dev.client.guinness.util.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.item.ItemStack;

@Mixin(GuiScreen.class)
public class MixinGuiScreen implements Wrapper {

	@Inject(method = "drawDefaultBackground", at = @At("HEAD"), cancellable = true)
	public void drawDefaultBackground(CallbackInfo ci) {
		if(Minecraft.getMinecraft().player != null && Minecraft.getMinecraft().world != null && ModuleManager.getModuleByClass(NoRender.class).isEnabled() && NoRender.guitint.getValue()) {
			ci.cancel();
		}
	}
	
	@Inject(method = "renderToolTip", at = @At("HEAD"), cancellable = true)
	public void renderToolTip(ItemStack itemStack, int x, int y, CallbackInfo ci) {
		if(ModuleManager.getModuleByClass(ShulkerPeek.class).isEnabled()) {
			ShulkerPeek.renderToolTip(itemStack, x, y, ci);
		}
	}
	
}
