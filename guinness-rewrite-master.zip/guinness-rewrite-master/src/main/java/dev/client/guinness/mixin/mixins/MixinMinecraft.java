package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.event.events.GuiScreenEvent;
import dev.client.guinness.util.Wrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.common.MinecraftForge;

@Mixin(Minecraft.class)
public class MixinMinecraft implements Wrapper {


	protected boolean Null() {
		return (mc.player == null || mc.world == null);
	}

	@Inject(method = "displayGuiScreen", at = @At("HEAD"), cancellable = true)
    public void displayGuiScreen(GuiScreen guiScreenIn, CallbackInfo info) {
		if (Null()) return;
		GuiScreenEvent event = new GuiScreenEvent(guiScreenIn);
		MinecraftForge.EVENT_BUS.post(event);
		if (guiScreenIn == null && mc.player.getHealth() <= 0) {
            guiScreenIn = new GuiGameOver(null);
        }
	}
	
}
