package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.dispenserpvp.Aura32k;
import net.minecraft.client.particle.ParticleManager;

@Mixin(ParticleManager.class)
public class MixinParticleManager {

	/**
	 * Stops particles from being rendered when 32kAura is enabled, has a target, and antilag is on.
	 * Particle manager can crash or slow the game, this should make aura better.
	 */
	@Inject(method = "updateEffects", at = @At("HEAD"), cancellable = true)
	public void updateEffects(CallbackInfo ci) {
		
	}
	
}
