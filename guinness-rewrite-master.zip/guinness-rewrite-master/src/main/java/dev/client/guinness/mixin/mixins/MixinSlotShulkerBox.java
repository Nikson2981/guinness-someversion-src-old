package dev.client.guinness.mixin.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.exploit.Shulkerception;
import dev.client.guinness.util.Wrapper;
import net.minecraft.block.Block;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.inventory.SlotShulkerBox;
import net.minecraft.item.ItemStack;

@Mixin(SlotShulkerBox.class)
public class MixinSlotShulkerBox implements Wrapper {
	
	@Inject(method = "isItemValid", at = @At("HEAD"), cancellable = true)
	public void isItemValid(ItemStack stack, CallbackInfoReturnable<Boolean> ci) {
		if(ModuleManager.getModuleByClass(Shulkerception.class).isEnabled() && Block.getBlockFromItem(stack.getItem()) instanceof BlockShulkerBox) {
			ci.setReturnValue(mc.player.isCreative());
		}
	}

}
