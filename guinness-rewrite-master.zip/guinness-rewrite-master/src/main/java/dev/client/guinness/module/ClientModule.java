package dev.client.guinness.module;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import org.lwjgl.input.Keyboard;

import com.mojang.realmsclient.gui.ChatFormatting;

import dev.client.guinness.module.modules.client.Notify;
import dev.client.guinness.setting.settings.Setting;
import dev.client.guinness.util.Wrapper;
import dev.client.guinness.util.client.MessageUtil;
import mcp.MethodsReturnNonnullByDefault;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;

/**
 * @author bon
 * @since 11/13/20
 * 
 * Renamed to ClientModule because my IDE decided to choose ibmx.Module every time I imported it bruh
 */

public abstract class ClientModule implements Wrapper {

	private final String name;
	private final ModuleCategory category;
	private KeyBinding key;
	private boolean enabled = false;
	
	private boolean isKeyDown = false;
	
	//Gui
	private boolean opened = false;
	private boolean isBinding = false;
	
	private String arraylistInfo;
	
	public List<Setting<?>> settingsList = new ArrayList<>();
	
	//sometimes a mf dont feel like having a description
	protected ClientModule(String name, ModuleCategory category) {
		this.name = name;
		this.category = category;
		
		this.key = new KeyBinding(name, Keyboard.KEY_NONE, "Guinness");
		ClientRegistry.registerKeyBinding(this.key);
	}
	
	protected void onEnable() {
		if(ModuleManager.getModuleByClass(Notify.class).isEnabled() && !this.name.equalsIgnoreCase("clickgui")) {
			MessageUtil.sendClientMessage(this.name + ChatFormatting.GREEN + " enabled");
		}
		MinecraftForge.EVENT_BUS.register(this);
	}
	
	protected void onDisable() {
		if(ModuleManager.getModuleByClass(Notify.class).isEnabled() && !this.name.equalsIgnoreCase("clickgui")) {
			MessageUtil.sendClientMessage(this.name + ChatFormatting.RED + " disabled");
		}
		MinecraftForge.EVENT_BUS.unregister(this);
	}
	
	public void onUpdate() {
		
	}
	
	public void onFastUpdate() {
		
	}
	
	public void toggle() {
		this.enabled = !this.enabled;
		try {
			if(this.isEnabled()) {
				this.onEnable();
			} else {
				this.onDisable();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void enable() {
		if(!this.isEnabled()) {
			this.enabled = true;
			try { this.onEnable(); }
			catch(Exception e) { e.printStackTrace(); }
		}
	}
	
	public void disable() {
		if(this.isEnabled()) {
			this.enabled = false;
			try { this.onDisable(); }
			catch(Exception e) { e.printStackTrace(); }
		}
	}
	
	//Getters
	public String getName() {
		return this.name;
	}
	
	public boolean isEnabled() {
		return this.enabled;
	}
	
	public ModuleCategory getCategory() {
		return this.category;
	}
	
	public KeyBinding getKeybind() {
		return this.key;
	}
	
	public List<Setting<?>> getSettings(){
		return this.settingsList;
	}
	
	public boolean isOpened() {
		return this.opened;
	}
	
	public boolean isBinding() {
		return this.isBinding;
	}
	
	public boolean isKeyDown() {
		return this.isKeyDown;
	}
	
	public boolean hasSettings() {
		return this.settingsList.size() > 0;
	}
	
	public String getArraylistInfo() {
		return this.arraylistInfo;
	}
	
	public Setting<?> getSettingByName(String name) {
		return this.settingsList.stream()
				.filter(setting -> setting.getName().equalsIgnoreCase(name))
				.findFirst()
				.orElse(null);
	}
	
	//Setters
	public void setKeybind(KeyBinding key) {
		this.key = key;
	}
	
	public void setOpen(boolean opened) {
		this.opened = opened;
	}
	
	public void setBinding(boolean b) {
		this.isBinding = b;
	}
	
	public void setKeyDown(boolean b) {
		this.isKeyDown = b;
	}
	
	protected void addSetting(Setting<?> s) {
		settingsList.add(s);
	}
	
	protected void setArraylistInfo(String info) {
		this.arraylistInfo = info;
	}
	
	/**
	 * @return true if null, false if non-null.
	 **/
	protected boolean Null() {
		return (mc.player == null || mc.world == null);
	}

	public enum ModuleCategory {
		/*
		 * Adjust these categories as needed.
		 */
		CLIENT("Client"),
		COMBAT("Combat"),
		EXPLOIT("Exploit"),
		MISC("Misc"),
		MOVEMENT("Movement"),
		RENDER("Render"),
		DISPENSERPVP("32k"),
		HIDDEN("Hidden");
		
		private final String name;
		
		private ModuleCategory(final String name) {
			this.name = name;
		}
		
		public String getName() {
			return this.name;
		}
	}
	
}
