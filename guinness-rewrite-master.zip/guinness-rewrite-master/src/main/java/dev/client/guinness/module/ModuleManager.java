package dev.client.guinness.module;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import dev.client.guinness.module.ClientModule.ModuleCategory;

import dev.client.guinness.module.modules.client.*;
import dev.client.guinness.module.modules.combat.*;
import dev.client.guinness.module.modules.dispenserpvp.*;
import dev.client.guinness.module.modules.exploit.*;
import dev.client.guinness.module.modules.misc.*;
import dev.client.guinness.module.modules.movement.*;
import dev.client.guinness.module.modules.render.*;

import dev.client.guinness.util.Wrapper;

/**
 * @author bon
 * @since 11/13/20
 */

public class ModuleManager implements Wrapper {

    private static final List<ClientModule> modules = Arrays.asList
            (
                    //Client
                    new Arraylist(),
                    new ClickGui(),
                    new HUD(),
                    new Notify(),
                    //Combat
                    new AnchorAura(),
                    new AutoArmor(),
                    new AutoCreeper(),
                    new AutoTotem(),
                    new AutoTrap(),
                    new AutoTrapBed(),
                    new BedAura(),
                    new BowSpam(),
                    new Burrow(),
                    new Criticals(),
                    new Offhand(),
                    new PacketAutoCity(),
                    new PistonAura(),
                    //Exploit
                    new AntiHunger(),
                    new AntiPacketBan(),
                    new ArmorCrasher(),
                    new EBackPack(),
                    new EntityDesync(),
                    new KitBackPack(),
                    new MountBypass(),
                    new NoHandshake(),
                    new NoSwing(),
                    new NoTurn(),
                    new PacketCanceller(),
                    new PacketMine(),
                    new PortalGodmode(),
                    new Reach(),
                    new SecretClose(),
                    new Shulkerception(),
                    new XCarry(),
                    //Misc
                    new AutoCope(),
                    new AutoEZ(),
                    new AutoRespawn(),
                    new BuildHeight(),
                    new ChatEncryption(),
                    new ChatSuffix(),
                    new FakeCreative(),
                    new FakePlayer(),
                    new MiddleClick(),
                    new NoCooldown(),
                    new NoEntityTrace(),
                    new PortalChat(),
                    new Potion(),
                    new ShulkerPeek(),
                    new TotemPopCounter(),
                    new VisualRange(),
                    //Movement
                    new FastFall(),
                    new IceSpeed(),
                    new NoPush(),
                    new NoSlow(),
                    new NoWeb(),
                    new PearlTP(),
                    new Velocity(),
                    //Render
                    new BlockHighlight(),
                    new DeathEffects(),
                    new ESP(),
                    new Fullbright(),
                    new NoRender(),
                    new NoWeather(),
                    new SkyColor(),
                    new ViewModel(),
                    //DispenserPVP
                    new Aura32k(),
                    new Block32k(),
                    new blu3Auto32k(),
                    new Info32k(),
                    new Throw32k(),
                    new TP32k(),
                    new Anti32k(),
                    new Auto32k(),
                    new HopperNuker(),
                    //Hidden
                    new TP32kHelper(),
                    new blu332kReset()
            );

    public static List<ClientModule> getModules() {
        return new ArrayList<>(modules);
    }

    public static List<ClientModule> getModulesInCategory(ModuleCategory cat) {
        List<ClientModule> modulesInCat = new ArrayList<>();
        modules.stream()
                .filter(m -> m.getCategory().equals(cat))
                .forEach(m -> modulesInCat.add(m));

        return modulesInCat;
    }

    public static ClientModule getModuleByName(String name) {
        return modules.stream()
                .filter(module -> module.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public static ClientModule getModuleByClass(Class<? extends ClientModule> clazz) {
        return modules.stream()
                .filter(module -> module.getClass().equals(clazz))
                .findFirst()
                .orElse(null);
    }

}
