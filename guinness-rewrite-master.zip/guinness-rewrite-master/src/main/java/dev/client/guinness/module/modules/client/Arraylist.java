package dev.client.guinness.module.modules.client;

import java.util.List;
import java.util.stream.Collectors;

import dev.client.guinness.Guinness;
import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.setting.settings.SMode;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Arraylist extends ClientModule {
	private SMode side = new SMode("Side", "Top Left", "Top Right", "Bottom Left", "Bottom Right");
	public Arraylist() {
		super("Arraylist", ModuleCategory.CLIENT);
		addSetting(side);
	}
	
	@SubscribeEvent
	public void onRender(RenderGameOverlayEvent event) {
		if(Null()) return;
		if (event.getType().equals(ElementType.TEXT)) {
			int boost = 0;
			ScaledResolution sr = new ScaledResolution(mc);
			List<ClientModule> activemods = ModuleManager.getModules().stream()
					.filter(m -> m.isEnabled())
					.filter(m -> m.getCategory() != ModuleCategory.HIDDEN)
					.collect(Collectors.toList());
			if(side.getValue().equalsIgnoreCase("Top Left")) {
				if(ClickGui.theme.getValue().equalsIgnoreCase("Cliffbase")) {
					activemods.sort((w, l) -> Integer.compare((int) mc.fontRenderer.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) mc.fontRenderer.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						mc.fontRenderer.drawStringWithShadow(m.getName(), 1, 1 + boost*9, FinalColor.BESTCOLOR(255, boost));
						if(m.getArraylistInfo() != null) mc.fontRenderer.drawStringWithShadow(m.getArraylistInfo(), mc.fontRenderer.getStringWidth(m.getName()) + 3, 1 + boost*9, 0xFFB5B5B5);
						boost++;
					}
				} else {
					activemods.sort((w, l) -> Integer.compare((int) Guinness.customFont.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) Guinness.customFont.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						Guinness.customFont.drawStringWithShadow(m.getName(), 1, 1 + boost*9, FinalColor.BESTCOLOR(255, boost));
						if(m.getArraylistInfo() != null) Guinness.customFont.drawStringWithShadow(m.getArraylistInfo(), Guinness.customFont.getStringWidth(m.getName()) + 3, 1 + boost*9, 0xFFB5B5B5);
						boost++;
					}
				}
			}
			if(side.getValue().equalsIgnoreCase("Top Right")) {
				if(ClickGui.theme.getValue().equalsIgnoreCase("Cliffbase")) {
					activemods.sort((w, l) -> Integer.compare((int) mc.fontRenderer.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) mc.fontRenderer.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						if(m.getArraylistInfo() != null) {
							mc.fontRenderer.drawStringWithShadow(m.getName(), sr.getScaledWidth() - mc.fontRenderer.getStringWidth(m.getName() + m.getArraylistInfo()) - 4, 1 + boost*9, FinalColor.BESTCOLOR(255, boost));
							mc.fontRenderer.drawStringWithShadow(m.getArraylistInfo(), sr.getScaledWidth() - mc.fontRenderer.getStringWidth(m.getArraylistInfo()) - 2, 1 + boost*9, 0xFFB5B5B5);
							boost++;
						} else {
							mc.fontRenderer.drawStringWithShadow(m.getName(), sr.getScaledWidth() - mc.fontRenderer.getStringWidth(m.getName()) - 2, 1 + boost*9, FinalColor.BESTCOLOR(255, boost));
							boost++;
						}
					}
				} else {
					activemods.sort((w, l) -> Integer.compare((int) Guinness.customFont.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) Guinness.customFont.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						if(m.getArraylistInfo() != null) {
							Guinness.customFont.drawStringWithShadow(m.getName(), sr.getScaledWidth() - Guinness.customFont.getStringWidth(m.getName() + m.getArraylistInfo()) - 4, 1 + boost*9, FinalColor.BESTCOLOR(255, boost));
							Guinness.customFont.drawStringWithShadow(m.getArraylistInfo(), sr.getScaledWidth() - Guinness.customFont.getStringWidth(m.getArraylistInfo()) - 2, 1 + boost*9, 0xFFB5B5B5);
							boost++;
						} else {
							Guinness.customFont.drawStringWithShadow(m.getName(), sr.getScaledWidth() - Guinness.customFont.getStringWidth(m.getName()) - 2, 1 + boost*9, FinalColor.BESTCOLOR(255, boost));
							boost++;
						}
					}
				}
			}
			if(side.getValue().equalsIgnoreCase("Bottom Left")) {	
				if(ClickGui.theme.getValue().equalsIgnoreCase("Cliffbase")) {
					activemods.sort((w, l) -> Integer.compare((int) mc.fontRenderer.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) mc.fontRenderer.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						mc.fontRenderer.drawStringWithShadow(m.getName(), 1, (sr.getScaledHeight() - 10) - boost*9, FinalColor.BESTCOLOR(255, boost));
						if(m.getArraylistInfo() != null) mc.fontRenderer.drawStringWithShadow(m.getArraylistInfo(), mc.fontRenderer.getStringWidth(m.getName()) + 3, (sr.getScaledHeight() - 10) - boost*9, 0xFFB5B5B5);
						boost++;
					}
				} else {
					activemods.sort((w, l) -> Integer.compare((int) Guinness.customFont.getStringWidth(l.getName()  + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) Guinness.customFont.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						Guinness.customFont.drawStringWithShadow(m.getName(), 1, (sr.getScaledHeight() - 10) - boost*9, FinalColor.BESTCOLOR(255, boost));
						if(m.getArraylistInfo() != null) Guinness.customFont.drawStringWithShadow(m.getArraylistInfo(), Guinness.customFont.getStringWidth(m.getName()) + 3, (sr.getScaledHeight() - 10) - boost*9, 0xFFB5B5B5);
						boost++;
					}
				}
			}
			if(side.getValue().equalsIgnoreCase("Bottom Right")) {
				if(ClickGui.theme.getValue().equalsIgnoreCase("Cliffbase")) {
					activemods.sort((w, l) -> Integer.compare((int) mc.fontRenderer.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) mc.fontRenderer.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						if(m.getArraylistInfo() != null) {
							mc.fontRenderer.drawStringWithShadow(m.getName(), sr.getScaledWidth() - mc.fontRenderer.getStringWidth(m.getName() + m.getArraylistInfo()) - 4, (sr.getScaledHeight() - (mc.currentScreen instanceof GuiChat ? 24 : 10)) - boost*9, FinalColor.BESTCOLOR(255, boost));
							mc.fontRenderer.drawStringWithShadow(m.getArraylistInfo(), sr.getScaledWidth() - mc.fontRenderer.getStringWidth(m.getArraylistInfo()) - 2, (sr.getScaledHeight() - (mc.currentScreen instanceof GuiChat ? 24 : 10)) - boost*9, 0xFFB5B5B5);
							boost++;
						} else {
							mc.fontRenderer.drawStringWithShadow(m.getName(), sr.getScaledWidth() - mc.fontRenderer.getStringWidth(m.getName()) - 2, (sr.getScaledHeight() - (mc.currentScreen instanceof GuiChat ? 24 : 10)) - boost*9, FinalColor.BESTCOLOR(255, boost));
							boost++;
						}
					}
				} else {
					activemods.sort((w, l) -> Integer.compare((int) Guinness.customFont.getStringWidth(l.getName() + (l.getArraylistInfo() != null ? l.getArraylistInfo() : "")), (int) Guinness.customFont.getStringWidth(w.getName() + (w.getArraylistInfo() != null ? w.getArraylistInfo() : ""))));
					for(ClientModule m : activemods) {
						if(m.getArraylistInfo() != null) {
							Guinness.customFont.drawStringWithShadow(m.getName(), sr.getScaledWidth() - Guinness.customFont.getStringWidth(m.getName() + m.getArraylistInfo()) - 4, (sr.getScaledHeight() - (mc.currentScreen instanceof GuiChat ? 24 : 10)) - boost*9, FinalColor.BESTCOLOR(255, boost));
							Guinness.customFont.drawStringWithShadow(m.getArraylistInfo(), sr.getScaledWidth() - Guinness.customFont.getStringWidth(m.getArraylistInfo()) - 2, (sr.getScaledHeight() - (mc.currentScreen instanceof GuiChat ? 24 : 10)) - boost*9, 0xFFB5B5B5);
							boost++;
						} else {
							Guinness.customFont.drawStringWithShadow(m.getName(), sr.getScaledWidth() - Guinness.customFont.getStringWidth(m.getName()) - 2, (sr.getScaledHeight() - (mc.currentScreen instanceof GuiChat ? 24 : 10)) - boost*9, FinalColor.BESTCOLOR(255, boost));
							boost++;
						}
					}
				}
			}
		}
	}

}
