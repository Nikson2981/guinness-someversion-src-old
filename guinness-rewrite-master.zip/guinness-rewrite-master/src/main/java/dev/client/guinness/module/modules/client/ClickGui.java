package dev.client.guinness.module.modules.client;

import dev.client.guinness.gui.main.GuinnessGui;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SDouble;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.setting.subsettings.SubBoolean;
import dev.client.guinness.setting.subsettings.SubDouble;
import net.minecraft.util.ResourceLocation;

/**
 * @author bon
 * @since 11/16/20
 */

public class ClickGui extends ClientModule {
	
	public static SMode theme = new SMode("Theme", "Guinness", "GuinnessClean", "GuinnessThin", "Cliffbase");
	public static SBoolean click = new SBoolean("Click Sound", true);
	public static SBoolean blur = new SBoolean("Blur", true);
	public static SBoolean watermark = new SBoolean("Watermark", true);
	public static SBoolean rainbow = new SBoolean("Rainbow", true);
		public static SubBoolean gradient = new SubBoolean(rainbow, "Gradient", true);
		public static SubDouble saturation = new SubDouble(rainbow, "Saturation", 0.01D, 0.80D, 1.00D, 2);
		public static SubDouble brightness = new SubDouble(rainbow, "Brightness", 0.01D, 0.80D, 1.00D, 2);
		public static SubDouble difference = new SubDouble(rainbow, "Difference", 0.1D, 25.0D, 100.0D, 1);
		public static SubDouble speed = new SubDouble(rainbow, "Speed", 0.1D, 25.0D, 100.0D, 1);
	public static SDouble r = new SDouble("R", 0.0D, 200.0D, 255.0D, 1);
	public static SDouble g = new SDouble("G", 0.0D, 200.0D, 255.0D, 1);
	public static SDouble b = new SDouble("B", 0.0D, 200.0D, 255.0D, 1);
	
	public static GuinnessGui clickGui = new GuinnessGui();
	
	public ClickGui() {
		super("ClickGui", ModuleCategory.CLIENT);
		addSetting(theme);
		addSetting(click);
		addSetting(blur);
		addSetting(rainbow);
		addSetting(r);
		addSetting(g);
		addSetting(b);
	}
	
	@Override
	public void onEnable() {
		super.onEnable();
		mc.displayGuiScreen(clickGui);
		if(blur.getValue()) {
			mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
		}
	}
}
