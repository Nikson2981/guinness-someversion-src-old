package dev.client.guinness.module.modules.client;

import dev.client.guinness.command.Console;
import dev.client.guinness.module.ClientModule;

public class CommandConsole extends ClientModule {
    public CommandConsole() {
        super("Console", ModuleCategory.CLIENT);
    }

    public Console console = new Console();
    public void onEnable() {
        mc.displayGuiScreen(console);
        disable();
    }
}
