package dev.client.guinness.module.modules.client;

import dev.client.guinness.Guinness;
import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HUD extends ClientModule {
	public static SBoolean potions = new SBoolean("Potions", false);
	public HUD() {
		super("HUD", ModuleCategory.CLIENT);
		addSetting(potions);
	}
	
	@SubscribeEvent
	public void onRender(Text event) {
		if(Null()) return;
		ScaledResolution sr = new ScaledResolution(mc);
		if (event.getType().equals(ElementType.TEXT)) {
			if(potions.getValue()) {
				int boost = 0;
				for(PotionEffect pe : mc.player.getActivePotionEffects()) {
					Guinness.customFont.drawStringWithShadow(ModuleUtil.getPotionString(pe), sr.getScaledWidth() - Guinness.customFont.getStringWidth(ModuleUtil.getPotionString(pe)) + 4, 1 + (boost*9), FinalColor.BESTCOLOR(255, boost));
					boost++;
				}
			}
		}
	}

}
