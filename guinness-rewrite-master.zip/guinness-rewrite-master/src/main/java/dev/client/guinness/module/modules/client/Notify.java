package dev.client.guinness.module.modules.client;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.util.text.TextFormatting;

/**
 * @author bon
 * @since 11/12/20
 */

public class Notify extends ClientModule {
	public Notify() {
		super("Notify", ModuleCategory.CLIENT);
	}
	
	//Needed because when its disabled it can't send the message
	@Override
	public void onDisable() {
		MessageUtil.sendClientMessage("Notify " + TextFormatting.RED + "disabled");
	}
}
