package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AnchorAura extends ClientModule {
	public AnchorAura() {
		super("AnchorAura", ModuleCategory.COMBAT);
	}
	int obby;
	int glow;
	int tickdelay = 0;
	EntityPlayer closestTarget;
	
	@Override
	public void onEnable() {
		if(Null()) {
			this.disable();
			return;
		}
		tickdelay = 0;
		obby = InventoryUtil.find(Blocks.OBSIDIAN);
		glow = InventoryUtil.find(Blocks.GLOWSTONE);
		if(obby == -1 || glow == -1) {
			MessageUtil.sendClientMessage("Missing obsidian or glowstone!");
			this.disable();
			return;
		}
	}
	
	@Override
	public void onUpdate() {
		if(Null()) {
			this.disable();
			return;
		}
		tickdelay++;
		closestTarget = (EntityPlayer) ModuleUtil.getActualClosestPlayerLOL();
		if(closestTarget == null) return;
		
		BlockPos boompos = new BlockPos(closestTarget.getPositionVector());
		
		if(tickdelay == 8) {
			mc.player.inventory.currentItem = obby;
			ModuleUtil.placeBlock(boompos.add(0, 1, 0), EnumFacing.UP, true, EnumHand.MAIN_HAND);
			tickdelay++;
		}
		
		if(tickdelay == 16) {
			mc.player.inventory.currentItem = glow;
			//mc.playerController.processRightClickBlock(mc.player, mc.world, boompos.add(0, 3, 0), EnumFacing.DOWN, new Vec3d(0, 0, 0), EnumHand.MAIN_HAND);
			ModuleUtil.placeBlock(boompos.add(0, 1, 0), EnumFacing.UP, true, EnumHand.MAIN_HAND);
			tickdelay++;
		}
		
		if(tickdelay == 24) {
			mc.player.inventory.currentItem = obby;
			//mc.playerController.processRightClickBlock(mc.player, mc.world, boompos.add(0, 3, 0), EnumFacing.DOWN, new Vec3d(0, 0, 0), EnumHand.MAIN_HAND);
			ModuleUtil.placeBlock(boompos.add(0, 1, 0), EnumFacing.UP, true, EnumHand.MAIN_HAND);
			tickdelay++;
		}
		
		if(tickdelay == 85) {
			tickdelay = 0;
		}
	}
	
	@Override
	public void onDisable() {
		if(Null()) return;
		tickdelay = 0;
	}

}
