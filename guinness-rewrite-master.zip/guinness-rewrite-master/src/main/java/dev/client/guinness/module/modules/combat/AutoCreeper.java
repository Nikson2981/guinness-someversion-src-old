package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AutoCreeper extends ClientModule {
	private SInteger delay = new SInteger("Delay", 1, 3, 15);
	public AutoCreeper() {
		super("AutoCreeper", ModuleCategory.COMBAT);
		addSetting(delay);
	}
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		EntityPlayer target = mc.world.playerEntities.stream()
				.filter(p -> p != mc.player)
				.filter(p -> !FriendUtil.isFriend(p.getName()))
				.filter(p -> mc.player.getDistance(p) <= 8)
				.filter(p -> p.getHealth() > 0.0F)
				.findFirst()
				.orElse(null);
		int egg = InventoryUtil.find(Items.SPAWN_EGG);
		
		if(target == null) return;
		if(egg == -1) return;
		
		if(mc.player.ticksExisted % delay.getValue() == 0) {
			mc.player.ticksExisted++;
			mc.player.inventory.currentItem = egg;
			BlockPos targetblock = new BlockPos(target.getPositionVector());
			ModuleUtil.placeBlock(targetblock, EnumFacing.DOWN, true, EnumHand.MAIN_HAND);
		}
		
	}

}
