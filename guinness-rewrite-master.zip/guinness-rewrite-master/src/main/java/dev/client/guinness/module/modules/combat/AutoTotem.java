package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.module.InventoryUtil;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;

public class AutoTotem extends ClientModule {
	private SMode mode = new SMode("Mode", "Normal", "Fast");
	public AutoTotem() {
		super("AutoTotem", ModuleCategory.COMBAT);
		addSetting(mode);
	}
	
	@Override
	public void onUpdate() {
		this.setArraylistInfo(this.mode.getValue());
		if(mode.getValue().equalsIgnoreCase("Normal")) {
			if(Null()) return;
			if(mc.currentScreen instanceof GuiContainer) return;
			if(mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) return;
			
			int totem = InventoryUtil.findInv(Items.TOTEM_OF_UNDYING);
			if(totem != -1) {
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.PICKUP, mc.player);
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 0, ClickType.PICKUP, mc.player);
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.PICKUP, mc.player);
			}
		}
	}
	
	@Override
	public void onFastUpdate() {
		if(mode.getValue().equalsIgnoreCase("Fast")) {
			if(Null()) return;
			if(mc.currentScreen instanceof GuiContainer) return;
			if(mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) return;
			
			int totem = InventoryUtil.findInv(Items.TOTEM_OF_UNDYING);
			if(totem != -1) {
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.PICKUP, mc.player);
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 0, ClickType.PICKUP, mc.player);
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.PICKUP, mc.player);
			}
		}
	}
	
}
