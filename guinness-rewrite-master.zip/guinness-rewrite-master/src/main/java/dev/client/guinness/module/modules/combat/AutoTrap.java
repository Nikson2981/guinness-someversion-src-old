package dev.client.guinness.module.modules.combat;

import com.mojang.realmsclient.gui.ChatFormatting;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class AutoTrap extends ClientModule {
	private SInteger timeoutticks = new SInteger("Timeout", 1, 18, 30);
	public AutoTrap() {
		super("AutoTrap", ModuleCategory.COMBAT);
		addSetting(timeoutticks);
	}
	
	int timeout = 0;
	
	@Override
	public void onUpdate() {
		if(Null()) {
			this.disable();
			return;
		}
		timeout++;
		if(timeout >= timeoutticks.getValue()) {
			this.disable();
			return;
		}
		EntityPlayer target = (EntityPlayer) ModuleUtil.getActualClosestPlayerLOL();
		if(target == null || mc.player.getDistance(target) > 6) return;
		int obsidian = InventoryUtil.find(Blocks.OBSIDIAN);
		if(obsidian == -1) {
			MessageUtil.sendClientMessage(ChatFormatting.BLUE + "[AutoTrap] " + ChatFormatting.RESET + "No Obsidian!");
			this.disable();
			return;
		}
		int delay = 0;
		for(Vec3d vec : sides) {
			BlockPos targetedBlock = new BlockPos(target.getPositionVector().add(vec));
			if(mc.world.getBlockState(targetedBlock).getMaterial().isReplaceable()) {
				int oldSlot = mc.player.inventory.currentItem;
				mc.player.inventory.currentItem = obsidian;
				ModuleUtil.placeBlock(targetedBlock, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
				mc.player.inventory.currentItem = oldSlot;
				delay++;
				if(delay == 1) return;
			}
		}
		
		BlockPos top1 = new BlockPos(target.getPositionVector()).add(1, 2, 0);
		BlockPos top2 = new BlockPos(target.getPositionVector()).add(0, 2, 1);
		BlockPos top3 = new BlockPos(target.getPositionVector()).add(-1, 2, 0);
		BlockPos top4 = new BlockPos(target.getPositionVector()).add(0, 2, -1);
		
		if(!mc.world.getBlockState(top1).getMaterial().isReplaceable() && mc.world.getBlockState(new BlockPos(target.getPositionVector()).add(0, 2, 0)).getMaterial().isReplaceable()) {
			int oldSlot = mc.player.inventory.currentItem;
			mc.player.inventory.currentItem = obsidian;
			ModuleUtil.placeBlock(top1, EnumFacing.WEST, false, EnumHand.MAIN_HAND);
			mc.player.inventory.currentItem = oldSlot;
		} else if(!mc.world.getBlockState(top2).getMaterial().isReplaceable() && mc.world.getBlockState(new BlockPos(target.getPositionVector()).add(0, 2, 0)).getMaterial().isReplaceable()) {
			int oldSlot = mc.player.inventory.currentItem;
			mc.player.inventory.currentItem = obsidian;
			ModuleUtil.placeBlock(top2, EnumFacing.EAST, false, EnumHand.MAIN_HAND);
			mc.player.inventory.currentItem = oldSlot;
		} else if(!mc.world.getBlockState(top3).getMaterial().isReplaceable() && mc.world.getBlockState(new BlockPos(target.getPositionVector()).add(0, 2, 0)).getMaterial().isReplaceable()) {
			int oldSlot = mc.player.inventory.currentItem;
			mc.player.inventory.currentItem = obsidian;
			ModuleUtil.placeBlock(top1, EnumFacing.SOUTH, false, EnumHand.MAIN_HAND);
			mc.player.inventory.currentItem = oldSlot;
		} else if(!mc.world.getBlockState(top4).getMaterial().isReplaceable() && mc.world.getBlockState(new BlockPos(target.getPositionVector()).add(0, 2, 0)).getMaterial().isReplaceable()) {
			int oldSlot = mc.player.inventory.currentItem;
			mc.player.inventory.currentItem = obsidian;
			ModuleUtil.placeBlock(top1, EnumFacing.NORTH, false, EnumHand.MAIN_HAND);
			mc.player.inventory.currentItem = oldSlot;
		}
	}
	
	@Override
	public void onDisable() {
		timeout = 0;
	}
	
	private Vec3d[] sides = new Vec3d[] {
			new Vec3d(1, -1, 0),
			new Vec3d(0, -1, 1),
			new Vec3d(-1, -1, 0),
			new Vec3d(0, -1, -1),
			new Vec3d(1, 0, 0),
			new Vec3d(0, 0, 1),
			new Vec3d(-1, 0, 0),
			new Vec3d(0, 0, -1),
			new Vec3d(1, 1, 0),
			new Vec3d(0, 1, 1),
			new Vec3d(-1, 1, 0),
			new Vec3d(0, 1, -1),
			new Vec3d(1, 2, 0),
			new Vec3d(0, 2, 1),
			new Vec3d(-1, 2, 0),
			new Vec3d(0, 2, -1),
	};

}
