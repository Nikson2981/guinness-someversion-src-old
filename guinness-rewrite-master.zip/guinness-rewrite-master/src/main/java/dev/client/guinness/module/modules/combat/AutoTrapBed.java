package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class AutoTrapBed extends ClientModule {
	
	public AutoTrapBed() {
		super("AutoTrapBed", ModuleCategory.COMBAT);
	}
	
	@Override
	public void onEnable() {
		if(Null()) {
			this.disable();
			return;
		}
		int currentSlot = mc.player.inventory.currentItem;
		int obsidian = InventoryUtil.find(Blocks.OBSIDIAN);
		EntityPlayer closestPlayer = (EntityPlayer) ModuleUtil.getActualClosestPlayerLOL();
		if(obsidian != -1) {
			mc.player.inventory.currentItem = obsidian;
			ModuleUtil.placeBlock(new BlockPos(closestPlayer.getPositionVector()).add(0, 3, 0), EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
			mc.player.inventory.currentItem = currentSlot;
			this.disable();
		} else {
			MessageUtil.sendClientMessage("No obsidian!");
			this.disable();
		}
	}
}
