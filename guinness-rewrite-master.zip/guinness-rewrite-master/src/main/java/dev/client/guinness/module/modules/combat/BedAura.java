package dev.client.guinness.module.modules.combat;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;

import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SDouble;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.ModuleUtil;
import dev.client.guinness.util.render.RenderUtil;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBed;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.tileentity.TileEntityBed;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BedAura extends ClientModule {
	private SMode mode = new SMode("Mode", "Place/Break", "Break Only");
	private SDouble range = new SDouble("Range", 1.0D, 8.0D, 10.0D, 1);
	private SInteger delay = new SInteger("Place Delay", 1, 13, 20);
	private SBoolean render = new SBoolean("Render", true);
	
	public BedAura() {
		super("BedAura", ModuleCategory.COMBAT);
		addSetting(mode);
		addSetting(range);
		addSetting(delay);
		addSetting(render);
	}
	
	private int originBedSlot;
	private BlockPos placeTarget;
	private EntityPlayer bestTarget;
	
	@Override
	public void onUpdate() {
		if(Null()) return;

		if(mc.player.dimension == 0) {
			MessageUtil.sendClientMessage("You are in the overworld! Disabling...");
			this.disable();
		}
		this.originBedSlot = this.findBedInHotbar();
		this.findbestTarget();
		if(bestTarget != null) {
			if(mc.player.ticksExisted % 2 == 0) {
				detonateBeds();
			}
			if((mc.player.ticksExisted % delay.getValue() == 0) && mc.player.getDistance(bestTarget) <= range.getValue()) {
				placeTarget = getViableTargets(bestTarget.getPositionVector());
				this.moveBedFromInventory();
				this.doBedAura();
				this.moveBedFromInventory();
				mc.player.ticksExisted++;
				
			}
			
		} else return;

	}
	
	@SubscribeEvent
    public void onRenderWorld(RenderWorldLastEvent event) {
		if(!render.getValue()) return;
		mc.world.loadedTileEntityList.stream()
		.filter(t -> t instanceof TileEntityBed)
		.forEach(t -> {
			//RenderUtil.drawBoundingBoxBlockPos(t.getPos(), -0.4355, new Color(FinalColor.BESTCOLOR(255, 0)));
		});

		if(placeTarget != null && bestTarget != null && mc.player.getDistanceSq(placeTarget) <= range.getValue()*range.getValue()) {
			if (mc.world.getBlockState(placeTarget.add(0, -1, 0)).getBlock() instanceof BlockAir || mc.world.getBlockState(placeTarget.add(0, -1, 0)).getBlock() instanceof BlockLiquid || mc.world.getBlockState(placeTarget.add(0, -1, 0)).getBlock() instanceof BlockFire || mc.world.getBlockState(placeTarget.add(0, -1, 0)).getBlock() instanceof BlockBed) {
				RenderUtil.drawBoundingBoxBlockPos(placeTarget.add(0, -1, 0), -0.4355, new Color(FinalColor.BESTCOLOR(255, 0)));
				RenderUtil.drawBoundingBoxBlockPos(placeTarget.add(0, -1, 0).offset(EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(placeTarget, new BlockPos(bestTarget.getPositionVector())))), -0.4355, new Color(FinalColor.BESTCOLOR(255, 0)));
			} else {
			RenderUtil.drawBoundingBoxBlockPos(placeTarget, -0.4355, new Color(FinalColor.BESTCOLOR(255, 0)));
			RenderUtil.drawBoundingBoxBlockPos(placeTarget.add(0, -1, 0).offset(EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(placeTarget, new BlockPos(bestTarget.getPositionVector())))), -0.4355, new Color(FinalColor.BESTCOLOR(255, 0)));
			}
		}

	}
	
	public void doBedAura() {
		for (int i = 0; i < 9; i++) {
            if (originBedSlot != -1) {
                break;
            }
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.getItem() instanceof ItemBed) {
                	mc.player.inventory.currentItem = i;
                break;
            }
		}
		if(originBedSlot != -1) {
		mc.player.inventory.currentItem = originBedSlot;
		}
		if(mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem).getItem() instanceof ItemBed) {
			mc.player.connection.sendPacket(new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.START_SNEAKING));
			ModuleUtil.rotateBedPacket(placeTarget, new BlockPos(bestTarget.getPositionVector()));
			ModuleUtil.placeBlock(placeTarget, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
			mc.player.connection.sendPacket(new CPacketEntityAction((Entity)mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
		}
	}
	
	public BlockPos getViableTargets(Vec3d target) {
		BlockPos[] placeablePos =
		   {
			new BlockPos(target.x, target.y, target.z).add(1, 1, 0),
			new BlockPos(target.x, target.y, target.z).add(-1, 1, 0),
			new BlockPos(target.x, target.y, target.z).add(0, 1, 1),
			new BlockPos(target.x, target.y, target.z).add(0, 1, -1),
			new BlockPos(target.x, target.y, target.z).add(1, 0, 0),
			new BlockPos(target.x, target.y, target.z).add(-1, 0, 0),
			new BlockPos(target.x, target.y, target.z).add(0, 0, 1),
			new BlockPos(target.x, target.y, target.z).add(0, 0, -1),
			new BlockPos(target.x, target.y, target.z).add(1, 2, 0),
			new BlockPos(target.x, target.y, target.z).add(-1, 2, 0),
			new BlockPos(target.x, target.y, target.z).add(0, 2, 1),
			new BlockPos(target.x, target.y, target.z).add(0, 2, -1)};
		for(int i = 0; i < 13; i++) {
			if(canPlaceBed(placeablePos[i])) {
				BlockPos viablePos = placeablePos[i];
				if(mc.world.getBlockState(viablePos).getBlock() instanceof BlockAir || mc.world.getBlockState(viablePos).getBlock() instanceof BlockLiquid) {
					return viablePos.add(0, 1, 0);
				}
				return viablePos;
			}
			
		}
		return null;
	}
	
	public void detonateBeds() {
		mc.world.loadedTileEntityList.stream()
        .filter(e -> e instanceof TileEntityBed)
        .filter(e -> mc.player.getDistance(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()) <= range.getValue())
        .sorted(Comparator.comparing(e -> mc.player.getDistance(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ())))
        .forEach(bed -> {
        	if(mc.player.dimension != 0) {
            mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(bed.getPos(), EnumFacing.UP, EnumHand.OFF_HAND, 0, 0, 0));
        	}
        });
	}
	
	public boolean canPlaceBed(BlockPos pos) {
		return (mc.world.getBlockState(pos).getBlock() == Blocks.AIR || mc.world.getBlockState(pos).getBlock() == Blocks.BED) &&
    			mc.world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(pos.add(0, -0.5, 0))).isEmpty() &&
    			mc.world.getEntitiesWithinAABB(EntityEnderCrystal.class, new AxisAlignedBB(pos.add(0, -0.5, 0))).isEmpty() &&
    			mc.world.getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(pos.add(0, -0.5, 0))).isEmpty();	
	}
	
	public void moveBedFromInventory() {
		if (mc.currentScreen == null || !(mc.currentScreen instanceof GuiContainer)) {
            if (mc.player.inventory.getStackInSlot(0).getItem() != Items.BED) {
               for(int i = 9; i < 36; ++i) {
                  if (mc.player.inventory.getStackInSlot(i).getItem() == Items.BED) {
                	  if(originBedSlot != -1) {
                		 mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, originBedSlot, ClickType.SWAP, mc.player);
                	  } else {
                		  mc.playerController.windowClick(mc.player.inventoryContainer.windowId, i, 0, ClickType.SWAP, mc.player);
                	  }
                     break;
                  }
               }
            }
         }
	}
	
	private void findbestTarget() {
        List<EntityPlayer> playerList = mc.world.playerEntities;
        bestTarget = null;
        for (EntityPlayer target : playerList) {
            if (target == mc.player) {
                continue;
            }
            if (FriendUtil.isFriend(target.getName())) {
                continue;
            }
            if (!(target instanceof EntityLivingBase)) {
                continue;
            }
            if ((target).getHealth() <= 0) {
                continue;
            }
            if (bestTarget == null) {
                bestTarget = target;
                continue;
            }
            if (mc.player.getDistance(target) < mc.player.getDistance(bestTarget)) {
                bestTarget = target;
            }
        }
    }
	
	public int findBedInHotbar() {
		int slot = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof Item)) {
                continue;
            }
            Item item = ((Item) stack.getItem());
            if (item instanceof ItemBed) {
                slot = i;
                break;
            }
        }
        return slot;
	}
	
}
