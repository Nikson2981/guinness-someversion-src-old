package dev.client.guinness.module.modules.combat;

import dev.client.guinness.event.events.PacketEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.LinkedList;

public class Blink extends ClientModule {
    public Blink() {
        super("Blink", ModuleCategory.COMBAT);
        INSTANCE = this;
    }

    private static Blink INSTANCE;

    public static Blink getInstance() {
        return INSTANCE;
    }

    private final LinkedList<Packet<?>> packetQueue = new LinkedList<>();
    private boolean sending = false;

    public BlockPos startPos = BlockPos.ORIGIN, endPos = BlockPos.ORIGIN;

    public BlockPos getStartPos() {
        return startPos;
    }

    public BlockPos getEndPos() {
        return endPos;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        MessageUtil.sendClientMessage("Blink Enabled");
        packetQueue.clear();
        sending = false;
        startPos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.PacketSendEvent event) {
        if (!sending && event.getPacket() instanceof CPacketPlayer) {
            CPacketPlayer packet = (CPacketPlayer) event.getPacket();
            event.setCanceled(true);
            packetQueue.add(packet);
        }
    }

    @Override
    public void onDisable() {
        super.onDisable();
        MessageUtil.sendClientMessage("Blink Disabled");
        sending = true;
        while (!packetQueue.isEmpty()) mc.player.connection.sendPacket(packetQueue.poll());
        sending = false;
        endPos = mc.player.getPosition();
        CombatAnnouncer.getInstance().shouldCheckBlink = true;
    }
}
