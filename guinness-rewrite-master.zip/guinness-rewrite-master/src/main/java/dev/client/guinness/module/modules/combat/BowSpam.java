package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import net.minecraft.item.ItemBow;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.math.BlockPos;

public class BowSpam extends ClientModule {

	public BowSpam() {
		super("BowSpam", ModuleCategory.COMBAT);
	}
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		if(mc.player.getHeldItemMainhand().getItem() instanceof ItemBow
				&& mc.player.isHandActive()
				&& mc.player.getItemInUseMaxCount() >=3) {
				mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM,
				BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
				
				mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(mc.player.getActiveHand()));
				mc.player.stopActiveHand();
		}
	}
	
}
