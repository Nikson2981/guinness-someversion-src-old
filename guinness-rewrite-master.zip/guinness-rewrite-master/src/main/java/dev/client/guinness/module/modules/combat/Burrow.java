package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class Burrow extends ClientModule {
	
	public Burrow() {
		super("Burrow", ModuleCategory.COMBAT);
	}
	
	BlockPos originalPos;

    @Override
    public void onEnable() {
        if (Null())
            return;

        originalPos = new BlockPos(mc.player.posX, mc.player.posY, mc.player.posZ);

        mc.player.jump();
    }

    @Override
    public void onUpdate() {
        if (mc.player.posY > originalPos.getY() + 1.2) {
            final int oldSlot = mc.player.inventory.currentItem;
            mc.player.inventory.currentItem = InventoryUtil.find(Blocks.OBSIDIAN);

            ModuleUtil.placeBlock(originalPos, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
            mc.player.inventory.currentItem = oldSlot;

            mc.player.jump();

            this.disable();
        }
    }

}
