package dev.client.guinness.module.modules.combat;

import dev.client.guinness.*;
import dev.client.guinness.event.events.*;
import dev.client.guinness.gui.main.*;
import dev.client.guinness.module.*;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.util.client.*;
import dev.client.guinness.util.module.*;
import dev.client.guinness.util.render.*;
import net.minecraft.block.*;
import net.minecraft.client.audio.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.settings.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.network.play.server.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraftforge.client.event.*;
import net.minecraftforge.fml.common.eventhandler.*;

import java.util.*;

@SuppressWarnings("ALL") // fuck you intellij
public class CombatAnnouncer extends ClientModule {

    public static SBoolean text = new SBoolean("Text", true), sound = new SBoolean("Sound", false);

    public CombatAnnouncer() {
        super("CombatAnnouncer", ModuleCategory.COMBAT);
        this.warningTimer = new TimerUtils();
        this.blinkTimer = new TimerUtils();
        this.alarmTimer = new TimerUtils();
        addSetting(text);
        addSetting(sound);
        INSTANCE = this;
    }

    public final ResourceLocation LOGO = new ResourceLocation("guinness:textures/logo.png");

    private static CombatAnnouncer INSTANCE;

    public static CombatAnnouncer getInstance() {
        return INSTANCE;
    }

    private final TimerUtils
            warningTimer,
            alarmTimer,
            blinkTimer;

    public boolean
            shouldCheckSurround = false,
            shouldCheckBlink = false,
            isTotemWarningActive = false,
            failedBlink = false,
            failingSurround = false,
            lowTotems = false;

    public String
            healthLevelWarning = "Stable",
            surroundState = "disabled";


    private int colour;

    private EntityPlayer closestTarget = null;


    public void onUpdate() {
        if (Null()) return;

        // if (shouldCheckSurround) checkSurround();
        if (shouldCheckBlink) checkBlink();
        checkHealth();
        checkTotems();
        colour = mc.player.getHealth() + mc.player.getAbsorptionAmount() > 20.0F ? 2158832 : MathHelper.hsvToRGB((mc.player.getHealth() + mc.player.getAbsorptionAmount()) / 20.0F / 3.0F, 1.0F, 1.0F);

        if (!shouldCheckBlink) blinkTimer.reset();
        checkTotemPopWarning();

        if (isTotemWarningActive && alarmTimer.passedS(.95)) {
            if (sound.getValue()) mc.getSoundHandler().playSound(PositionedSoundRecord.getRecord(SoundUtil.GUINNESS_UI_ALARM, 1.0F, 1F));
            alarmTimer.reset();
        }
    }


    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        if (mc.currentScreen instanceof GuinnessGui) return;
        closestTarget = ModuleUtil.getClosestEnemy();

        int height = 30;
        Guinness.blu3Font.drawStringWithShadow("Health condition: " + healthLevelWarning, 30, height, colour);
        height += 13;
       /* Guinness.blu3Font.drawStringWithShadow("Surround: " + surroundState, 30, height, ColorUtil.rainbow(1, 255));
        height += 10;*/
        if (failedBlink) {
            if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Warning: failed Blink", 30, height, ColorUtil.rainbow(1, 255));
            height += 10;
        }
        if (lowTotems) {
            if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Warning: low totems", 30, height, ColorUtil.rainbow(1, 255));
            height += 10;
        }
        if (isTotemWarningActive) {
            if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Warning: popped totem", 30, height, MathHelper.hsvToRGB(1 / 20.0F / 3.0F, 1.0F, 1.0F));
            height += 30;
        }

        // this might not work idk
        if (closestTarget != null) {
            if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Closest target: " + closestTarget.getName(), 30, height, 0xFF00FFFF);
            if (!checkTargetArmour(closestTarget)[0]) {
                if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Target is missing a helmet", 30, height, 0xFF00FFFF);
                height += 10;
            }
            if (!checkTargetArmour(closestTarget)[1]) {
                if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Target is missing a chestplate", 30, height, 0xFF00FFFF);
                height += 10;
            }
            if (!checkTargetArmour(closestTarget)[2]) {
                if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Target is missing leggings", 30, height, 0xFF00FFFF);
                height += 10;
            }
            if (!checkTargetArmour(closestTarget)[3]) {
                if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("Target is missing boots", 30, height, 0xFF00FFFF);
                height += 10;
            }
        } else {
            if (text.getValue()) Guinness.blu3Font.drawStringWithShadow("No potential targets in range.", 30, height, 0xFF00FFFF);
            height += 10;
        }

        renderArmourOverlay();
        // blu3Tesselator.drawPolygon(new TesselatorVec2i(50, 50), new TesselatorVec2i(110, 70), new TesselatorVec2i(70, 130), new TesselatorVec2i(130, 120), ColorUtil.rainbow(1, 255));
        // renderLogo();
    }

    public void renderLogo() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int x = 1, y = scaledResolution.getScaledHeight() - 141;
        mc.getTextureManager().bindTexture(LOGO);
        blu3Tesselator.drawPolygonWithCustomSizedTexture(new Vec2i(50, 50), new Vec2i(110, 70), new Vec2i(70, 130), new Vec2i(130, 120), 220, 141);
    }

    public void renderArmourOverlay() {
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int x = (scaledResolution.getScaledWidth() / 2) + 10, y = scaledResolution.getScaledHeight() - 55, i = 0, hy = y - 18, cy = y - 18, ly = y - 18, by = y - 18;
        final List<ItemStack> armor = new ArrayList<>();
        for (final ItemStack is : mc.player.getArmorInventoryList()) { armor.add(is); }
        Collections.reverse(armor);
        for (final ItemStack is : armor) {
            final int xx = (x + i);
            RenderHelper.enableGUIStandardItemLighting();
            mc.getRenderItem().renderItemAndEffectIntoGUI(is, xx, y);
            mc.getRenderItem().renderItemOverlays(mc.fontRenderer, is, xx, y);
            RenderHelper.disableStandardItemLighting();
            i += 18;
        }
        for (int helmets = 0; helmets < (armor.get(0).getItem() == Items.AIR ? getArmour()[0] : getArmour()[0] - 1); helmets++) {
            RenderHelper.enableGUIStandardItemLighting();
            mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.DIAMOND_HELMET), x, hy);
            mc.getRenderItem().renderItemOverlays(mc.fontRenderer, new ItemStack(Items.DIAMOND_HELMET), x, hy);
            RenderHelper.disableStandardItemLighting();
            hy -= 18;
        }
        x += 18;
        for (int chestPlates = 0; chestPlates < (armor.get(1).getItem() == Items.AIR ? getArmour()[1] : getArmour()[1] - 1); chestPlates++) {
            RenderHelper.enableGUIStandardItemLighting();
            mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.DIAMOND_CHESTPLATE), x, cy);
            mc.getRenderItem().renderItemOverlays(mc.fontRenderer, new ItemStack(Items.DIAMOND_CHESTPLATE), x, cy);
            RenderHelper.disableStandardItemLighting();
            cy -= 18;
        }
        x += 18;
        for (int leggings = 0; leggings < (armor.get(2).getItem() == Items.AIR ? getArmour()[2] : getArmour()[2] - 1); leggings++) {
            RenderHelper.enableGUIStandardItemLighting();
            mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.DIAMOND_LEGGINGS), x, ly);
            mc.getRenderItem().renderItemOverlays(mc.fontRenderer, new ItemStack(Items.DIAMOND_LEGGINGS), x, ly);
            RenderHelper.disableStandardItemLighting();
            ly -= 18;
        }
        x += 18;
        for (int boots = 0; boots < (armor.get(3).getItem() == Items.AIR ? getArmour()[3] : getArmour()[3] - 1); boots++) {
            RenderHelper.enableGUIStandardItemLighting();
            mc.getRenderItem().renderItemAndEffectIntoGUI(new ItemStack(Items.DIAMOND_BOOTS), x, by);
            mc.getRenderItem().renderItemOverlays(mc.fontRenderer, new ItemStack(Items.DIAMOND_BOOTS), x, by);
            RenderHelper.disableStandardItemLighting();
            by -= 18;
        }
    }

    public void checkSurround() {
        //TODO: add surround
        if (failingSurround) {
            int pickaxe = InventoryUtil.find(Items.DIAMOND_PICKAXE);
            int chorus = InventoryUtil.find(Items.CHORUS_FRUIT);

            if (mc.world.getBlockState(mc.player.getPosition().down()).getBlock() instanceof BlockObsidian && pickaxe != -1) {
                surroundState = "Warning: Surround failure - digging down";
                mc.player.inventory.currentItem = pickaxe;
                mc.player.rotationPitch = 0;
                mc.playerController.onPlayerDamageBlock(mc.player.getPosition().down(), EnumFacing.DOWN);
            } else if (chorus != -1) {
                surroundState = "Warning: Surround failure - attempting chorus getaway";
                mc.player.inventory.currentItem = chorus;
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
            } else surroundState = "Danger: total Surround failure -  survival unlikely";
        }
    }

    public boolean[] checkTargetArmour(EntityPlayer player) {
        boolean helmet = false, chestPlate = false, leggings = false, boots = false;
        final List<ItemStack> armor = new ArrayList<>();
        for (final ItemStack is : player.getArmorInventoryList()) {
            armor.add(is);
        }
        Collections.reverse(armor);
        if (InventoryUtil.helmets.contains((armor.get(0).getItem()))) {
            helmet = true;
        }
        if (InventoryUtil.chestPlates.contains((armor.get(1).getItem()))) {
            chestPlate = true;
        }
        if (InventoryUtil.leggings.contains((armor.get(1).getItem()))) {
            leggings = true;
        }
        if (InventoryUtil.boots.contains((armor.get(1).getItem()))) {
            boots = true;
        }
        return new boolean[]{
                helmet, chestPlate, leggings, boots
        };
    }

    public void checkBlink() {
        BlockPos startPos = Blink.getInstance().getStartPos();
        if (startPos == null) return;
        if (!failedBlink && blinkTimer.passedS(0.3) && mc.player.getDistance(startPos.getX(), startPos.getY(), startPos.getZ()) < 2) {
            failedBlink = true;
        }
        if (blinkTimer.passedS(4)) {
            failedBlink = false;
            Blink.getInstance().startPos = null;
        }
    }

    public void checkHealth() {
        float health = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (health < 20 && health >= 16) {
            healthLevelWarning = "Stable";
        } else if (health < 16 && mc.player.getHealth() >= 10) {
            healthLevelWarning = "Healing Recommended";
        } else if (health < 10 && mc.player.getHealth() >= 5) {
            healthLevelWarning = "Low";
        } else if (health < 5) {
            healthLevelWarning = "Critical";
        } else if (health >= 21) {
            healthLevelWarning = "Overhealed";
        }
    }

    public void checkTotems() {
        lowTotems = getTotems() <= 2;
    }

    public void checkTotemPopWarning() {
        isTotemWarningActive = !warningTimer.passedS(6);
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.PacketReceiveEvent event) {
        if (event.getPacket() instanceof SPacketEntityStatus) {
            SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();
            if (packet.getOpCode() == 35 && packet.getEntity(mc.world).equals(mc.player)) {
                warningTimer.reset();
            }
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    private int getTotems() {
        int c = 0;
        for (int i = 0; i < 45; ++i) {
            if (this.mc.player.inventory.getStackInSlot(i).getItem() == Items.TOTEM_OF_UNDYING) {
                ++c;
            }
        }
        return c;
    }

    private int[] getArmour() {
        return new int[]{
                getArmourType(InventoryUtil.helmets),
                getArmourType(InventoryUtil.chestPlates),
                getArmourType(InventoryUtil.leggings),
                getArmourType(InventoryUtil.boots)
        };
    }

    private int getArmourType(List<Item> itemList) {
        int c = 0;
        for (Item item : itemList) {
            for (int i = 0; i < 45; ++i) {
                if (this.mc.player.inventory.getStackInSlot(i).getItem() == item) {
                    ++c;
                }
            }
        }
        return c;
    }
}
