package dev.client.guinness.module.modules.combat;

import java.util.Objects;

import dev.client.guinness.event.events.PacketEvent.PacketSendEvent;
import dev.client.guinness.module.ClientModule;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Criticals extends ClientModule {
	
	public Criticals() {
		super("Criticals", ModuleCategory.COMBAT);
	}

	@SubscribeEvent
	public void onPacketSend(PacketSendEvent event){
		if (Null()) return;
		if (event.getPacket() instanceof CPacketUseEntity && ((CPacketUseEntity) event.getPacket()).getAction() == CPacketUseEntity.Action.ATTACK && mc.player.onGround) {
			final CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
			mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.1625, mc.player.posZ, false));
            mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
            mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 4.0E-6, mc.player.posZ, false));
            mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
            mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.0E-6, mc.player.posZ, false));
            mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
            mc.player.connection.sendPacket((Packet<?>)new CPacketPlayer());
            mc.player.onCriticalHit((Entity)Objects.requireNonNull(packet.getEntityFromWorld((World)mc.world)));
		}
	}
	
}
