package dev.client.guinness.module.modules.combat;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SDouble;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;

/**
 * @author Reap
 */

public class Offhand extends ClientModule {
	public SMode mode = new SMode("Mode", "Totem", "Crystal", "Gapple");
	public SBoolean stopInGUI = new SBoolean("Stop in GUI", false);
	public SBoolean swordGap = new SBoolean("SwordGap", false);
	public SDouble minHealth = new SDouble("Health", 0.5D, 18.0D, 36.0D, 1);
	public Offhand() {
		super("Offhand", ModuleCategory.COMBAT);
		addSetting(mode);
		addSetting(stopInGUI);
		addSetting(swordGap);
		addSetting(minHealth);
	}
	
	@Override public void onUpdate() {
        if (mc.player == null || mc.world == null) return;
        if (stopInGUI.getValue() && mc.currentScreen != null) return;

        int itemSlot = getItemSlot();
        if (itemSlot == -1) return;

        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, itemSlot, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 45, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, itemSlot, 0, ClickType.PICKUP, mc.player);
    }

    private int getItemSlot() {
        Item itemToSearch = Items.TOTEM_OF_UNDYING;

        if (!(mc.player.getHealth() + mc.player.getAbsorptionAmount() <= minHealth.getValue())) {
            if (swordGap.getValue() && (mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_SWORD) && !ModuleUtil.is32k(mc.player.getHeldItemMainhand())) {
                itemToSearch = Items.GOLDEN_APPLE;
            } else {
                switch (mode.getValue()) {
                    case "Crystal":
                        itemToSearch = Items.END_CRYSTAL;
                        break;
                    case "Gapple":
                        itemToSearch = Items.GOLDEN_APPLE;
                        break;
                    case "Bed":
                        itemToSearch = Items.BED;
                        break;
                }
            }
        }

        if (mc.player.getHeldItemOffhand().getItem().equals(itemToSearch)) {
            return -1;
        }

        for (int i = 9; i < 36; i++) {
            if (mc.player.inventory.getStackInSlot(i).getItem() == itemToSearch) {
                return i < 9 ? i + 36 : i;
            }
        }

        return -1;
    }

}
