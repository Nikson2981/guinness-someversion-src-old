package dev.client.guinness.module.modules.combat;

import java.util.List;

import com.mojang.realmsclient.gui.ChatFormatting;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.common.MinecraftForge;

public class PacketAutoCity extends ClientModule {
	public PacketAutoCity() {
		super("PacketAutoCity", ModuleCategory.COMBAT);
	}
	
	private boolean firstRun;
	private BlockPos mineTarget = null;
	private EntityPlayer closestTarget;
	
	@Override
	public void onEnable() {
		if(mc.player == null) {
			this.toggle();
			return;
		}
		MinecraftForge.EVENT_BUS.register(this);
		firstRun = true;
	}
	
	@Override
	public void onDisable() {
		if(mc.player == null) {
			return;
		}
		MinecraftForge.EVENT_BUS.unregister(this);
	}
	
	@Override
    public void onUpdate() {
		if(mc.player == null) {
			return;
		}
		findClosestTarget();

        if (closestTarget == null) {
            if (firstRun) {
                firstRun = false;
                MessageUtil.sendClientMessage(TextFormatting.BLUE + "[" + TextFormatting.RESET + "AutoCity" + TextFormatting.BLUE + "]" + ChatFormatting.WHITE.toString() + "Enabled" + ChatFormatting.RESET.toString() + ", no one to city!"); 
            }
            this.toggle();
            return;
        }
        
        if (firstRun && mineTarget != null) {
            firstRun = false;
        }
        
        findCityBlock();
        if(mineTarget != null) {
        	int newSlot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack stack = mc.player.inventory.getStackInSlot(i);
                if (stack == ItemStack.EMPTY) {
                    continue;
                }
                if ((stack.getItem() instanceof ItemPickaxe)) {
                    newSlot = i;
                    break;
                }
            }
            if (newSlot != -1) {
                mc.player.inventory.currentItem = newSlot;
            }
        	mc.player.swingArm(EnumHand.MAIN_HAND);
        	mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, mineTarget, EnumFacing.DOWN));
        	mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, mineTarget, EnumFacing.DOWN));
        	this.toggle();
        } else {
        	MessageUtil.sendClientMessage(TextFormatting.BLUE + "[" + TextFormatting.RESET + "AutoCity" + TextFormatting.BLUE + "]" + " No city blocks to mine!");
        	this.toggle();
        }
        
	}
	
	public BlockPos findCityBlock() {
		Double dist = 7d;
		Vec3d vec = closestTarget.getPositionVector();
		if(mc.player.getPositionVector().distanceTo(vec) <= dist) {
			BlockPos targetX = new BlockPos(vec).add(1, 0, 0);
			BlockPos targetXMinus = new BlockPos(vec).add(-1, 0, 0);
			BlockPos targetZ = new BlockPos(vec).add(0, 0, 1);
			BlockPos targetZMinus = new BlockPos(vec).add(0, 0, -1);
			if(canBreak(targetX)) {
				mineTarget = targetX;
			}
			if(!canBreak(targetX) && canBreak(targetXMinus)) {
				mineTarget = targetXMinus;
			}
			if(!canBreak(targetX) && !canBreak(targetXMinus) && canBreak(targetZ)) {
				mineTarget = targetZ;
			}
			if(!canBreak(targetX) && !canBreak(targetXMinus) && !canBreak(targetZ) && canBreak(targetZMinus)) {
				mineTarget = targetZMinus;
			}
			if((!canBreak(targetX) && !canBreak(targetXMinus) && !canBreak(targetZ) && !canBreak(targetZMinus)) || mc.player.getPositionVector().distanceTo(vec) > dist) {
				mineTarget = null;
			} 
		}
		return mineTarget;
	}
	
	private boolean canBreak(BlockPos pos) {
		final IBlockState blockState = mc.world.getBlockState(pos);
		final Block block = blockState.getBlock();
		return block.getBlockHardness(blockState, mc.world, pos) != -1 || !block.getLocalizedName().equalsIgnoreCase("air");
	}
	
	private void findClosestTarget() {
    	List<EntityPlayer> playerList = mc.world.playerEntities;

        closestTarget = null;

        for (EntityPlayer target : playerList) {

            if (target == mc.player) {
                continue;
            }

            if (FriendUtil.isFriend(target.getName())) {
                continue;
            }

            if (!isLiving(target)) {
                continue;
            }

            if ((target).getHealth() <= 0) {
                continue;
            }

            if (closestTarget == null) {
                closestTarget = target;
                continue;
            }

            if (mc.player.getDistance(target) < mc.player.getDistance(closestTarget)) {
                closestTarget = target;
            }

        }

    }
	
	public static boolean isLiving(Entity e) {
        return e instanceof EntityLivingBase;
    }

}
