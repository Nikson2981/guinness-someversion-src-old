package dev.client.guinness.module.modules.combat;

import java.util.Arrays;
import java.util.List;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;

public class PistonAura extends ClientModule {
	private SBoolean debug = new SBoolean("Debug", true);
    private SInteger delay = new SInteger("Delay", 3, 10, 18);
    public PistonAura() {
        super("PistonAura", ModuleCategory.COMBAT);
        addSetting(delay);
        addSetting(debug);
    }

    int piston = -1;
    int redstone = -1;
    int crystal = -1;
    int restticks = 0;
    boolean readytobreak = false;

    @Override
    public void onEnable() {
        if(Null()) return;
        readytobreak = false;
        piston = InventoryUtil.find(Blocks.PISTON);
        redstone = InventoryUtil.find(Blocks.REDSTONE_BLOCK);
        crystal = InventoryUtil.find(Items.END_CRYSTAL);
        restticks = 0;
        if(piston == -1 || redstone == -1 || crystal == -1) {
            MessageUtil.sendClientMessage("Missing materials!");
            this.disable();
            return;
        }
    }

    @Override
    public void onUpdate() {
        if(Null()) return;
        EntityPlayer target = (EntityPlayer) ModuleUtil.getActualClosestPlayerLOL();
        if(mc.player.ticksExisted % delay.getValue() == 0) {
        	mc.player.ticksExisted++;
            if(target != null && this.getViablePos(target) != null) {
            	int currentslot = mc.player.inventory.currentItem;
                mc.player.inventory.currentItem = piston;
                BlockPos pistonSpot = this.placePiston(target);
                mc.player.inventory.currentItem = crystal;
                ModuleUtil.placeBlock(pistonSpot.offset(EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(pistonSpot, new BlockPos(target.getPositionVector())))), EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
                mc.player.inventory.currentItem = redstone;
                ModuleUtil.placeBlock(pistonSpot.offset(EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(pistonSpot, new BlockPos(target.getPositionVector()))).getOpposite()), EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(pistonSpot, new BlockPos(target.getPositionVector()))), false, EnumHand.MAIN_HAND);
                mc.player.inventory.currentItem = currentslot;
                this.disable();
            } else {
                if(debug.getValue()) MessageUtil.sendClientMessage("No spots to place!");
            }
        }
    }

    public BlockPos getViablePos(EntityPlayer target) {
        BlockPos[] pistonPos = {
                new BlockPos(target.getPositionVector()).add(2, 1, 0),
                new BlockPos(target.getPositionVector()).add(-2, 1, 0),
                new BlockPos(target.getPositionVector()).add(0, 1, 2),
                new BlockPos(target.getPositionVector()).add(0, 1, -2),
                new BlockPos(target.getPositionVector()).add(2, 2, 0),
                new BlockPos(target.getPositionVector()).add(-2, 2, 0),
                new BlockPos(target.getPositionVector()).add(0, 2, 2),
                new BlockPos(target.getPositionVector()).add(0, 2, -2)
        };
        return Arrays.stream(pistonPos).filter(p -> this.canPlaceSetup(p, target)).findFirst().orElse(null);
    }

    public boolean canPlaceSetup(BlockPos pos, EntityPlayer target) {
        return mc.world.getBlockState(pos).getMaterial().isReplaceable() &&
        	   !mc.world.getBlockState(pos.add(0, -1, 0)).getMaterial().isReplaceable() &&
        	   mc.world.getBlockState(pos.offset(EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(pos, new BlockPos(target.getPositionVector()))).getOpposite())).getMaterial().isReplaceable() &&
        	   this.canPlaceCrystal(pos.add(0, -1, 0).offset(EnumFacing.fromAngle(ModuleUtil.rotateBedPacket(pos.add(0, -1, 0), new BlockPos(target.getPositionVector())))));
    }

    public boolean canPlaceCrystal(BlockPos blockPos) {
        final BlockPos boost = blockPos.add(0, 1, 0);
        final BlockPos boost2 = blockPos.add(0, 2, 0);
        return (mc.world.getBlockState(blockPos).getBlock() == Blocks.BEDROCK || mc.world.getBlockState(blockPos).getBlock() == Blocks.OBSIDIAN) && mc.world.getBlockState(boost).getBlock() == Blocks.AIR && mc.world.getBlockState(boost2).getBlock() == Blocks.AIR && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(boost2)).isEmpty();
    }

    public BlockPos placePiston(EntityPlayer target) {
        BlockPos placeSpot = this.getViablePos(target);
        mc.player.connection.sendPacket(new Rotation(ModuleUtil.rotateBedPacket(placeSpot, new BlockPos(target.getPositionVector())) - 180, 0, mc.player.onGround));
        ModuleUtil.placeBlock(placeSpot, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
        return placeSpot;
    }

}
