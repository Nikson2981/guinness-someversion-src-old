package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.inventory.GuiDispenser;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;

public class Anti32k extends ClientModule {
	public Anti32k() {
		super("Anti32k", ModuleCategory.DISPENSERPVP);
	}
	
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		//if(mc.player.openContainer != null)
		//MessageUtil.sendClientMessage(mc.player.openContainer.getSlot(36).getStack().getItem().getUnlocalizedName());
		swapTotem();
		findEnemies();
	}
	
	public void swapTotem() {
		if(mc.player.inventory.getStackInSlot(0).getItem().equals(Items.TOTEM_OF_UNDYING)) return;
		
		int totem = InventoryUtil.findInv(Items.TOTEM_OF_UNDYING);
		if(totem != -1 && totem != 0) {
			if(mc.currentScreen instanceof GuiHopper){
				mc.playerController.windowClick(mc.player.openContainer.windowId, totem - 4, 0, ClickType.SWAP, mc.player);
			} else if(mc.currentScreen instanceof GuiDispenser){
				mc.playerController.windowClick(mc.player.openContainer.windowId, totem, 0, ClickType.SWAP, mc.player);
			} else if(mc.currentScreen == null || mc.currentScreen instanceof GuiInventory){
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.SWAP, mc.player);
			} else {
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.SWAP, mc.player);
			}
		} else {
			return;
		}
	}
	
	public void findEnemies() {
		int badguys = (int) mc.world.playerEntities.stream()
				.filter(p -> !FriendUtil.isFriend(p.getName()))
				.filter(p -> mc.player.getDistance(p) <= 8)
				.filter(p -> ModuleUtil.is32k(p.getHeldItemMainhand()))
				.count();
				
		if(badguys == 0) return;
		if(ModuleUtil.is32k(mc.player.itemStackMainHand)) return;
		if(ModuleManager.getModuleByClass(Auto32k.class).isEnabled()) return;
		if(ModuleManager.getModuleByClass(blu3Auto32k.class).isEnabled()) return;
		mc.player.inventory.currentItem = 0;
	}

}
