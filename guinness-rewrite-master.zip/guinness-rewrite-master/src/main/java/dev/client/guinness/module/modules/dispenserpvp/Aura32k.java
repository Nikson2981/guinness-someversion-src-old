package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.event.events.ModelBipedEvent;
import dev.client.guinness.event.events.PacketEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.module.ModuleUtil;
import dev.client.guinness.util.module.RotationManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Aura32k extends ClientModule {

	public static SBoolean rotate = new SBoolean("Rotate", false);

	public Aura32k() {
		super("32kAura", ModuleCategory.DISPENSERPVP);
		addSetting(rotate);
	}

	@Override
	public void onUpdate() {
		if(Null()) return;
		if(!ModuleUtil.is32k(mc.player.inventory.getCurrentItem())) return;
		for(EntityPlayer ep : mc.world.playerEntities) {
			if(ep == mc.player) continue;
			if(FriendUtil.isFriend(ep.getName())) continue;
			if(mc.player.getDistance(ep) <= 10 && (ep.getHealth() > 0)) {
				if (rotate.getValue())  {
					double[] rots = RotationManager.calculateLookAt(ep, mc.player);
					yaw = (float) rots[0];
					pitch = (float) rots[1];
				} else resetRotation();
				mc.player.connection.sendPacket(new CPacketUseEntity(ep));
				mc.player.swingArm(EnumHand.MAIN_HAND);
			}
		}
		if (this.isRotating) {
			if (togglePitch) {
				mc.player.rotationPitch += (float) 4.0E-4;
				togglePitch = false;
			} else {
				mc.player.rotationPitch -= (float) 4.0E-4;
				togglePitch = true;
			}
		}
	}

	private float yaw, pitch;
	public boolean isRotating, togglePitch = false;

	@SubscribeEvent
	public void renderRotations(ModelBipedEvent event) {
		if (mc.player == null || mc.world == null) return;
		if (this.isRotating) {
			event.headYaw = yaw + (mc.player.getHorizontalFacing().equals(EnumFacing.EAST) ? 90 : mc.player.getHorizontalFacing().equals(EnumFacing.SOUTH) ? 0 : mc.player.getHorizontalFacing().equals(EnumFacing.WEST) ? -90 : 180);
			event.headPitch = pitch;
		}
	}

	public void resetRotation() {
		if (isRotating) {
			yaw = mc.player.cameraYaw;
			pitch = mc.player.cameraPitch;
			this.isRotating = false;
		}
	}

	@SubscribeEvent
	public void spoofRotations(PacketEvent.PacketSendEvent event) {
		if (mc.player == null || mc.world == null) return;
		if (event.getPacket() instanceof CPacketPlayer && this.isRotating) {
			((CPacketPlayer) event.getPacket()).yaw = yaw;
			((CPacketPlayer) event.getPacket()).pitch = pitch;
		}
	}


}
