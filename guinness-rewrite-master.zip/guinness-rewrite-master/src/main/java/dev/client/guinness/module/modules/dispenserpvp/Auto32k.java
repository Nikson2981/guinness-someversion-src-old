package dev.client.guinness.module.modules.dispenserpvp;

import java.awt.Color;

import com.mojang.realmsclient.gui.ChatFormatting;

import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.module.modules.exploit.SecretClose;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import dev.client.guinness.util.render.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiDispenser;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Auto32k extends ClientModule {
	
	private SMode mode = new SMode("Mode", "Dispenser", "Hopper");
	private SMode placeMode = new SMode("Place Mode", "Aim", "Auto");
	private SBoolean illegalbypass = new SBoolean("Illegal Bypass", false);
	private SBoolean enableAura = new SBoolean("Enable Aura", true);
	private SBoolean whythis = new SBoolean("China Place", false);
	private SBoolean debugRender = new SBoolean("Debug Render", false);
	private SBoolean smartAim = new SBoolean("Smart Aim", true);
	private SInteger timeout = new SInteger("Timeout Ticks", 30, 70, 100);
	
	private Stage stage;
	private int obsidian, dispenser, redstone, shulker, hopper, tickdelay;
	private BlockPos target, obs, disp, red, hop;
	private boolean autoplacing;
	private EnumFacing redstoneDirection;
	
	public Auto32k() {
		super("Auto32k", ModuleCategory.DISPENSERPVP);
		addSetting(mode);
		addSetting(placeMode);
		addSetting(illegalbypass);
		addSetting(enableAura);
		addSetting(whythis);
		addSetting(debugRender);
		addSetting(smartAim);
		addSetting(timeout);
	}
	
	@Override
	public void onEnable() {
		if(Null()) return;
		this.setArraylistInfo(this.mode.getValue());
		MinecraftForge.EVENT_BUS.register(this);
		
		this.hopper = InventoryUtil.find(Blocks.HOPPER);
		this.shulker = -1;
		for(int i = 0; i < 9; i++) {
			ItemStack stack = mc.player.inventory.getStackInSlot(i);
			if(stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock)) continue;
			Block block = ((ItemBlock) stack.getItem()).getBlock();
			if(InventoryUtil.shulkers.contains(block)) {shulker = i;}
		}
		
		if(mode.getValue().equalsIgnoreCase("dispenser")) {
			this.obsidian = InventoryUtil.find(Blocks.OBSIDIAN);
			this.dispenser = InventoryUtil.find(Blocks.DISPENSER);
			this.redstone = InventoryUtil.find(Blocks.REDSTONE_BLOCK);
		}
		
		this.target = null;
		this.obs = null;
		this.disp = null;
		this.hop = null;
		this.red = null;
		this.autoplacing = false;
		this.stage = Stage.CALCULATING;
		this.tickdelay = 0;
		
		if(obsidian == -1 && mode.getValue().equalsIgnoreCase("dispenser")) {
			MessageUtil.sendClientMessage(TextFormatting.BLUE + "[Auto32k] " + TextFormatting.GRAY + "Missing Obsidian!");
			this.disable();
			return;
		} else if(dispenser == -1 && mode.getValue().equalsIgnoreCase("dispenser")) {
			MessageUtil.sendClientMessage(TextFormatting.BLUE + "[Auto32k] " + TextFormatting.GRAY + "Missing Dispenser!");
			this.disable();
			return;
		} else if(redstone == -1 && mode.getValue().equalsIgnoreCase("dispenser")) {
			MessageUtil.sendClientMessage(TextFormatting.BLUE + "[Auto32k] " + TextFormatting.GRAY + "Missing Redstone Block!");
			this.disable();
			return;
		} else if(hopper == -1) {
			MessageUtil.sendClientMessage(TextFormatting.BLUE + "[Auto32k] " + TextFormatting.GRAY + "Missing Hopper!");
			this.disable();
			return;
		} else if(shulker == -1) {
			MessageUtil.sendClientMessage(TextFormatting.BLUE + "[Auto32k] " + TextFormatting.GRAY + "Missing Shulker Box!");
			this.disable();
			return;
		}
		
		if(this.placeMode.getValue().equalsIgnoreCase("Auto")) {
			autoplacing = true;
		}
		
		if(this.placeMode.getValue().equalsIgnoreCase("Aim")) {
			if(mc.objectMouseOver == null || mc.objectMouseOver.getBlockPos() == null || mc.objectMouseOver.getBlockPos().up() == null || mc.objectMouseOver.getBlockPos().getDistance((int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ) < 2 && smartAim.getValue()) {
				autoplacing = true;
			}
			if(!autoplacing) {
				target = mc.objectMouseOver.getBlockPos();
				if(mc.world.getBlockState(target.offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable()) {
					if(this.checkRoom(target, true)) {
						this.hop = target.offset(mc.player.getHorizontalFacing().getOpposite());
						this.disp = target.add(0, 1, 0);
						this.red = this.getRedstoneSpot(this.disp);
						if(red == null && smartAim.getValue()) {
							autoplacing = true;
						}
					} else {
						if(smartAim.getValue())
						autoplacing = true;
					}
				} else {
					if(this.checkRoom(target, false)) {
						this.hop = target.offset(mc.player.getHorizontalFacing().getOpposite()).add(0, 1, 0);
						this.obs = target.add(0, 1, 0);
						this.disp = target.add(0, 2, 0);
						this.red = this.getRedstoneSpot(this.disp);
						if(red == null && smartAim.getValue()) {
							autoplacing = true;
						}
					} else {
						if(smartAim.getValue())
						autoplacing = true;
					}
				}
			}
		}
		
		if(autoplacing) {
			for(int y = mc.player.isAirBorne ? -3 : -1; y <= 1; y++) {
				if(mc.player.getHorizontalFacing().toString().equalsIgnoreCase("north")) {
					for(int x = -1; x <= 1; x++) {
						for(int z = 0; z >= -3; z--) {
							this.calculatePos(x, y, z);
						}
					}
				} else if(mc.player.getHorizontalFacing().toString().equalsIgnoreCase("south")) {
					for(int x = -1; x <= 1; x++) {
						for(int z = 0; z <= 3; z++) {
							this.calculatePos(x, y, z);
						}
					}
				} else if(mc.player.getHorizontalFacing().toString().equalsIgnoreCase("east")) {
					for(int x = 0; x <= 3; x++) {
						for(int z = -1; z <= 1; z++) {
							this.calculatePos(x, y, z);
						}
					}
				} else {
					for(int x = 0; x >= -3; x--) {
						for(int z = -1; z <= 1; z++) {
							this.calculatePos(x, y, z);
						}
					}
				}
			}
		}
		
		//last ditch attempt tp try to place anywhere
		if((red == null || hop == null || disp == null) && autoplacing) {
			for (int x = -2; x <= 2; x++) {
                for (int y = mc.player.isAirBorne ? -3 : -1; y <= 1; ++y) {
                    for (int z = -2; z <= 2; z++) {
                    	this.calculatePos(x, y, z);
                    }
                }
            }
			if(red == null || hop == null || disp == null) {
				MessageUtil.sendClientMessage(ChatFormatting.BLUE + "[Auto32k] " + ChatFormatting.GRAY + "Nowhere to place!");
				this.disable();
				return;
			}
		}
		
		if(obs == null) {
			if(mc.world.getBlockState(target.offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable()) {
				this.stage = Stage.DISPANDOBS;
			} else {
				MessageUtil.sendClientMessage(ChatFormatting.BLUE + "[Auto32k] " + ChatFormatting.GRAY + "Nowhere to place!");
				this.disable();
				return;
			}
		}
	
		this.stage = Stage.DISPANDOBS;
	}
	
	@Override
	public void onUpdate() {
		if(Null()) {
			this.disable();
			return;
		}
		
		tickdelay++;
		
		if(this.stage.equals(Stage.DISPANDOBS)) {
			if(obs != null) {
				mc.player.inventory.currentItem = obsidian;
				ModuleUtil.placeBlock(obs, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
			}
			mc.player.inventory.currentItem = dispenser;
			ModuleUtil.placeBlock(disp, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
			mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(disp, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0, 0, 0));
			this.stage = Stage.DISPSTUFF;
		}
		
		if(this.stage.equals(Stage.DISPSTUFF)) {
			if(!(mc.currentScreen instanceof GuiDispenser)) {
				if(tickdelay > timeout.getValue()) {
					MessageUtil.sendClientMessage("Tick Timeout!");
					this.disable();
					return;
				}
				return;
			}
			
			mc.playerController.windowClick(mc.player.openContainer.windowId, 4, shulker, ClickType.SWAP, mc.player);
			mc.player.closeScreen();
			this.stage = Stage.REDSTONE;
		}
		
		if(this.stage.equals(Stage.REDSTONE)) {
			mc.player.inventory.currentItem = redstone;
			ModuleUtil.placeBlock(red, this.redstoneDirection, false, EnumHand.MAIN_HAND);
			this.stage = Stage.PLACEHOP;
		}
		
		if(this.stage.equals(Stage.PLACEHOP)) {
			if(!(mc.world.getBlockState(disp.offset(mc.player.getHorizontalFacing().getOpposite())).getBlock() instanceof BlockShulkerBox)) return;
			mc.player.inventory.currentItem = hopper;
			ModuleUtil.placeBlock(hop, mc.player.getHorizontalFacing(), false, EnumHand.MAIN_HAND);
			mc.player.inventory.currentItem = shulker;
			mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(hop, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0, 0, 0));
			this.stage = Stage.HOPSTUFF;
		}
		
		if(this.stage.equals(Stage.HOPSTUFF)) {

			if(!(mc.currentScreen instanceof GuiHopper)) {
				return;
			}
			
				this.stage = Stage.FINISH;
			
		}
		
		if(stage.equals(Stage.FINISH)) {
			if(!(mc.currentScreen instanceof GuiHopper)) {
				this.disable();
				return;
			}
			if(((GuiContainer) mc.currentScreen).inventorySlots.getSlot(0).getStack().isEmpty()) {
				return;
			} else {
				mc.playerController.windowClick(mc.player.openContainer.windowId, 0, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);
				if(illegalbypass.getValue()) {
					ClientModule secretClose = ModuleManager.getModuleByClass(SecretClose.class);
					if(!secretClose.isEnabled()) {
						secretClose.enable();
					}
				}
				if(enableAura.getValue()) {
					ClientModule aura = ModuleManager.getModuleByClass(Aura32k.class);
					if(!aura.isEnabled()) {
						aura.enable();
					}
				}
				if(illegalbypass.getValue()) {
					mc.player.closeScreen();
					this.disable();
					return;
				}
			}
		}
	}
	
	@SubscribeEvent
	public void onRender(RenderWorldLastEvent event) {
		if(!debugRender.getValue()) return;
		if(hop != null) {
			RenderUtil.drawBoundingBoxBlockPos(hop, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
		}
		
		if(disp != null) {
			RenderUtil.drawBoundingBoxBlockPos(disp, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
			if(mc.world.getBlockState(disp).getBlock() == Blocks.DISPENSER)
			RenderUtil.drawBoundingBoxBlockPos(disp.offset(mc.world.getBlockState(disp).getValue(PropertyDirection.create("facing"))), 0, new Color(FinalColor.BESTCOLOR(255, 0)));
		}
		
		if(obs != null) {
			RenderUtil.drawBoundingBoxBlockPos(obs, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
		}
		
		if(red != null) {
			RenderUtil.drawBoundingBoxBlockPos(red, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
		}
	}
	
	private enum Stage {
		CALCULATING,
		DISPANDOBS,
		DISPSTUFF,
		REDSTONE,
		PLACEHOP,
		HOPSTUFF,
		FINISH
	}
	
	public boolean checkRoom(BlockPos placeTarget, boolean boosted) {
		if(boosted) {
			return mc.world.getBlockState(placeTarget.add(0, 1, 0)).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget.offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget.add(0, 1, 0).offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget).getBlock() != Blocks.REDSTONE_BLOCK &&
				   mc.world.getBlockState(placeTarget).getBlock() != Blocks.HOPPER &&
				   mc.world.getBlockState(placeTarget).getBlock() != Blocks.DISPENSER &&
				   !(mc.world.getBlockState(placeTarget).getBlock() instanceof BlockShulkerBox) &&
				   mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(placeTarget.add(0, 1, 0).offset(mc.player.getHorizontalFacing().getOpposite())), e -> !(e instanceof EntityItem)).isEmpty() &&
				   mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(placeTarget.offset(mc.player.getHorizontalFacing().getOpposite())), e -> !(e instanceof EntityItem)).isEmpty();
		} else {
			return mc.world.getBlockState(placeTarget.add(0, 1, 0)).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget.add(0, 2, 0)).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget.add(0, 2, 0).offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget.add(0, 1, 0).offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable() &&
				   mc.world.getBlockState(placeTarget.offset(mc.player.getHorizontalFacing().getOpposite())).getBlock() != Blocks.REDSTONE_BLOCK &&
				   mc.world.getBlockState(placeTarget.offset(mc.player.getHorizontalFacing().getOpposite())).getBlock() != Blocks.HOPPER &&
				   mc.world.getBlockState(placeTarget.offset(mc.player.getHorizontalFacing().getOpposite())).getBlock() != Blocks.DISPENSER &&
				   !(mc.world.getBlockState(placeTarget.offset(mc.player.getHorizontalFacing().getOpposite())).getBlock() instanceof BlockShulkerBox) &&
				   mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(placeTarget.add(0, 2, 0).offset(mc.player.getHorizontalFacing().getOpposite())), e -> !(e instanceof EntityItem)).isEmpty() &&
				   mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(placeTarget.add(0, 1, 0).offset(mc.player.getHorizontalFacing().getOpposite())), e -> !(e instanceof EntityItem)).isEmpty();
		}
	}
	
	public BlockPos getRedstoneSpot(BlockPos dispenserPos) {
		if(whythis.getValue()) {
			if(mc.world.getBlockState(dispenserPos.offset(mc.player.getHorizontalFacing().rotateY())).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.offset(mc.player.getHorizontalFacing().rotateY())), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = mc.player.getHorizontalFacing().rotateY().getOpposite();
				return dispenserPos.offset(mc.player.getHorizontalFacing().rotateY());
			} else if(mc.world.getBlockState(dispenserPos.offset(mc.player.getHorizontalFacing().rotateYCCW())).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.offset(mc.player.getHorizontalFacing().rotateYCCW())), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = mc.player.getHorizontalFacing().rotateYCCW().getOpposite();
				return dispenserPos.offset(mc.player.getHorizontalFacing().rotateYCCW());
			} else if(mc.world.getBlockState(dispenserPos.offset(mc.player.getHorizontalFacing())).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.offset(mc.player.getHorizontalFacing())), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = mc.player.getHorizontalFacing().getOpposite();
				return dispenserPos.offset(mc.player.getHorizontalFacing());
			} else if(mc.world.getBlockState(dispenserPos.add(0, 1, 0)).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.add(0, 1, 0)), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = EnumFacing.DOWN;
				return dispenserPos.add(0, 1, 0);
			}
		} else {
			if(mc.world.getBlockState(dispenserPos.add(0, 1, 0)).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.add(0, 1, 0)), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = EnumFacing.DOWN;
				return dispenserPos.add(0, 1, 0);
			} else if(mc.world.getBlockState(dispenserPos.offset(mc.player.getHorizontalFacing().rotateYCCW())).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.offset(mc.player.getHorizontalFacing().rotateYCCW())), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = mc.player.getHorizontalFacing().rotateYCCW().getOpposite();
				return dispenserPos.offset(mc.player.getHorizontalFacing().rotateYCCW());
			} else if(mc.world.getBlockState(dispenserPos.offset(mc.player.getHorizontalFacing())).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.offset(mc.player.getHorizontalFacing())), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = mc.player.getHorizontalFacing().getOpposite();
				return dispenserPos.offset(mc.player.getHorizontalFacing());
			} else if(mc.world.getBlockState(dispenserPos.offset(mc.player.getHorizontalFacing().rotateY())).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(dispenserPos.offset(mc.player.getHorizontalFacing().rotateY())), e -> !(e instanceof EntityItem)).isEmpty()) {
				this.redstoneDirection = mc.player.getHorizontalFacing().rotateY().getOpposite();
				return dispenserPos.offset(mc.player.getHorizontalFacing().rotateY());
			}
		}
		return null;
	}
	
	public void calculatePos(int x, int y, int z) {
		boolean boosted = mc.world.getBlockState(mc.player.getPosition().add(x, y, z).add(0, 0, 0).offset(mc.player.getHorizontalFacing().getOpposite())).getMaterial().isReplaceable();
    	if(!mc.world.getBlockState(mc.player.getPosition().add(x, y, z)).getMaterial().isReplaceable() && this.checkRoom(mc.player.getPosition().add(x, y, z), boosted)) {
    		this.target = mc.player.getPosition().add(x, y, z);
    		if(boosted) {
    			this.disp = target.add(0, 1, 0);
    			this.hop = target.offset(mc.player.getHorizontalFacing().getOpposite());
    			this.red = this.getRedstoneSpot(this.disp);
    			this.obs = null;
    		} else {
    			this.disp = target.add(0, 2, 0);
    			this.hop = target.offset(mc.player.getHorizontalFacing().getOpposite()).add(0, 1, 0);
    			this.red = this.getRedstoneSpot(this.disp);
    			this.obs = target.add(0, 1, 0);
    		}
    	}
	}
}
