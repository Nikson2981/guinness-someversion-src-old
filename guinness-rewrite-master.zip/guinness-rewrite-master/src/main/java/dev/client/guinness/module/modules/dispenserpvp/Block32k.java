package dev.client.guinness.module.modules.dispenserpvp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;

public class Block32k extends ClientModule {
	
	public Block32k() {
		super("32kBlock", ModuleCategory.DISPENSERPVP);
	}
	
	private List<EntityPlayer> badguys = new ArrayList<>();
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		findEnemies();
		if(badguys.size() == 0) return;
		if(ModuleUtil.is32k(mc.player.itemStackMainHand)) return;
		if(ModuleManager.getModuleByClass(Auto32k.class).isEnabled()) return;
		
		int currentSlot = mc.player.inventory.currentItem;
		int obs = InventoryUtil.find(Blocks.OBSIDIAN);
		if(obs != -1) {
			mc.player.inventory.currentItem = obs;
			badguys.forEach(b -> {
				block32k(b);
			});
			mc.player.inventory.currentItem = currentSlot;
		}
	}
	
	public void findEnemies() {
		badguys = mc.world.playerEntities.stream()
				.filter(p -> p != mc.player)
				.filter(p -> !FriendUtil.isFriend(p.getName()))
				.filter(p -> mc.player.getDistance(p) <= 8)
				.filter(p -> p.getHeldItemMainhand().getItem() instanceof ItemBlock)
				.filter(p -> ((ItemBlock)p.getHeldItemMainhand().getItem()).getBlock() == Blocks.DISPENSER)
				.collect(Collectors.toList());
	}
	
	public void block32k(EntityPlayer p) {
		mc.world.loadedTileEntityList.stream()
		.filter(d -> d instanceof TileEntityDispenser)
		.filter(d -> d.getDistanceSq(mc.player.posX, mc.player.posY, mc.player.posZ) <= 8*8)
		.forEach(d -> {
			if(mc.world.getBlockState(d.getPos().offset(EnumFacing.getDirectionFromEntityLiving(d.getPos(), p))).getMaterial().isReplaceable())
			ModuleUtil.placeBlock(d.getPos().offset(EnumFacing.getDirectionFromEntityLiving(d.getPos(), p)), EnumFacing.getDirectionFromEntityLiving(d.getPos(), p).getOpposite(), false, EnumHand.MAIN_HAND);
		});
	}

}
