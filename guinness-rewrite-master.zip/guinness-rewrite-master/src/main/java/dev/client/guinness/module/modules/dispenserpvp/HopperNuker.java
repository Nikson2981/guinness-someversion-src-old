package dev.client.guinness.module.modules.dispenserpvp;

import java.util.Comparator;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SDouble;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class HopperNuker extends ClientModule {
	
	private SBoolean rotate = new SBoolean("Rotate", false);
	private SMode mode = new SMode("Break Mode", "Packet", "Vanilla");
	private SDouble range = new SDouble("Range", 1.0D, 6.0D, 9.0D, 1);
	
	public HopperNuker() {
		super("HopperNuker", ModuleCategory.DISPENSERPVP);
		addSetting(rotate);
		addSetting(mode);
		addSetting(range);
	}
	
	private int prevSlot = -1;
	private boolean mining = false;
	private BlockPos pos;
	
	@Override
	public void onUpdate() {
		this.setArraylistInfo(mode.getValue());
		if(Null()) return;
		if(ModuleManager.getModuleByClass(Auto32k.class).isEnabled()) return;
		BlockPos pos = findHoppers();
		if(pos != null) {
			if(!mining) {
				prevSlot = mc.player.inventory.currentItem;
				mining = true;
			}
			if(rotate.getValue()) {
			ModuleUtil.rotateClient(pos.getX(), pos.getY(), pos.getZ());
			}
			
			int newSlot = -1;
            for (int i = 0; i < 9; i++) {
                ItemStack stack = mc.player.inventory.getStackInSlot(i);
                if (stack == ItemStack.EMPTY) {
                    continue;
                }
                if ((stack.getItem() instanceof ItemPickaxe)) {
                    newSlot = i;
                    break;
                }
            }
            
            if (newSlot != -1) {
                mc.player.inventory.currentItem = newSlot;
            }
			
            if(!this.mode.getValue().equalsIgnoreCase("Packet")) {
            	mc.playerController.onPlayerDamageBlock(pos, mc.player.getHorizontalFacing());
            	mc.player.swingArm(EnumHand.MAIN_HAND);
            } else {
            	mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, mc.player.getHorizontalFacing()));
        		mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, mc.player.getHorizontalFacing()));
            }
            
		} else {
			 if (prevSlot != -1) {
	                mc.player.inventory.currentItem = prevSlot;
	                prevSlot = -1;
	                mining = false;
	            }
		}
		
	}
	
	private BlockPos findHoppers() {
		pos = null;
		
		mc.world.loadedTileEntityList.stream().filter(e -> 
		e instanceof TileEntityHopper).filter(e -> 
		mc.player.getDistance(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()) <= range.getValue()).sorted(Comparator.comparing(e ->
		mc.player.getDistance(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ()))).forEach(hopper ->
		{
			BlockPos hop = new BlockPos(hopper.getPos());
			pos = hop;

		});
		return pos;
	}
	
}
