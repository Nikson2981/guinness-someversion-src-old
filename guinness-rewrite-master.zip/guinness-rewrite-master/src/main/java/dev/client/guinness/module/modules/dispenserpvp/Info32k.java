package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.Guinness;
import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.modules.client.ClickGui;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Info32k extends ClientModule {

    private SBoolean info = new SBoolean("Info", true);
    private SBoolean warn = new SBoolean("Warner", true);

    public Info32k() {
        super("32kInfo", ModuleCategory.DISPENSERPVP);
        addSetting(info);
        addSetting(warn);
    }

    @SubscribeEvent
    public void onRender(Text event) {
        if (Null()) return;
        if (event.getType().equals(ElementType.TEXT)) {
            ScaledResolution sr = new ScaledResolution(mc);
            if (info.getValue()) {
                if (this.has32k()) {
                    if (ClickGui.theme.getValue().equalsIgnoreCase("cliffbase")) {
                        mc.fontRenderer.drawStringWithShadow("32k in hotbar!", (sr.getScaledWidth() / 2 - mc.fontRenderer.getStringWidth("32k in hotbar!") / 2), 2, FinalColor.BESTCOLOR(255, 1));
                    } else {
                        GlStateManager.pushMatrix();
                        Guinness.customFont.drawStringWithShadow("32k in hotbar!", (sr.getScaledWidth() / 2 - Guinness.customFont.getStringWidth("32k in hotbar!") / 2), 2, FinalColor.BESTCOLOR(255, 1));
                        GlStateManager.popMatrix();
                    }
                } else {
                    if (ClickGui.theme.getValue().equalsIgnoreCase("cliffbase")) {
                        mc.fontRenderer.drawStringWithShadow("No 32k in hotbar!", (sr.getScaledWidth() / 2 - mc.fontRenderer.getStringWidth("No 32k in hotbar!") / 2), 2, 0xFFFF0000);
                    } else {
                        GlStateManager.pushMatrix();
                        Guinness.customFont.drawStringWithShadow("No 32k in hotbar!", (sr.getScaledWidth() / 2 - Guinness.customFont.getStringWidth("No 32k in hotbar!") / 2), 2, 0xFFFF0000);
                        GlStateManager.popMatrix();
                    }
                }
            }
        }
    }

    private boolean has32k() {
        for (int i = 0; i < 9; i++) {
            ItemStack threetwokay = mc.player.inventory.getStackInSlot(i);
            if (ModuleUtil.is32k(threetwokay)) {
                return true;
            }
        }
        return false;
    }

}
