package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.setting.settings.SInteger;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class TP32k extends ClientModule {
	private SMode mode = new SMode("Mode", "Bow", "Normal");
	public SInteger delay = new SInteger("TP Delay", 1, 2, 6);
	
	public static TP32k INSTANCE;
	public TP32k() {
		super("32kTP", ModuleCategory.DISPENSERPVP);
		addSetting(mode);
		addSetting(delay);
		INSTANCE = this;
	}
	
	public BlockPos startpos;
	public boolean flag = false;
	boolean hasbow = false;
	
	@Override
	public void onEnable() {
		if(Null()) return;
		flag = false;
		hasbow = false;
		ModuleManager.getModuleByClass(TP32kHelper.class).enable();
		if(this.mode.getValue().equalsIgnoreCase("Bow")) {
			int bow = InventoryUtil.find(Items.BOW);
			if(bow == -1) {
				MessageUtil.sendClientMessage("No bow found!");
				return;
			}
			
			hasbow = true;
			
		}
	}
	
	@Override
	public void onUpdate() {
		this.setArraylistInfo(this.mode.getValue());
		if(this.mode.getValue().equalsIgnoreCase("Bow") && hasbow) {
			int bow = InventoryUtil.find(Items.BOW);
			mc.player.inventory.currentItem = bow;
			if(mc.player.getItemInUseMaxCount() >= 5) {
				mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
                mc.player.stopActiveHand();
                hasbow = false;
            } else {
                mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
            }
		}
	}
	
	@Override
	public void onDisable() {
		if(Null()) return;
		flag = true;	
	}

}
