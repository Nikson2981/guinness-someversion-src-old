package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.network.play.client.CPacketPlayer;

public class TP32kHelper extends ClientModule {
	
	public TP32kHelper() {
		super("32kTPHelper", ModuleCategory.HIDDEN);
	}
	
	int ticks = 0;
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		if(TP32k.INSTANCE.flag) {
			ticks++;
			if(ticks == TP32k.INSTANCE.delay.getValue()) {
				ticks++;
				mc.player.motionY = 4;
				this.disable();
			}
		}
	}
	
	@Override
	public void onDisable() {
		ticks = 0;
		TP32k.INSTANCE.flag = false;
	}

}
