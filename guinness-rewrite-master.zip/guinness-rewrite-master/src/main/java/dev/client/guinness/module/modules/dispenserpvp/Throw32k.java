package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.event.events.PacketEvent.PacketSendEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.block.Block;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Throw32k extends ClientModule {
	private SMode mode = new SMode("Mode", "Single", "Persistant");
	public Throw32k() {
		super("32kThrow", ModuleCategory.DISPENSERPVP);
		addSetting(mode);
	}
	
	int sword;
	int shulker;
	boolean ready2swap = false;
	int delay;
	
	@Override
	public void onEnable() {
		if(Null()) return;
		MinecraftForge.EVENT_BUS.register(this);
		if(this.mode.getValue().equalsIgnoreCase("Persistant")) return;
		sword = -1;
		sword = InventoryUtil.find(Items.DIAMOND_SWORD);
		
		shulker = -1;
		for(int i = 9; i < 36; i++) {
			ItemStack stack = mc.player.inventory.getStackInSlot(i);
			if(stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock)) continue;
			Block block = ((ItemBlock) stack.getItem()).getBlock();
			if(InventoryUtil.shulkers.contains(block)) {
				shulker = i;
			}
		}
		
		if(sword == -1) {
			MessageUtil.sendClientMessage("No sword to swap!");
			this.disable();
			return;
		}
		
		if(shulker == -1) {
			MessageUtil.sendClientMessage("No shulkers left!");
			this.disable();
			return;
		}
	}
	
	@Override
	public void onUpdate() {
		if(Null()) { 
			this.disable();
			return;
		}
		
		this.setArraylistInfo(this.mode.getValue());
		
		if(this.mode.getValue().equalsIgnoreCase("Single")) {
			mc.playerController.windowClick(mc.player.inventoryContainer.windowId, shulker, sword, ClickType.SWAP, mc.player);
			mc.player.connection.sendPacket(new CPacketClickWindow(0, shulker, 0, ClickType.THROW, mc.player.inventory.getStackInSlot(shulker), mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory)));
			this.disable();
		}
		
		if(ready2swap) {
			delay++;
			if(delay >= 4) {
				ready2swap = false;
				delay = 0;
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, shulker, sword, ClickType.SWAP, mc.player);
				mc.player.connection.sendPacket(new CPacketClickWindow(0, shulker, 0, ClickType.THROW, mc.player.inventory.getStackInSlot(shulker), mc.player.inventoryContainer.getNextTransactionID(mc.player.inventory)));
			}
		}
		
	}
	
	@SubscribeEvent
	public void onPacketSend(PacketSendEvent event) {
		if(this.mode.getValue().equalsIgnoreCase("Persistant")) {
			if(event.getPacket() instanceof CPacketCloseWindow) {
				sword = -1;
				sword = InventoryUtil.find(Items.DIAMOND_SWORD);
				
				shulker = -1;
				for(int i = 9; i < 36; i++) {
					ItemStack stack = mc.player.inventory.getStackInSlot(i);
					if(stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock)) continue;
					Block block = ((ItemBlock) stack.getItem()).getBlock();
					if(InventoryUtil.shulkers.contains(block)) {
						shulker = i;
					}
				}
				
				if(sword == -1) {
					return;
				}
				
				if(shulker == -1) {
					MessageUtil.sendClientMessage(TextFormatting.BLUE + "[32kThrow]" + TextFormatting.RESET + "No shulkers left!");
					return;
				}
				
				if(ModuleUtil.is32k(mc.player.inventory.getStackInSlot(sword))) return;
				
				ready2swap = true;
				
			}
		}
	}
	
	@Override
	public void onDisable() {
		MinecraftForge.EVENT_BUS.unregister(this);
		sword = -1;
		shulker = -1;
	}

}
