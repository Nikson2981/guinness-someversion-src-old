package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.module.ClientModule;

public class blu332kReset extends ClientModule {

    public blu332kReset() {
        super("blu332kReset", ModuleCategory.HIDDEN);
        INSTANCE = this;
        disable();
    }

    int ticks = 0;
    public static blu332kReset INSTANCE;

    @Override
    public void onUpdate() {
        if (Null()) return;
        if (blu3Auto32k.INSTANCE.dispenserFuckedUp) {
            ticks++;
            if (ticks == 20) {
                blu3Auto32k.INSTANCE.dispenserFuckedUp = false;
                blu3Auto32k.INSTANCE.enable();
            }
        }
    }

    @Override protected void onDisable() {
        ticks = 0;
    }
}
