package dev.client.guinness.module.modules.dispenserpvp;

import dev.client.guinness.event.events.*;
import dev.client.guinness.gui.theme.*;
import dev.client.guinness.module.*;
import dev.client.guinness.module.modules.exploit.*;
import dev.client.guinness.setting.settings.*;
import dev.client.guinness.setting.subsettings.*;
import dev.client.guinness.util.client.*;
import dev.client.guinness.util.module.*;
import net.minecraft.block.*;
import net.minecraft.block.properties.*;
import net.minecraft.client.gui.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.init.*;
import net.minecraft.inventory.*;
import net.minecraft.item.*;
import net.minecraft.network.play.client.*;
import net.minecraft.util.*;
import net.minecraft.util.math.*;
import net.minecraft.util.text.*;
import net.minecraftforge.client.event.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.common.gameevent.*;

import static dev.client.guinness.util.module.ModuleUtil.*;
import static dev.client.guinness.util.render.RenderUtil.*;

import java.awt.*;

/**
 * @author blu3
 * @since 2021-01-15
 * To my knowledge this is the smartest and most well optimised Auto32k ever written.
 */
@SuppressWarnings("ALL") // intellij moment
public class blu3Auto32k extends ClientModule {
    public static final SMode placeMode = new SMode("PlaceMode", "Auto", "Aim"), placeType = new SMode("PlaceType", "Dispenser", "Hopper");
    public static final SInteger range = new SInteger("Range", 1, 3, 3);
    public static final SBoolean timeOut = new SBoolean("Timeout (v)", true), secretClose = new SBoolean("Secret Close", false), autoRetry = new SBoolean("Auto Retry (v)", true), rotate = new SBoolean("Rotate (v)", false), render = new SBoolean("Render", true), sidePlace = new SBoolean("Side Redstone", false), slow = new SBoolean("Slow (v)", false);
    public static final SubInteger ticks = new SubInteger(autoRetry, "Ticks", 10, 20, 30), slowTicks = new SubInteger(slow, "Tick Delay", 1, 8, 20), timeout = new SubInteger(timeOut, "Timeout Ticks", 60, 80, 100);
    public static final SubMode rotateMode = new SubMode(rotate, "RotateMode", "Server", "Client");

    public blu3Auto32k() {
        super("blu3Auto32k", ModuleCategory.DISPENSERPVP);
        addSetting(placeMode);
        addSetting(placeType);
        addSetting(range);
        addSetting(timeOut);
        addSetting(secretClose);
        addSetting(autoRetry);
        addSetting(rotate);
        addSetting(render);
        addSetting(sidePlace);
        addSetting(slow);
        INSTANCE = this;
    }

    private void disableSaying(String text) {
        MessageUtil.sendClientMessage(TextFormatting.AQUA + "[Auto32k] " + TextFormatting.RED + text);
        disable();
    }

    public static blu3Auto32k INSTANCE;
    public boolean dispenserFuckedUp;
    private static int block = -1, redstone = -1, dispenser = -1, hopper = -1, shulker = -1, phaseTicks = 0, slownessTicks, totalTicks;
    private static BlockPos placeTarget, obbyPos, dispenserPos, redstonePos, shulkerPos, hopperPos, rotationPos;
    private static boolean movedSword, foundPlaceTarget, skipping, isRotating, togglePitch = false, isDispenser, placedDispenser, shulkerDispensed;
    private float yaw, pitch;
    private PlacePhase phase;
    private EnumFacing direction;

    @Override
    protected void onEnable() {
        if (Null()) return;
        super.onEnable();
        resetRotation();
        if (blu332kReset.INSTANCE.isEnabled()) blu332kReset.INSTANCE.disable();
        phase = PlacePhase.STARTING;
        block = InventoryUtil.find(Blocks.OBSIDIAN);
        redstone = InventoryUtil.find(Blocks.REDSTONE_BLOCK);
        dispenser = InventoryUtil.find(Blocks.DISPENSER);
        hopper = InventoryUtil.find(Blocks.HOPPER);
        phaseTicks = 0;
        slownessTicks = 0;
        totalTicks = 0;
        shulker = -1;
        for (int i = 0; i < 9; i++) {
            final ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack == ItemStack.EMPTY || !(stack.getItem() instanceof ItemBlock)) continue;
            final Block block = ((ItemBlock) stack.getItem()).getBlock();
            if (InventoryUtil.shulkers.contains(block)) {
                shulker = i;
            }
        }
        isDispenser = placeType.getValue().equalsIgnoreCase("dispenser");
        placeTarget = null;
        obbyPos = null;
        dispenserPos = null;
        redstonePos = null;
        shulkerPos = null;
        hopperPos = null;
        rotationPos = null;
        movedSword = false;
        foundPlaceTarget = false;
        skipping = false;
        dispenserFuckedUp = false;
        shulkerDispensed = false;
        placedDispenser = false;
        if (block == -1 && isDispenser) disableSaying("Missing obsidian.");
        else if (redstone == -1 && isDispenser) disableSaying("Missing redstone.");
        else if (dispenser == -1 && isDispenser) disableSaying("Missing dispenser.");
        else if (hopper == -1) disableSaying("Missing hopper.");
        else if (shulker == -1) disableSaying("Missing shulker.");
        if (hopper == -1 || (dispenser == -1 && isDispenser) || (redstone == -1 && isDispenser) || shulker == -1 || (block == -1 && isDispenser))
            return;
        if (placeMode.getValue().equalsIgnoreCase("Aim")) beginAimPlacement();
        else beginAutoPlacement();
    }

    private void beginAimPlacement() {
        direction = mc.player.getHorizontalFacing().getOpposite(); // This is so rotating while placing doesnt cause a fuckup.
        placeTarget = mc.player.rayTrace(5.0, mc.getRenderPartialTicks()).getBlockPos();
        if (placeType.getValue().equalsIgnoreCase("hopper")) {
            if (canPlaceBlock(placeTarget.up()) && isBlockEmpty(placeTarget.add(0, 2, 0))) putHopper32k();
            else disableSaying("Unable to place 32k.");
        } else {
            if (cannotPlace(placeTarget) && cannotPlace(placeTarget.up())) {
                disableSaying("Unable to place 32k.");
                return;
            }
            if (canSkip(placeTarget)) skipping = true;
            else if (canSkip(placeTarget.up())) {
                placeTarget = placeTarget.up();
                skipping = true;
            }
            startDispenser32k();
        }
    }

    private void beginAutoPlacement() {
        final int range = blu3Auto32k.range.getValue();
        for (int tries = 1; tries <= 4; tries++) { // Direction to face
            for (int y = -1; y < (mc.player.isAirBorne ? 2 : 1); y++) { // Y levels
                for (int x = -range; x < range; x++) { // X positions
                    for (int z = -range; z < range; z++) { // Z positions
                        placeTarget = new BlockPos(mc.player.posX + x, mc.player.posY + y, mc.player.posZ + z);
                        if (placeType.getValue().equalsIgnoreCase("hopper")) {
                            if (canPlaceBlock(placeTarget.up()) && isBlockEmpty(placeTarget.add(0, 2, 0))) {
                                putHopper32k();
                                return;
                            }
                        } else {
                            direction = (tries == 1 ? EnumFacing.SOUTH : tries == 2 ? EnumFacing.EAST : tries == 3 ? EnumFacing.NORTH : EnumFacing.WEST);
                            if (cannotPlace(placeTarget)) continue;
                            if (canSkip(placeTarget)) skipping = true;
                            startDispenser32k();
                            return;
                        }
                    }
                }
            }
        }
        disableSaying("No viable placetargets.");
    }

    private void startDispenser32k() {
        mc.player.setSprinting(false);
        if (!skipping) {
            placeTarget = placeTarget.up();
            obbyPos = placeTarget;
            rotationPos = obbyPos;
            placeBlock(obbyPos, block);
        }
        mc.player.connection.sendPacket(new CPacketPlayer.Rotation(direction.equals(EnumFacing.EAST) ? 90 : direction.equals(EnumFacing.NORTH) ? 0 : direction.equals(EnumFacing.WEST) ? -90 : 180, 0, mc.player.onGround));
        dispenserPos = placeTarget.up();
        redstonePos = redstoneTarget(dispenserPos);
        hopperPos = placeTarget.offset(direction);
        shulkerPos = hopperPos.up();
        rotationPos = dispenserPos;
        placeBlock(dispenserPos, dispenser);
        placedDispenser = true;
        mc.player.setSneaking(false);
        openBlock(dispenserPos);
        phase = PlacePhase.DISPENSERGUI;
    }

    private void putHopper32k() {
        hopperPos = placeTarget.up();
        shulkerPos = hopperPos.up();
        rotationPos = hopperPos;
        placeBlock(hopperPos, hopper);
        rotationPos = shulkerPos;
        placeBlock(shulkerPos, shulker);
        rotationPos = hopperPos;
        mc.player.setSneaking(false);
        openBlock(hopperPos);
        phase = PlacePhase.HOPPERGUI;
    }

    private boolean cannotSkip(BlockPos pos) {
        return canPlaceBlock(pos) && isBlockEmpty(pos.up()) && !canPlaceBlock(pos.up()) && redstoneTarget(pos.up()) != null && isBlockEmpty(pos.offset(direction)) && isBlockEmpty(pos.offset(direction).up());
    }

    private boolean canSkip(BlockPos pos) {
        return canPlaceBlock(pos.up()) && redstoneTarget(pos.up()) != null && isBlockEmpty(pos.offset(direction)) && isBlockEmpty(pos.offset(direction).up());
    }

    private boolean cannotPlace(BlockPos pos) {
        return !cannotSkip(pos.up()) && !canSkip(pos);
    }

    public void onUpdate() {
        if (safetyCheck()) {
            mc.player.closeScreen();
            return;
        }
        if (placeTarget == null) return;
        this.setArraylistInfo(" [" + phase + "]");
        if (slow.getValue()) {
            slownessTicks++;
            if (slownessTicks <= slowTicks.getValue()) return;
            else slownessTicks = 0;
        }
        phaseTicks++;
        totalTicks++;
        if (placeType.getValue().equalsIgnoreCase("dispenser")) {
            if (phase == PlacePhase.DISPENSERGUI && mc.currentScreen instanceof GuiDispenser) {
                if (dispenserFuckedUp) {
                    final boolean autoRetry = this.autoRetry.getValue();
                    mc.player.closeScreen();
                    disableSaying("Dispenser fucked up" + (autoRetry ? ", retrying." : "."));
                    if (!blu332kReset.INSTANCE.isEnabled() && autoRetry) blu332kReset.INSTANCE.enable();
                    return;
                }
                mc.playerController.windowClick(mc.player.openContainer.windowId, 4, shulker, ClickType.SWAP, mc.player);
                mc.player.closeScreen();
                phase = PlacePhase.REDSTONE;
                phaseTicks = 0;
                return;
            }
            if (phase == PlacePhase.REDSTONE) {
                if (redstonePos == null) disableSaying("No viable redstone placements.");
                else {
                    if (!(mc.world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(redstonePos)).isEmpty())) {
                        MessageUtil.sendClientMessage(TextFormatting.AQUA + "[Auto32k] " + TextFormatting.RED + "MOOOOOOOOOOOOOOOOOOVE");
                        return;
                    }
                    rotationPos = redstonePos;
                    placeBlock(redstonePos, redstone);
                    phase = PlacePhase.HOPPER;
                    phaseTicks = 0;
                    rotationPos = hopperPos;
                }
                return;
            }
            if (phase == PlacePhase.HOPPER && mc.world.getBlockState(shulkerPos).getBlock() instanceof BlockShulkerBox) {
                shulkerDispensed = true;
                placeBlock(hopperPos, hopper);
                openBlock(hopperPos);
                phase = PlacePhase.HOPPERGUI;
                phaseTicks = 0;
                mc.player.inventory.currentItem = shulker;
                return;
            }
        }
        if (phase == PlacePhase.HOPPERGUI) {
            if (!movedSword && mc.currentScreen instanceof GuiHopper) {
                if (((GuiContainer) mc.currentScreen).inventorySlots.getSlot(0).getStack().isEmpty()) return;
                mc.playerController.windowClick(mc.player.openContainer.windowId, 0, shulker, ClickType.SWAP, mc.player);
                movedSword = true;
                if (rotate.getValue()) resetRotation();
                return;
            }
            if (movedSword) { // this boolean only exists to add a tick of delay to this part
                if (secretClose.getValue()) {
                    ClientModule secretClose = ModuleManager.getModuleByClass(SecretClose.class);
                    secretClose.enable();
                    mc.player.closeScreen();
                }
                phase = PlacePhase.FINISHED;
                return;
            }
        }
        if (phase == PlacePhase.FINISHED) {
            phaseTicks = 0;
            if (!(mc.currentScreen instanceof GuiHopper)) {
                disable();
                if (rotateMode.getValue().equalsIgnoreCase("client") && rotate.getValue())
                    mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.cameraYaw, mc.player.cameraPitch, mc.player.onGround));
            }
        }
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent event) {
        if (Null() || !render.getValue()) return;
        if (obbyPos != null) drawBoundingBoxBlockPos(obbyPos, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
        if (hopperPos == null || shulkerPos == null) return;
        drawBoundingBoxBlockPos(hopperPos, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
        if (!isDispenser) drawBoundingBoxBlockPos(shulkerPos, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
        if (!isDispenser) return;
        if (redstonePos != null) drawBoundingBoxBlockPos(redstonePos, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
        if (dispenserPos != null) drawBoundingBoxBlockPos(dispenserPos, 0, new Color(FinalColor.BESTCOLOR(255, 0)));
    }

    private boolean safetyCheck() {
        if (Null()) return true;
        if (mc.player.getDistance(placeTarget.getX(), placeTarget.getY(), placeTarget.getZ()) > 8) return true;
        if (phaseTicks > timeout.getValue() && timeOut.getValue()) {
            disableSaying("Timed out.");
            return true;
        }
        if (totalTicks > timeout.getValue() * 2 && timeOut.getValue()) {
            disableSaying("Timed out.");
            return true;
        }
        if (placedDispenser && !shulkerDispensed && mc.world.getBlockState(dispenserPos).getBlock() instanceof BlockAir) {
            disableSaying("Dispenser was destroyed.");
            return true;
        }
        if (isDispenser && (dispenserPos.offset(mc.world.getBlockState(dispenserPos).getValue(PropertyDirection.create("facing"))).equals(dispenserPos.down()) || dispenserPos.offset(mc.world.getBlockState(dispenserPos).getValue(PropertyDirection.create("facing"))).equals(dispenserPos.up()))) {
            dispenserFuckedUp = true;
        }
        return false;
    }

    private BlockPos redstoneTarget(BlockPos origin) {
        final EnumFacing[] facings = {EnumFacing.UP, EnumFacing.NORTH, EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.EAST};
        final EnumFacing[] sideFacings = {EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.WEST, EnumFacing.EAST, EnumFacing.UP};
        for (final EnumFacing f : sidePlace.getValue() ? sideFacings : facings) {
            if (f.equals(direction)) continue;
            if (mc.world.getBlockState(origin.offset(f)).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(origin.offset(f))).isEmpty() && mc.player.getDistance(origin.offset(f).getX(), origin.offset(f).getY(), origin.offset(f).getZ()) <= 5.0)
                return origin.offset(f);
        }
        return null;
    }

    @Override
    protected void onDisable() {
        super.onDisable();
    }

    enum PlacePhase {STARTING, DISPENSERGUI, REDSTONE, HOPPER, HOPPERGUI, FINISHED}

    private void setRotations(BlockPos pos) {
        final double[] rots = RotationManager.calculateLookAt(pos.getX(), pos.getY(), pos.getZ(), mc.player);
        if (rotateMode.getValue().equalsIgnoreCase("client") && phase != PlacePhase.FINISHED && phase != PlacePhase.HOPPERGUI) {
            RotationManager.RotateClient(pos.getX(), pos.getY(), pos.getZ());
            return;
        }
        yaw = (float) rots[0];
        pitch = (float) rots[1];
        isRotating = true;
    }

    private void resetRotation() {
        yaw = mc.player.cameraYaw;
        pitch = mc.player.cameraPitch;
        isRotating = false;
    }

    @SubscribeEvent
    public void onTick(TickEvent event) {
        if (Null()) return;
        if (rotate.getValue() && rotationPos != null) setRotations(rotationPos);
        if (!isRotating) return;
        if (togglePitch) {
            mc.player.rotationPitch += (float) 4.0E-4;
            togglePitch = false;
        } else {
            mc.player.rotationPitch -= (float) 4.0E-4;
            togglePitch = true;
        }
    }

    @SubscribeEvent
    public void renderRotations(ModelBipedEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (isRotating) {
            event.headYaw = yaw + (mc.player.getHorizontalFacing().equals(EnumFacing.EAST) ? 90 : mc.player.getHorizontalFacing().equals(EnumFacing.SOUTH) ? 0 : mc.player.getHorizontalFacing().equals(EnumFacing.WEST) ? -90 : 180);
            event.headPitch = pitch + 10;
        }
    }

    @SubscribeEvent
    public void spoofRotations(PacketEvent.PacketSendEvent event) {
        if (mc.player == null || mc.world == null) return;
        if (event.getPacket() instanceof CPacketPlayer && isRotating && rotate.getValue() && rotateMode.getValue().equalsIgnoreCase("server")) {
            CPacketPlayer packet = ((CPacketPlayer) event.getPacket());
            packet.yaw = yaw;
            packet.pitch = pitch;
        }
    }
}