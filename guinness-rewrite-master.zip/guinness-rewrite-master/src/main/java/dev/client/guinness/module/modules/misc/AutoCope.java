package dev.client.guinness.module.modules.misc;

import dev.client.guinness.event.events.GuiScreenEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import scala.util.Random;

public class AutoCope extends ClientModule {
	
	public AutoCope() {
		super("AutoCope", ModuleCategory.MISC);
	}
	
	@SubscribeEvent
	public void guiDisplayed(GuiScreenEvent event) {
		if(event.getScreen() instanceof GuiGameOver) {
			Random rand = new Random();
			int bruh = rand.nextInt(6);
			if(bruh == 0) {
				MessageUtil.sendPublicMessage("uhh.. my keyboard was buggin..");
			} else if(bruh == 1) {
				MessageUtil.sendPublicMessage("my headphones broke mid fight tho..");
			} else if(bruh == 2) {
				MessageUtil.sendPublicMessage("i wasnt really even trying anyway..");
			} else if(bruh == 3) {
				MessageUtil.sendPublicMessage("im getting like 10 fps rn..");
			} else if(bruh == 4) {
				MessageUtil.sendPublicMessage("sry.. i was busy snapping the hoes..");
			} else if(bruh == 5) {
				MessageUtil.sendPublicMessage("my pc just bluescreened for a sec..");
			}

		}
	}

}
