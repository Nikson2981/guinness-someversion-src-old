package dev.client.guinness.module.modules.misc;

import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import dev.client.guinness.Guinness;
import dev.client.guinness.event.events.PacketEvent.PacketSendEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoEZ extends ClientModule {
	
	public AutoEZ() {
		super("AutoEZ", ModuleCategory.MISC);
	}
	
	private static final ConcurrentHashMap<String, EntityPlayer> targets = new ConcurrentHashMap<>();
	private int timeout;
	
	@SubscribeEvent
	public void onPacketSend(PacketSendEvent event) {
		if (event.getPacket() instanceof CPacketUseEntity) {
            CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
            if (packet.getAction().equals(CPacketUseEntity.Action.ATTACK)) {
                Entity target = packet.getEntityFromWorld(mc.world);
                if (target instanceof EntityPlayer) {
                    targets.put(target.getName(), (EntityPlayer) target);
                }
            }
        }
	}
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		timeout++;
		mc.world.playerEntities.stream()
		.filter(p -> p.getHealth() <= 0)
		.filter(p -> targets.containsKey(p.getName()))
		.forEach(p -> ez(p));
		
		if(timeout > 20) {
			targets.clear();
			timeout = 0;
		}
	}
	
	private void ez(EntityPlayer p) {
		String name = p.getName();
		Random rand = new Random();
		int tsi = rand.nextInt(6);
		targets.remove(name);
		if(ModuleUtil.is32k(mc.player.inventory.getCurrentItem())) {
			if(tsi == 0) {
				MessageUtil.sendPublicMessage("damn.. " + name + " rly just got 32k'ed by all of this " + Guinness.SPOOFNAME);
			} else if(tsi == 1) {
				MessageUtil.sendPublicMessage("oo aa.. me 32k you.. mad?");
			} else if(tsi == 2) {
				MessageUtil.sendPublicMessage(name + " jus got 1tapped by this " + Guinness.SPOOFNAME);
			} else if(tsi == 3) {
				MessageUtil.sendPublicMessage("i just 32k'ed " + name + " with this " + Guinness.SPOOFNAME);
			} else if(tsi == 4) {
				MessageUtil.sendPublicMessage(Guinness.SPOOFNAME + " just 32k'ed " + name + " out here");
			} else if(tsi == 5) {
				MessageUtil.sendPublicMessage("SAD! " + name + " was just onetapped by this " + Guinness.SPOOFNAME);
			}
			
		} else if(mc.player.inventory.getCurrentItem().getItem() == Items.END_CRYSTAL) {
			if(tsi == 0) {
				MessageUtil.sendPublicMessage(name + " just got blown up by all of this " + Guinness.SPOOFNAME);
			} else if(tsi == 1) {
				MessageUtil.sendPublicMessage("i just blew up " + name + " wit this " + Guinness.SPOOFNAME + " ca");
			} else {
				MessageUtil.sendPublicMessage("i just citied tf out of " + name + " thanks to " + Guinness.SPOOFNAME);
			}
		} else if(mc.player.inventory.getCurrentItem().getItem() == Items.DIAMOND_SWORD) {
			if(tsi == 0) {
				MessageUtil.sendPublicMessage("i j swordfagged tf out of " + name);
			} else {
				MessageUtil.sendPublicMessage("i just smacked " + name + " wit this " + Guinness.SPOOFNAME);
			}
		} else {
			MessageUtil.sendPublicMessage(name + " really just died to all of this " + Guinness.SPOOFNAME);
		}
	}

}
