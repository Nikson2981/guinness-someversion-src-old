package dev.client.guinness.module.modules.misc;

import dev.client.guinness.module.ClientModule;
import net.minecraft.client.gui.GuiGameOver;

public class AutoRespawn extends ClientModule {
	
	public AutoRespawn() {
		super("AutoRespawn", ModuleCategory.MISC);
	}
	
	@Override
	public void onUpdate() {
		if(mc.currentScreen instanceof GuiGameOver) {
			if(mc.player.getHealth() <= 0) {
				mc.player.respawnPlayer();
			}
		}
	}

}
