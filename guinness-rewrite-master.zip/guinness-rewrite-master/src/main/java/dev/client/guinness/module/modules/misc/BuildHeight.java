package dev.client.guinness.module.modules.misc;

import dev.client.guinness.event.events.PacketEvent.PacketSendEvent;
import dev.client.guinness.module.ClientModule;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BuildHeight extends ClientModule {
	
	public BuildHeight() {
		super("BuildHeight", ModuleCategory.MISC);
	}
	
	@SubscribeEvent
    public void onPacketSend(PacketSendEvent event) {
        if (!(event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock))
            return;

        final CPacketPlayerTryUseItemOnBlock oldPacket = (CPacketPlayerTryUseItemOnBlock) event.getPacket();
        if (oldPacket.getPos().getY() < 255)
            return;

        if (oldPacket.getDirection() != EnumFacing.UP)
            return;

        mc.player.connection.sendPacket(new CPacketPlayerTryUseItemOnBlock(oldPacket.getPos(), EnumFacing.DOWN, oldPacket.getHand(), oldPacket.getFacingX(), oldPacket.getFacingY(), oldPacket.getFacingZ()));
        event.setCanceled(true);
    }

}
