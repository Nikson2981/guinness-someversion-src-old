package dev.client.guinness.module.modules.misc;

import dev.client.guinness.event.events.PacketEvent.PacketSendEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChatEncryption extends ClientModule {
	
	public ChatEncryption() {
		super("ChatEncryption", ModuleCategory.MISC);
	}
	
	@SubscribeEvent
	public void onChat(PacketSendEvent event) {
		if(event.getPacket() instanceof CPacketChatMessage) {
			CPacketChatMessage packet = (CPacketChatMessage) event.getPacket();
			String newMessage = MessageUtil.encryptMessage1(packet.getMessage());
			if(packet.getMessage().startsWith("!")) return;
			if(packet.getMessage().startsWith("/")) return;
			if(packet.getMessage().startsWith("?")) return;
			if(packet.getMessage().startsWith("!")) return;
			packet.message = "flqg#" + newMessage;
		}
	}
	
	@SubscribeEvent
	public void receiveChat(ClientChatReceivedEvent event) {
		String message = event.getMessage().getUnformattedText();
		if(!message.contains("#")) return;
		String[] sender1 = message.split("<")[1].split("> ");
		String[] sender2 = sender1[1].split("#");
		if(FriendUtil.isFriend(sender1[0])) {
			event.setCanceled(true);
			mc.ingameGUI.getChatGUI().printChatMessage(new TextComponentString("<" + sender1[0] + "> " + MessageUtil.encryptMessage2(sender2[1])));
		}
		
	}

}
