package dev.client.guinness.module.modules.misc;

import dev.client.guinness.event.events.PacketEvent.PacketSendEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketOpenWindow;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChatSuffix extends ClientModule {
	private SMode mode = new SMode("Mode", "Guinness", "Custom");
	public ChatSuffix() {
		super("ChatSuffix", ModuleCategory.MISC);
		addSetting(mode);
	}
	
	public static String suffix;
	
	@Override
	public void onUpdate() {
		this.setArraylistInfo(this.mode.getValue());
	}
	
	@SubscribeEvent
	public void onPacketSend(PacketSendEvent event) {
		if(event.getPacket() instanceof CPacketChatMessage) {
			final CPacketChatMessage packet = (CPacketChatMessage) event.getPacket();
			String message = packet.getMessage();
			if(message.startsWith("/")) return;
			if(message.startsWith("?")) return;
			if(message.startsWith("!")) return;
			if(mode.getValue().equalsIgnoreCase("Guinness")) {
			message += " \u23d0 " + MessageUtil.toUnicode("guinness");
			packet.message = message;
			}
			
			if(mode.getValue().equalsIgnoreCase("Custom")){
				if(suffix != null) {
				message += " \u23d0 " + MessageUtil.toUnicode(suffix);
				packet.message = message;
				}
			}
		}
	}

}
