package dev.client.guinness.module.modules.misc;

import dev.client.guinness.module.ClientModule;
import net.minecraft.world.GameType;

public class FakeCreative extends ClientModule {
	
	public FakeCreative() {
		super("FakeCreative", ModuleCategory.MISC);
	}

	private GameType gameType;

	@Override
    public void onEnable() {
        if (Null())return;
        gameType = mc.playerController.getCurrentGameType();
        mc.playerController.setGameType(GameType.CREATIVE);
    }

    @Override
    public void onDisable() {
        mc.playerController.setGameType(gameType);
    }

}
