package dev.client.guinness.module.modules.misc;

import com.mojang.authlib.GameProfile;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.client.entity.EntityOtherPlayerMP;

public class FakePlayer extends ClientModule {
	private SBoolean inv = new SBoolean("Copy Inventory", true);
	public FakePlayer() {
		super("FakePlayer", ModuleCategory.MISC);
		addSetting(inv);
	}
	
	private EntityOtherPlayerMP fakePlayer;
	
	@Override
	public void onEnable() {
		fakePlayer = null;
		if(Null()) return;
		super.onEnable();
		fakePlayer = new EntityOtherPlayerMP(mc.world, new GameProfile(mc.player.getUniqueID(), "Guinness"));
		if(inv.getValue()) fakePlayer.inventory.copyInventory(mc.player.inventory);
		mc.world.addEntityToWorld(fakePlayer.getEntityId(), fakePlayer);
		fakePlayer.attemptTeleport(mc.player.posX, mc.player.posY, mc.player.posZ);
		MessageUtil.sendClientMessage("Spawned a player at " + (int) fakePlayer.posX + ", " + (int) fakePlayer.posY + ", " + (int) fakePlayer.posZ);
	}
	
	@Override
	public void onDisable() {
		if(Null()) return;
		if(fakePlayer != null)
		mc.world.removeEntity(fakePlayer);
	}
	
}
