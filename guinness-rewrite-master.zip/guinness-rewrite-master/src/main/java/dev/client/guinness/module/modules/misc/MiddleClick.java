package dev.client.guinness.module.modules.misc;

import org.lwjgl.input.Mouse;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.FriendUtil;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.RayTraceResult;

public class MiddleClick extends ClientModule {
	private SMode mode = new SMode("Mode", "Pearl", "EXP", "Friend");
	public MiddleClick() {
		super("MiddleClick", ModuleCategory.MISC);
		addSetting(mode);
	}
	
	private int pearlSlot;
	private int expSlot;
	
	private boolean clickedMiddle = false; //for pearl
	
	private boolean clickedOnce = false; //for exp
	private boolean startedThrowing = false; //for exp
	
	@Override
	public void onUpdate()
	{
		this.setArraylistInfo(this.mode.getValue());
		if(Null()) return;
		if(mc.currentScreen instanceof GuiContainer) return;
		
		if(mc.player.ticksExisted % 12 == 0) {
			clickedMiddle = false;
		}
		
		if(!Mouse.isButtonDown(2)){
			clickedOnce = false;
		}
		
		if(mode.getValue().equalsIgnoreCase("pearl")) {
			if(Mouse.isButtonDown(2) && !clickedMiddle) {
				clickedMiddle = true;
				findPearl();
		
				if(pearlSlot != -1) {
					
					ItemStack pearl = new ItemStack(Items.ENDER_PEARL);
					
					mc.playerController.windowClick(mc.player.inventoryContainer.windowId, pearlSlot, 0, ClickType.PICKUP, mc.player);
					mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
					
					mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
					
					mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
					mc.playerController.windowClick(mc.player.inventoryContainer.windowId, pearlSlot, 0, ClickType.PICKUP, mc.player);
				
					mc.playerController.windowClick(mc.player.inventoryContainer.windowId, pearlSlot, 0, ClickType.PICKUP, mc.player);
					
					mc.player.connection.sendPacket(new CPacketClickWindow(0, pearlSlot, 0, ClickType.PICKUP, pearl, (short) 19));
					mc.player.connection.sendPacket(new CPacketClickWindow(0, pearlSlot, 0, ClickType.PICKUP, pearl, (short) 20));

				}
			}
		}
		
		if(mode.getValue().equalsIgnoreCase("exp")) {
			if(Mouse.isButtonDown(2)) {
				startedThrowing = true;
				
				if(!clickedOnce) {
					clickedOnce = true;
					if(mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem).getItem() != Items.EXPERIENCE_BOTTLE) {
						findEXP();
					
						mc.playerController.windowClick(mc.player.inventoryContainer.windowId, expSlot, 0, ClickType.PICKUP, mc.player);
						mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
					}
				}
				
				if(clickedOnce) {
					mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
				}
			} else if(!Mouse.isButtonDown(2) && startedThrowing) {
				startedThrowing = false;
				ItemStack exp = new ItemStack(Items.EXPERIENCE_BOTTLE);
				
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, expSlot, 0, ClickType.PICKUP, mc.player);
			
				mc.playerController.windowClick(mc.player.inventoryContainer.windowId, expSlot, 0, ClickType.PICKUP, mc.player);
				
				mc.player.connection.sendPacket(new CPacketClickWindow(0, expSlot, 0, ClickType.PICKUP, exp, (short) 19));
				mc.player.connection.sendPacket(new CPacketClickWindow(0, expSlot, 0, ClickType.PICKUP, exp, (short) 20));
			}
		}
		
		if(mode.getValue().equalsIgnoreCase("friend")) {
			if(Mouse.isButtonDown(2) && !clickedMiddle) {
				clickedMiddle = true;
				final RayTraceResult rtr = mc.objectMouseOver;
				
				if(rtr == null || rtr.typeOfHit != RayTraceResult.Type.ENTITY) return;
				if(!(rtr.entityHit instanceof EntityPlayer)) return;
				
				Entity player = rtr.entityHit;
				
				if(FriendUtil.isFriend(player.getName())) {
					FriendUtil.delFriend(player.getName());
				} else {
					FriendUtil.addFriend(player.getName());
				}
			}
		}
		
	}

	private void findPearl() {
    	if (mc.currentScreen == null || !(mc.currentScreen instanceof GuiContainer)) {
            if (mc.player.inventory.getStackInSlot(mc.player.inventory.currentItem).getItem() != Items.ENDER_PEARL) {
               for(int i = 9; i < 36; ++i) {
            	   if (mc.player.inventory.getStackInSlot(i).getItem() == Items.ENDER_PEARL) {
                	 pearlSlot = i;
                     break;
                  	}
               	}
            }
         }
    }
	
	private void findEXP() {
    	if (mc.currentScreen == null || !(mc.currentScreen instanceof GuiContainer)) {
            if (mc.player.inventory.getStackInSlot(0).getItem() != Items.EXPERIENCE_BOTTLE) {
               for(int i = 9; i < 36; ++i) {
            	   if (mc.player.inventory.getStackInSlot(i).getItem() == Items.EXPERIENCE_BOTTLE) {
                	 expSlot = i;
                     break;
                  	}
               	}
            }
         }
    }

}
