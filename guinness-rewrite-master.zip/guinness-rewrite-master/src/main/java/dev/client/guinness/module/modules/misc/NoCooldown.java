package dev.client.guinness.module.modules.misc;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ClientModule.ModuleCategory;

public class NoCooldown extends ClientModule {
	public NoCooldown() {
		super("NoCooldown", ModuleCategory.MISC);
	}
}
