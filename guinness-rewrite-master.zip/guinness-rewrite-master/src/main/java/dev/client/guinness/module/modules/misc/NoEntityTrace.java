package dev.client.guinness.module.modules.misc;

import dev.client.guinness.module.ClientModule;

public class NoEntityTrace extends ClientModule {
	
	public NoEntityTrace() {
		super("NoEntityTrace", ModuleCategory.MISC);
	}
	
}
