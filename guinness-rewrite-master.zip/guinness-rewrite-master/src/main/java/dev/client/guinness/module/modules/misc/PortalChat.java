package dev.client.guinness.module.modules.misc;

import dev.client.guinness.module.ClientModule;

public class PortalChat extends ClientModule {
	
	public PortalChat() {
		super("PortalChat", ModuleCategory.MISC);
	}

}
