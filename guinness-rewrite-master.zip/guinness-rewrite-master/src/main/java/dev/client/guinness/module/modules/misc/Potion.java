package dev.client.guinness.module.modules.misc;

import java.util.Objects;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SMode;
import net.minecraft.potion.PotionEffect;

public class Potion extends ClientModule {
	
	private SMode mode = new SMode("Mode", "Apply", "Cancel");
	private SBoolean lev = new SBoolean("Levitation", false);
	private SBoolean haste = new SBoolean("Haste", false);
	private SBoolean fat = new SBoolean("Fatigue", false);
	private SBoolean blind = new SBoolean("Blindness", false);
	private SBoolean naus = new SBoolean("Nausea", false);
	private SBoolean nv = new SBoolean("Night Vision", false);
	private SBoolean gl = new SBoolean("Luck", false);
	private SBoolean bl = new SBoolean("Bad Luck", false);
	
	public Potion() {
		super("Potion", ModuleCategory.MISC);
		addSetting(mode);
		addSetting(lev);
		addSetting(haste);
		addSetting(fat);
		addSetting(blind);
		addSetting(naus);
		addSetting(nv);
		addSetting(gl);
		addSetting(bl);
	}
	
	@Override
	public void onUpdate()
	{
		this.setArraylistInfo(this.mode.getValue());
		if(Null()) return;
		
		if(mode.getValue().equalsIgnoreCase("cancel")) {
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("levitation"))) && lev.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("levitation"));
			}
		
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("haste"))) && haste.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("haste"));
			}
		
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("blindness"))) && blind.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("blindness"));
			}
			
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("mining_fatigue"))) && fat.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("mining_mining_fatigue"));
			}
			
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("nausea"))) && naus.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("nausea"));
			}
			
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionById(16))) && nv.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionById(16));
			}
			
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("luck"))) && gl.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("luck"));
			}
			
			if(mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("badluck"))) && bl.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("unluck"));
			}
		}
		
		if(mode.getValue().equalsIgnoreCase("apply")) {
			if(lev.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("levitation"), 200000, 4));
			}
			if(!lev.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("levitation")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("levitation"));
			}
			
			if(haste.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("haste"), 200000, 1));
			}
			if(!haste.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("haste")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("haste"));
			}
			
			if(blind.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("blindness"), 200000, 2));
			}
			if(!blind.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("blindness")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("blindness"));
			}
			
			if(fat.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("mining_fatigue"), 200000, 1));
			}
			if(!fat.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("mining_fatigue")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("mining_fatigue"));
			}
			
			if(naus.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("nausea"), 200000, 1));
			}
			if(!naus.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("nausea")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("nausea"));
			}
			
			if(nv.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionById(16), 200000, 0));
			}
			if(!nv.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("night_vision")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionById(16));
			}
			
			if(gl.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("luck"), 200000, 2));
			}
			if(!gl.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("luck")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("luck"));
			}
			
			if(bl.getValue()) {
				mc.player.addPotionEffect(new PotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("unluck"), 200000, 2));
			}
			if(!bl.getValue() && mc.player.isPotionActive((net.minecraft.potion.Potion)Objects.requireNonNull(net.minecraft.potion.Potion.getPotionFromResourceLocation("unluck")))) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("unluck"));
			}
		}
	}
	
	@Override
	public void onDisable()
	{
		if(mode.getValue().equalsIgnoreCase("apply")) {
			if(lev.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("levitation"));
			}
			if(haste.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("haste"));
			}
			if(blind.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("blindness"));
			}
			
			if(fat.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("mining_fatigue"));
			}
			
			if(naus.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("nausea"));
			}
			
			if(nv.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionById(16));
			}
			
			if(gl.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("luck"));
			}
			
			if(bl.getValue()) {
				mc.player.removeActivePotionEffect(net.minecraft.potion.Potion.getPotionFromResourceLocation("unluck"));
			}
		}
	}
	
	

}
