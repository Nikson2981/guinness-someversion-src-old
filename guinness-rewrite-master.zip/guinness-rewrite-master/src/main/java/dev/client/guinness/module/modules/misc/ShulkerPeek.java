package dev.client.guinness.module.modules.misc;

import java.awt.Color;
import java.util.List;
import java.util.stream.Collectors;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;

public class ShulkerPeek extends ClientModule {
	private static SMode mode = new SMode("Glow Mode", "Always", "32k Only");
	public ShulkerPeek() {
		super("ShulkerPeek", ModuleCategory.MISC);
		addSetting(mode);
	}
	
	public static void renderToolTip(ItemStack itemStack, int x, int y, CallbackInfo ci) {
		NBTTagCompound tagCompound = itemStack.getTagCompound();
        if (tagCompound != null && tagCompound.hasKey("BlockEntityTag", 10)) {
            NBTTagCompound blockEntityTag = tagCompound.getCompoundTag("BlockEntityTag");
            if (blockEntityTag.hasKey("Items", 9)) {
                ci.cancel();

                NonNullList<ItemStack> nonnulllist = NonNullList.withSize(27, ItemStack.EMPTY);
                ItemStackHelper.loadAllItems(blockEntityTag, nonnulllist);
                GlStateManager.enableBlend();
                GlStateManager.disableRescaleNormal();
                RenderHelper.disableStandardItemLighting();
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();

                int x1 = x + 12;
                int y1 = y - 12;
                int height = 57;
                int width = (int) Math.max(144, mc.fontRenderer.getStringWidth(itemStack.getDisplayName())+3);
                mc.getRenderItem().zLevel = 300.0F;
                GuiScreen.drawRect(x1 - 4, y1 - 9, x1 + width + 1, y1 + 4, new Color(0, 0, 0, 144).getRGB());
                GuiScreen.drawRect(x1 - 4, y1 + 5, x1 + width + 1, y1 + height + 3, new Color(0, 0, 0, 144).getRGB());
                
                List<ItemStack> superweapons = nonnulllist.stream().filter(item -> ModuleUtil.is32k(item)).collect(Collectors.toList());
                
                if(mode.getValue().equalsIgnoreCase("Always")) {
	                GuiScreen.drawRect(x1 - 5, y1 - 10, x1 - 6, y1 + height + 5, FinalColor.BESTCOLOR(255, 1));
	                GuiScreen.drawRect(x1 + width + 2, y1 - 11, x1 + width + 3, y1 + height + 5, FinalColor.BESTCOLOR(255, 1));
	                GuiScreen.drawRect(x1 - 6, y1 - 11, x1 + width + 2, y1 - 10, FinalColor.BESTCOLOR(255, 1));
	                GuiScreen.drawRect(x1 - 5, y1 + height + 4, x1 + width + 2, y1 + height + 5, FinalColor.BESTCOLOR(255, 1));
                } else {
                	if(superweapons.size() > 0) {
                		GuiScreen.drawRect(x1 - 5, y1 - 10, x1 - 6, y1 + height + 5, FinalColor.BESTCOLOR(255, 1));
    	                GuiScreen.drawRect(x1 + width + 2, y1 - 11, x1 + width + 3, y1 + height + 5, FinalColor.BESTCOLOR(255, 1));
    	                GuiScreen.drawRect(x1 - 6, y1 - 11, x1 + width + 2, y1 - 10, FinalColor.BESTCOLOR(255, 1));
    	                GuiScreen.drawRect(x1 - 5, y1 + height + 4, x1 + width + 2, y1 + height + 5, FinalColor.BESTCOLOR(255, 1));
                	} else {
                		GuiScreen.drawRect(x1 - 5, y1 - 10, x1 - 6, y1 + height + 5, new Color(0, 0, 0, 144).getRGB());
    	                GuiScreen.drawRect(x1 + width + 2, y1 - 11, x1 + width + 3, y1 + height + 5, new Color(0, 0, 0, 144).getRGB());
    	                GuiScreen.drawRect(x1 - 6, y1 - 11, x1 + width + 2, y1 - 10, new Color(0, 0, 0, 144).getRGB());
    	                GuiScreen.drawRect(x1 - 5, y1 + height + 4, x1 + width + 2, y1 + height + 5, new Color(0, 0, 0, 144).getRGB());
                	}
                }
                
                mc.fontRenderer.drawStringWithShadow(itemStack.getDisplayName(), (x1 + width/2) - (mc.fontRenderer.getStringWidth(itemStack.getDisplayName())/2), y1 - 6, new Color(255, 255, 255).getRGB());

                GlStateManager.enableBlend();
                GlStateManager.enableAlpha();
                GlStateManager.enableTexture2D();
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                RenderHelper.enableGUIStandardItemLighting();

                for (int i = 0; i < nonnulllist.size(); i++) {
                    int iX = x + (i % 9) * 16 + 11;
                    int iY = y + (i / 9) * 16 - 11 + 8;
                    ItemStack stack = nonnulllist.get(i);

                    mc.getRenderItem().renderItemAndEffectIntoGUI(stack, iX, iY);
                    mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, stack, iX, iY, null);
                }
                
                RenderHelper.disableStandardItemLighting();
                mc.getRenderItem().zLevel = 0.0F;

                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                RenderHelper.enableStandardItemLighting();
                GlStateManager.enableRescaleNormal();
            }
        }
	}

}
