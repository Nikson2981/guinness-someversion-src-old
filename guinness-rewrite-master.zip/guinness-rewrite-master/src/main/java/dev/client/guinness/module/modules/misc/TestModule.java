package dev.client.guinness.module.modules.misc;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;

public class TestModule extends ClientModule {
	
	public TestModule() {
		super("TestModule", ModuleCategory.MISC);
	}
	
	@Override
	public void onUpdate() {
		MessageUtil.sendClientMessage("Testing onUpdate()!");
	}

}
