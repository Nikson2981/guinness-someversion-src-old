package dev.client.guinness.module.modules.misc;

import java.util.concurrent.ConcurrentHashMap;

import com.mojang.realmsclient.gui.ChatFormatting;

import dev.client.guinness.event.events.PacketEvent.PacketReceiveEvent;
import dev.client.guinness.event.events.TotemPopEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import dev.client.guinness.setting.settings.SMode;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class TotemPopCounter extends ClientModule {
	private SMode mode = new SMode("Mode", "Client", "Public");
	private SBoolean greentext = new SBoolean("GreenText", false);
	private SBoolean deathOnly = new SBoolean("Public Death", false);
	public TotemPopCounter() {
		super("TotemPopCounter", ModuleCategory.MISC);
		addSetting(mode);
		addSetting(greentext);
		addSetting(deathOnly);
	}
	
	private ConcurrentHashMap<EntityPlayer, Integer> poplist = new ConcurrentHashMap<>();
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		this.setArraylistInfo(mode.getValue());
		if(mc.player.getHealth() <= 0) {
			poplist.clear();
			return;
		}
		
		mc.world.playerEntities.stream()
		.filter(p -> p.getHealth() <= 0)
		.filter(p -> p != mc.player)
		.filter(p -> !FriendUtil.isFriend(p.getName()))
		.filter(p -> poplist.containsKey(p))
		.forEach(p -> {
			if(mode.getValue().equalsIgnoreCase("Client")) {
				MessageUtil.sendClientMessage(ChatFormatting.DARK_AQUA + p.getName() + ChatFormatting.DARK_RED + " died after popping " + ChatFormatting.GOLD + (poplist.get(p) == 1 ? ("" + poplist.get(p) + ChatFormatting.DARK_RED + " totem") : "" + poplist.get(p) + ChatFormatting.DARK_RED + " totems"));
				if(deathOnly.getValue()) {
					if(greentext.getValue()) {
						MessageUtil.sendPublicMessage("> " + p.getName() + " died after popping " + (poplist.get(p) == 1 ? "" + poplist.get(p) + " totem" : "" + poplist.get(p) + " totems"));
					} else {
						MessageUtil.sendPublicMessage(p.getName() + " died after popping " + (poplist.get(p) == 1 ? "" + poplist.get(p) + "" + poplist.get(p) + " totem" : " totems"));
					}
				}
			} else if(mode.getValue().equalsIgnoreCase("Public")) {
				if(greentext.getValue()) {
					MessageUtil.sendPublicMessage("> " + p.getName() + " died after popping " + (poplist.get(p) == 1 ? "" + poplist.get(p) + " totem" : "" + poplist.get(p) + " totems"));
				} else {
					MessageUtil.sendPublicMessage(p.getName() + " died after popping " + (poplist.get(p) == 1 ? "" + poplist.get(p) + "" + poplist.get(p) + " totem" : " totems"));
				}
			}
			poplist.remove(p);
		});
	}
	
	@SubscribeEvent
	public void onPacketReceive(PacketReceiveEvent event) {
		final SPacketEntityStatus[] packet = new SPacketEntityStatus[1];
        final Entity[] entity = new Entity[1];
        if (event.getPacket() instanceof SPacketEntityStatus) {
            packet[0] = (SPacketEntityStatus) event.getPacket();
            if (packet[0].getOpCode() == 35) {
                entity[0] = packet[0].getEntity(mc.world);
                if (!entity[0].getName().equalsIgnoreCase(mc.player.getName())) {
                    MinecraftForge.EVENT_BUS.post(new TotemPopEvent((EntityPlayer) entity[0]));
                }
            }
        }
	}
	
	@SubscribeEvent
	public void onPop(TotemPopEvent event) {
		final int[] pops = {0};
		if(poplist.get(event.getPlayer()) == null) {
			poplist.put(event.getPlayer(), 1);
			if(!event.getPlayer().getName().equalsIgnoreCase(mc.player.getName()) && !FriendUtil.isFriend(event.getPlayer().getName())) {
				if(mode.getValue().equalsIgnoreCase("Client")) {
					MessageUtil.sendClientMessage(ChatFormatting.DARK_AQUA + event.getPlayer().getName() + ChatFormatting.DARK_RED + " popped " + ChatFormatting.GOLD + "1" + ChatFormatting.DARK_RED + " totem");
				} else if(mode.getValue().equalsIgnoreCase("Public")) {
					if(greentext.getValue()) {
						MessageUtil.sendPublicMessage("> " + event.getPlayer().getName() + " popped 1 totem");
					} else {
						MessageUtil.sendPublicMessage(event.getPlayer().getName() + " popped 1 totem");
					}
				}
			}
		} else if(poplist.get(event.getPlayer()) != null) {
			pops[0] = poplist.get(event.getPlayer());
			pops[0]++;
			poplist.put(event.getPlayer(), pops[0]);
			if(!event.getPlayer().getName().equalsIgnoreCase(mc.player.getName()) && !FriendUtil.isFriend(event.getPlayer().getName())) {
				if(mode.getValue().equalsIgnoreCase("Client")) {
					MessageUtil.sendClientMessage(ChatFormatting.DARK_AQUA + event.getPlayer().getName() + ChatFormatting.DARK_RED + " popped " + ChatFormatting.GOLD + pops[0] + ChatFormatting.DARK_RED + " totems");
				} else if(mode.getValue().equalsIgnoreCase("Public")) {
					if(greentext.getValue()) {
						MessageUtil.sendPublicMessage("> " + event.getPlayer().getName() + " popped " + pops[0] + " totems");
					} else {
						MessageUtil.sendPublicMessage(event.getPlayer().getName() + " popped " + pops[0] + " totems");
					}
				}
			}
		}
	}
}
