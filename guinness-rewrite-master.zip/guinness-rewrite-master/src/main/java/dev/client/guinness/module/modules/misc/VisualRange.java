package dev.client.guinness.module.modules.misc;

import java.util.ArrayList;
import java.util.List;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class VisualRange extends ClientModule {
	
	public VisualRange() {
		super("VisualRange", ModuleCategory.MISC);
	}
	
	private List<String> players;
    private List<String> oldPlayers;
    
    @Override
	public void onEnable() {
		players = new ArrayList<>();
		oldPlayers = new ArrayList<>();
	}
    
    @Override
	public void onUpdate() {
		if(Null()) return;
		List<String> newPlayers = new ArrayList<>();
		List<EntityPlayer> playerEntities = mc.world.playerEntities;
		
		for (Entity e : playerEntities) {
			if (e.getName().equals(mc.player.getName())) continue;
			newPlayers.add(e.getName());
		}
		
		if (newPlayers.size() > 0) {
			for (String name : newPlayers) {
				if (!players.contains(name)) {
					MessageUtil.sendClientMessage(name + " has just entered visual range.");
					players.add(name);
				}
			}
		}
		
		if (players.size() > 0) {
            for (String name : players) {
                if (!newPlayers.contains(name)) {
                    oldPlayers.add(name);
                    MessageUtil.sendClientMessage(name + " has just left visual range.");

                }

            }
		}

            if (oldPlayers.size() > 0) {
                for (String name : oldPlayers) {
                    players.remove(name);
                }
                oldPlayers.clear();
            }
	}

}
