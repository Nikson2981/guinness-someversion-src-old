package dev.client.guinness.module.modules.movement;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SInteger;

public class FastFall extends ClientModule {
	private SInteger height = new SInteger("Height", 1, 3, 5);
	public FastFall() {
		super("FastFall", ModuleCategory.MOVEMENT);
		addSetting(height);
	}
	
	@Override
    public void onUpdate() {
    	if (Null())
    	    return;

        if (mc.player.isSneaking())
            return;

        if (mc.player != null && mc.player.onGround && !mc.player.isInWater() && !mc.player.isOnLadder()) {
            for (double y = 0.0; y < height.getValue() + 0.5; y += 0.01) {
                if (!mc.world.getCollisionBoxes(mc.player, mc.player.getEntityBoundingBox().offset(0.0, -y, 0.0)).isEmpty()) {
                    mc.player.motionY = -10.0;
                    break;
                }
            }
        }
    }

}
