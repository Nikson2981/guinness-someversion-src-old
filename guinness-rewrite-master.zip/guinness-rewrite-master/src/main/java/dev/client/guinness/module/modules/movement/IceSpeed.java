package dev.client.guinness.module.modules.movement;

import dev.client.guinness.module.ClientModule;
import net.minecraft.init.Blocks;

public class IceSpeed extends ClientModule {
	
	public IceSpeed() {
		super("IceSpeed", ModuleCategory.MOVEMENT);
	}
	
	public void onUpdate() {
        if (Null()) return;

        Blocks.ICE.slipperiness = 0.42F;
        Blocks.PACKED_ICE.slipperiness = 0.42F;
        Blocks.FROSTED_ICE.slipperiness = 0.42F;
    }

    public void onDisable() {
        Blocks.ICE.slipperiness = 0.98F;
        Blocks.PACKED_ICE.slipperiness = 0.98F;
        Blocks.FROSTED_ICE.slipperiness = 0.98F;
    }

}
