package dev.client.guinness.module.modules.movement;

import dev.client.guinness.event.events.PlayerPushEvent;
import dev.client.guinness.event.events.PushEvent;
import dev.client.guinness.event.events.WaterPushEvent;
import dev.client.guinness.module.ClientModule;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoPush extends ClientModule {
	
	public NoPush() {
		super("NoPush", ModuleCategory.MOVEMENT);
	}
	
	@SubscribeEvent
	public void onPush(PushEvent event) {
		event.setCanceled(true);
	}
	
	@SubscribeEvent
	public void onPushByWater(WaterPushEvent event) {
		event.setCanceled(true);
	}
	
	@SubscribeEvent
	public void onPushByPlayer(PlayerPushEvent event) {
		event.setCanceled(true);
	}

}
