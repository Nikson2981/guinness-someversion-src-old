package dev.client.guinness.module.modules.movement;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ClientModule.ModuleCategory;

public class NoWeb extends ClientModule {
	
	public NoWeb() {
		super("NoWeb", ModuleCategory.MOVEMENT);
	}

}
