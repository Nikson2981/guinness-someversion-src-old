package dev.client.guinness.module.modules.movement;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import dev.client.guinness.util.module.ModuleUtil;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class PearlTP extends ClientModule {
	
	public PearlTP() {
		super("PearlTP", ModuleCategory.MOVEMENT);
	}
	
	@Override
	public void onEnable() {
		if(Null()) return;
		EntityPlayer target = (EntityPlayer) ModuleUtil.getClosestPlayer();
		int pearl = InventoryUtil.findInv(Items.ENDER_PEARL);
		
		if(pearl == -1 || target == null) {
			MessageUtil.sendClientMessage("No pearl, or no one to target!");
			this.disable();
			return;
		}
		float oldyaw = mc.player.rotationYaw;
		float oldpitch = mc.player.rotationPitch;
		mc.player.rotationYaw = ModuleUtil.rotateBedPacket(new BlockPos(mc.player.getPositionVector()), new BlockPos(target.getPositionVector()));
		mc.player.rotationPitch = (mc.player.getDistance(target) / 360);
		if((mc.player.rotationPitch == (mc.player.getDistance(target) / 360) - 20) && mc.player.rotationYaw == ModuleUtil.rotateBedPacket(new BlockPos(mc.player.getPositionVector()), new BlockPos(target.getPositionVector())))
		this.usePearl(pearl);
		//mc.player.rotationYaw = oldyaw;
		//mc.player.rotationPitch = oldpitch;
		this.disable();
		
	}
	
	public void usePearl(int pearlSlot) {
		ItemStack pearl = new ItemStack(Items.ENDER_PEARL);
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, pearlSlot, 0, ClickType.PICKUP, mc.player);
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
		
		mc.playerController.processRightClick(mc.player, mc.world, EnumHand.MAIN_HAND);
		
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 36 + mc.player.inventory.currentItem, 0, ClickType.PICKUP, mc.player);
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, pearlSlot, 0, ClickType.PICKUP, mc.player);
	
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, pearlSlot, 0, ClickType.PICKUP, mc.player);
		
		mc.player.connection.sendPacket(new CPacketClickWindow(0, pearlSlot, 0, ClickType.PICKUP, pearl, (short) 19));
		mc.player.connection.sendPacket(new CPacketClickWindow(0, pearlSlot, 0, ClickType.PICKUP, pearl, (short) 20));
	}

}
