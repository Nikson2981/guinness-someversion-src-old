package dev.client.guinness.module.modules.movement;

import dev.client.guinness.event.events.PacketEvent.PacketReceiveEvent;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SDouble;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Velocity extends ClientModule {
	private SDouble h = new SDouble("Horizontal %", 0.0D, 0.0D, 100.0D, 2);
	private SDouble v = new SDouble("Vertical %", 0.0D, 0.0D, 100.0D, 2);
	public Velocity() {
		super("Velocity", ModuleCategory.MOVEMENT);
		addSetting(h);
		addSetting(v);
	}
	
	@SubscribeEvent
	public void onPacketReceive(PacketReceiveEvent event) {
		if(event.getPacket() instanceof SPacketEntityVelocity) {
			SPacketEntityVelocity packet = (SPacketEntityVelocity) event.getPacket();
			if(h.getValue() + v.getValue() == 0) event.setCanceled(true);;
			packet.motionX = (int) ((packet.motionX / 100) * h.getValue());
			packet.motionZ = (int) ((packet.motionZ / 100) * h.getValue());
			packet.motionY = (int) ((packet.motionY / 100) * v.getValue());
		}
		
		if(event.getPacket() instanceof SPacketExplosion) {
			SPacketExplosion packet = (SPacketExplosion) event.getPacket();
			if(h.getValue() + v.getValue() == 0) event.setCanceled(true);;
			packet.motionX = (int) ((packet.motionX / 100) * h.getValue());
			packet.motionZ = (int) ((packet.motionZ / 100) * h.getValue());
			packet.motionY = (int) ((packet.motionY / 100) * v.getValue());
		}
	}
	
	

}
