package dev.client.guinness.module.modules.render;

import java.awt.Color;

import dev.client.guinness.gui.theme.FinalColor;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.util.render.RenderUtil;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BlockHighlight extends ClientModule {
	
	public BlockHighlight() {
		super("BlockHighlight", ModuleCategory.RENDER);
	}
	
	@SubscribeEvent
	public void onRender(RenderWorldLastEvent event) {
		if(mc.objectMouseOver.getBlockPos() != null) {
			if(!mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getMaterial().isReplaceable()) {
				RenderUtil.drawBoundingBoxBlockPos(mc.objectMouseOver.getBlockPos(), 0, new Color(FinalColor.BESTCOLOR(255, 1)));
			}
		}
	}

}
