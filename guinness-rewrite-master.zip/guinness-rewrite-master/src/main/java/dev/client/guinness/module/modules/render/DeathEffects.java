package dev.client.guinness.module.modules.render;

import java.util.concurrent.ConcurrentHashMap;

import dev.client.guinness.module.ClientModule;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;

public class DeathEffects extends ClientModule {
	private ConcurrentHashMap<EntityPlayer, Boolean> players = new ConcurrentHashMap<>();
	public DeathEffects() {
		super("DeathEffects", ModuleCategory.RENDER);
	}
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		players.clear();
		mc.world.playerEntities.forEach(p -> {
			players.put(p, p.getHealth() <= 0.0F);
			if(players.get(p)) {
				EntityLightningBolt bolt = new EntityLightningBolt(mc.world, p.posX, p.posY, p.posZ, true);
				mc.world.spawnEntity(bolt);
				ResourceLocation rl = new ResourceLocation("minecraft", "entity.lightning.thunder");
				ResourceLocation rl2 = new ResourceLocation("minecraft", "entity.lightning.impact");
				SoundEvent sound = new SoundEvent(rl);
				SoundEvent sound2 = new SoundEvent(rl2);
				mc.world.playSound(mc.player, new BlockPos(p.posX, p.posY, p.posZ), sound, SoundCategory.WEATHER, 1.0F, 1.0F);
				mc.world.playSound(mc.player, new BlockPos(p.posX, p.posY, p.posZ), sound2, SoundCategory.WEATHER, 1.0F, 1.0F);
				mc.world.removeEntity(p);
				players.remove(p);
			}
		});
	}

}
