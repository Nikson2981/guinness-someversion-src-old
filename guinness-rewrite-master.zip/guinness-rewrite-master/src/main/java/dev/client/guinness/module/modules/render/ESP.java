package dev.client.guinness.module.modules.render;

import dev.client.guinness.module.ClientModule;

public class ESP extends ClientModule {
	
	public ESP() {
		super("ESP", ModuleCategory.RENDER);
	}
	
	@Override
	public void onUpdate() {
		if(Null()) return;
		mc.world.playerEntities.stream()
		.forEach(p -> {
			if(!p.isGlowing()) {
				p.setGlowing(true);
			}
		});
	}

}
