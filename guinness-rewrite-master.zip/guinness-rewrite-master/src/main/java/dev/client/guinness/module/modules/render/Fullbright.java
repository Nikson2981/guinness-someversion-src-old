package dev.client.guinness.module.modules.render;

import dev.client.guinness.module.ClientModule;

public class Fullbright extends ClientModule {
	
	public Fullbright() {
		super("Fullbright", ModuleCategory.RENDER);
	}
	
	@Override
	public void onEnable() {
		mc.gameSettings.gammaSetting = 100;
	}
	
	@Override
	public void onDisable() {
		mc.gameSettings.gammaSetting = 10;
	}

}
