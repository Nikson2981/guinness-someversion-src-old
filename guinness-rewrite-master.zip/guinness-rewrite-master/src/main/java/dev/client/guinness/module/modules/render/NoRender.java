package dev.client.guinness.module.modules.render;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SBoolean;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class NoRender extends ClientModule {
	
	public static SBoolean hurtcam = new SBoolean("HurtCam", true);
	public static SBoolean guitint = new SBoolean("Gui Tint", true);
	public static SBoolean portal = new SBoolean("Portal", true);
	public static SBoolean pumpkin = new SBoolean("Pumpkin", true);
	private SBoolean fire = new SBoolean("Fire", true);
	
	public NoRender() {
		super("NoRender", ModuleCategory.RENDER);
		addSetting(hurtcam);
		addSetting(guitint);
		addSetting(portal);
		addSetting(pumpkin);
		addSetting(fire);
	}
	
	@SubscribeEvent
    public void onRenderBlockOverlay (RenderBlockOverlayEvent event) {
        if (fire.getValue() && event.getOverlayType() == RenderBlockOverlayEvent.OverlayType.FIRE)
            event.setCanceled(true);
    }

}
