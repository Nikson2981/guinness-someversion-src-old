package dev.client.guinness.module.modules.render;

import dev.client.guinness.module.ClientModule;
import net.minecraft.network.play.client.CPacketPlayer;

public class NoWeather extends ClientModule {
	
	public NoWeather() {
		super("NoWeather", ModuleCategory.RENDER);
	}
	
	@Override
    public void onUpdate() {
		if(Null()) return;
        if (mc.world.isRaining())
            mc.world.setRainStrength(0);
    }

}
