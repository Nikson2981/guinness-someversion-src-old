package dev.client.guinness.module.modules.render;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SDouble;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SkyColor extends ClientModule {
	private SDouble r = new SDouble("R", 0.0D, 210.0D, 255.0D, 1);
	private SDouble g = new SDouble("G", 0.0D, 210.0D, 255.0D, 1);
	private SDouble b = new SDouble("B", 0.0D, 210.0D, 255.0D, 1);
	public SkyColor() {
		super("SkyColor", ModuleCategory.RENDER);
		addSetting(r);
		addSetting(g);
		addSetting(b);
	}
	
	@SubscribeEvent
	public void colorEvent(final EntityViewRenderEvent.FogColors event) {
		event.setRed((float) (r.getValue() / 255f));
		event.setGreen((float) (g.getValue() / 255f));
		event.setBlue((float) (b.getValue() / 255f));
	}
	
	@SubscribeEvent
	public void fogEvent(final EntityViewRenderEvent.FogDensity event) {
		event.setDensity(0.0f);
		event.setCanceled(true);
	}
	
	

}
