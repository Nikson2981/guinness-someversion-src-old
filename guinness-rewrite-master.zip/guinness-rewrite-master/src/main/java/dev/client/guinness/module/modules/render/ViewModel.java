package dev.client.guinness.module.modules.render;

import dev.client.guinness.module.ClientModule;
import dev.client.guinness.setting.settings.SDouble;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ViewModel extends ClientModule {
	private SDouble fov = new SDouble("FOV", 70.0D, 130.0D, 160.0D, 1);
	public ViewModel() {
		super("ViewModel", ModuleCategory.RENDER);
		addSetting(fov);
	}
	
	@SubscribeEvent
    public void fovModifier(final EntityViewRenderEvent.FOVModifier event) {
            event.setFOV(fov.getValue().floatValue());
    }

}
