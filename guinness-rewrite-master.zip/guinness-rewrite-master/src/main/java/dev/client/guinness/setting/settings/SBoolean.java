package dev.client.guinness.setting.settings;

/**
 * @author bon
 * @since 12/10/20
 */

public class SBoolean extends Setting<Boolean> {

	public SBoolean(String name, boolean value) {
		super(name, value);
	}
	
}
