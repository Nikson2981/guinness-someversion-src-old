package dev.client.guinness.setting.settings;

/**
 * @author bon
 * @since 12/10/20
 */

public class SDouble extends Setting<Double> {

	public SDouble(String name, double min, double value, double max, int scale) {
		super(name, min, value, max, scale);
	}
	
}
