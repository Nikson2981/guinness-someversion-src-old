package dev.client.guinness.setting.settings;

/**
 * @author bon
 * @since 12/10/20
 */

public class SInteger extends Setting<Integer> {

	public SInteger(String name, int min, int value, int max) {
		super(name, min, value, max);
	}
	
}
