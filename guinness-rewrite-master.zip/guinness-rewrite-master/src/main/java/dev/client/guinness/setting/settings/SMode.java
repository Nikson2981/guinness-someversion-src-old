package dev.client.guinness.setting.settings;

/**
 * @author bon
 * @since 12/10/20
 */

public class SMode extends Setting<String> {

	public SMode(String name, String... modes) {
		super(name, modes);
	}
	
}
