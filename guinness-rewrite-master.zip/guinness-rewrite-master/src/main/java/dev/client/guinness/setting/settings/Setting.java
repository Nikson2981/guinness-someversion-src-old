package dev.client.guinness.setting.settings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import dev.client.guinness.setting.subsettings.SubSetting;

/**
 * @author bon
 * @since 12/10/20
 * 
 * TODO Check casts on lines 54 and 93
 */

public class Setting<T> {
	
	private String name;
	private T min;
	private T value;
	private T max;
	private int scale;
	private int modeIndex = 0;
	private List<String> modes;
	private boolean opened = false;
	private List<SubSetting<?>> subsettings = new ArrayList<>();
	
	//Boolean
	public Setting(String name, T value) {
		this.name = name;
		this.value = value;
	}
	
	//Integer
	public Setting(String name, T min, T value, T max) {
		this.name = name;
		this.min = min;
		this.value = value;
		this.max = max;
	}
	
	//Double
	public Setting(String name, T min, T value, T max, int scale) {
		this.name = name;
		this.min = min;
		this.value = value;
		this.max = max;
		this.scale = scale;
	}
	
	//Mode
	public Setting(String name, String... modes) {
		this.name = name;
		this.modes = Arrays.asList(modes);
		this.value = (T) modes[modeIndex]; //I think this cast is ok
	}
	
	//Getters
	public String getName() {
		return this.name;
	}
	
	public T getValue() {
		return this.value;
	}
	
	public T getMinValue() { 
		return this.min; 
	}
	
	public T getMaxValue() { 
		return this.max; 
	}	

	public int getRoundingScale() { 
		return this.scale; 
	}
	
	public int getNextMode() { 
		return this.modeIndex + 1; 
	}
	
	public String getMode(int index) { 
		return this.modes.get(index); 
	}
	
	//Setters
	public void setValue(T value) {
		this.value = value;
	}
	
	public void setMode(int mode) {
		this.modeIndex = mode > this.modes.size() - 1 ? 0 : mode;
		this.setValue((T) this.modes.get(modeIndex));
	}
	
	//Subsetting
	public boolean hasSubSettings() { 
		return this.subsettings.size() > 0; 
	}
	
	public List<SubSetting<?>> getSubSettings() { 
		return this.subsettings; 
	}
	
	public void addSubSetting(SubSetting<?> ss) { 
		this.subsettings.add(ss); 
	}
	
	public SubSetting<?> getSubSettingByName(String name) {
		return this.subsettings.stream()
				.filter(sub -> sub.getName().equalsIgnoreCase(name))
				.findFirst()
				.orElse(null);
	}
	
	//Gui
	public boolean isOpened() { 
		return this.opened; 
	}
	
	public void setOpened(boolean opened) { 
		this.opened = opened;
	}
}
