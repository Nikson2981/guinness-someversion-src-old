package dev.client.guinness.setting.subsettings;

import dev.client.guinness.setting.settings.Setting;

public class SubBoolean extends SubSetting<Boolean> {

	public SubBoolean(Setting<?> parent, String name, boolean value) {
		super(parent, name, value);
	}
	
}
