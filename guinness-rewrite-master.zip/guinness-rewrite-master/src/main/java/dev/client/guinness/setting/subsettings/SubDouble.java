package dev.client.guinness.setting.subsettings;

import dev.client.guinness.setting.settings.Setting;

public class SubDouble extends SubSetting<Double> {

	public SubDouble(Setting<?> parent, String name, double min, double value, double max, int scale) {
		super(parent, name, min, value, max, scale);
	}
	
}
