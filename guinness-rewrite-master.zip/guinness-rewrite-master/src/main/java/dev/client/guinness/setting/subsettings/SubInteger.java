package dev.client.guinness.setting.subsettings;

import dev.client.guinness.setting.settings.Setting;

public class SubInteger extends SubSetting<Integer> {

	public SubInteger(Setting<?> parent, String name, int min, int value, int max) {
		super(parent, name, min, value, max);
	}
	
}
