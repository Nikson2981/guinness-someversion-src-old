package dev.client.guinness.setting.subsettings;

import dev.client.guinness.setting.settings.Setting;

public class SubMode extends SubSetting<String> {

	public SubMode(Setting<?> parent, String name, String... modes) {
		super(parent, name, modes);
	}
	
}
