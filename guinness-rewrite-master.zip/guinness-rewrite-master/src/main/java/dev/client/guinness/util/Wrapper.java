package dev.client.guinness.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;

/**
 * @author bon
 * @since 11/12/20
 */

//Not sure why this is called wrapper but idk what else to call it
public interface Wrapper {
    Minecraft mc = Minecraft.getMinecraft();
}
