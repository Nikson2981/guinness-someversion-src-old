package dev.client.guinness.util.client;

import java.awt.Color;

import dev.client.guinness.module.modules.client.ClickGui;

/**
 * @author bon
 * @since 11/12/20
 */

public final class ColorUtil {
	
	public static int rainbow(long offset, int alpha) {
		float hue = (float) ((((System.currentTimeMillis()*(ClickGui.speed.getValue() / 10)) + (offset * 500)) % (30000L / (ClickGui.difference.getValue()/100))) / (30000.0f / (ClickGui.difference.getValue()/20)));
		int rgb = Color.HSBtoRGB(hue, ClickGui.saturation.getValue().floatValue(), ClickGui.brightness.getValue().floatValue());
		int red = rgb >> 16 & 255;
        int green = rgb >> 8 & 255;
        int blue = rgb & 255;
        int color = toRGBA(red, green, blue, alpha);
		return color;
	}
	
	public static int toRGBA(int r, int g, int b, int a) {
        return (r << 16) + (g << 8) + (b << 0) + (a << 24);
    }
	
}
