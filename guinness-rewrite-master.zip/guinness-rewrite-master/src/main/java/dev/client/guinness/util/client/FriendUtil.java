package dev.client.guinness.util.client;

import java.util.ArrayList;
import java.util.List;

/**
 * @author bon
 * @since 12/05/20
 */

public class FriendUtil {
	
	private static List<String> friends = new ArrayList<String>();

	public static void addFriend(String name) { 
		FriendUtil.friends.add(name.toLowerCase()); 
	}
	
	public static void delFriend(String name) { 
		FriendUtil.friends.remove(name.toLowerCase());
	}
	
	public static boolean isFriend(String name) { 
		return FriendUtil.friends.contains(name.toLowerCase());
	}
	
	public static List<String> getFriends() { 
		return FriendUtil.friends; 
	}
	
}
