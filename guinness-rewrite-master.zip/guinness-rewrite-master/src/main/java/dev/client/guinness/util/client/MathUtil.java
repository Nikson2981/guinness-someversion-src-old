package dev.client.guinness.util.client;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author bon
 * @since 11/14/20
 */

public class MathUtil {

	public static double roundDouble(double number, int scale) {
		BigDecimal bd = new BigDecimal(number);
		bd = bd.setScale(scale, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
	
}
