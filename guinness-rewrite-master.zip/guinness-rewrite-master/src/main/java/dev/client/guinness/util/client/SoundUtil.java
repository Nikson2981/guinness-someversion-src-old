package dev.client.guinness.util.client;

import dev.client.guinness.Guinness;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

public class SoundUtil {
    public static SoundEvent
            GUINNESS_TEXT_BEEPS,
            GUINNESS_UI_ALARM;

    public static void registerSounds() {
        GUINNESS_TEXT_BEEPS = registerSound("text.beeps");
        GUINNESS_UI_ALARM = registerSound("ui.alarm");
    }

    private static SoundEvent registerSound(String name){
        ResourceLocation location = new ResourceLocation(Guinness.MODID, name);
        SoundEvent event = new SoundEvent(location);
        event.setRegistryName(name);
        ForgeRegistries.SOUND_EVENTS.register(event);
        return event;
    }
}
