package dev.client.guinness.util.config;

import dev.client.guinness.Guinness;
import net.minecraftforge.common.config.Config;
import net.minecraftforge.common.config.ConfigManager;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * @author bon
 * @since 12/03/20
 */

@Config(modid = Guinness.MODID)
@Config.LangKey("Guinness.config.title")
public class ConfigUtil {

	public static boolean ExampleBoolean = true;
	
	@Mod.EventBusSubscriber
	private static class EventHandler {
		@SubscribeEvent
		public static void configChanged(final ConfigChangedEvent.OnConfigChangedEvent event) {
			if(event.getModID().equals(Guinness.MODID)) {
				ConfigManager.sync(Guinness.MODID, Config.Type.INSTANCE);
			}
		}
	}
	
}
