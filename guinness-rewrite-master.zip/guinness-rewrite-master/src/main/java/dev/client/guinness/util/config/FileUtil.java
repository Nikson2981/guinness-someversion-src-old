package dev.client.guinness.util.config;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.util.List;

import dev.client.guinness.gui.main.Window;
import dev.client.guinness.module.ClientModule;
import dev.client.guinness.module.ModuleManager;
import dev.client.guinness.setting.settings.*;
import dev.client.guinness.setting.subsettings.*;
import dev.client.guinness.util.client.FriendUtil;
import dev.client.guinness.util.client.MessageUtil;
import dev.client.guinness.util.module.InventoryUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;

/**
 * @author bon
 * @since 12/05/20
 */

public class FileUtil {

	private static File custombase;
	
	public static void loadAll() {
		FileUtil.loadGui();
		FileUtil.loadBinds();
		FileUtil.loadFriends();
		FileUtil.loadSettings();
		FileUtil.loadSubSettings();
		FileUtil.loadActiveModules();
	}
	
	public static void saveAll() {
		FileUtil.saveGui();
		FileUtil.saveBinds();
		FileUtil.saveFriends();
		FileUtil.saveSettings();
		FileUtil.saveSubSettings();
		FileUtil.saveActiveModules();
	}
	
	public static void createDirectory() {
		FileUtil.custombase = new File("GuinnessClient");
		if(!FileUtil.custombase.exists()) custombase.mkdirs();
	}
	
	public static void saveGui() {
		try {
			File guiPos = new File(FileUtil.custombase.getAbsolutePath(), "ClickGui.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(guiPos));
			for(Window w : Window.windows) {
				bw.write(w.getName() + ":" + "x:" + w.x + ":" + "y:" + w.y);
				bw.write("\r\n");
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace();; }
	}
	
	public static void loadGui() {
		try {
			File guiPos = new File(FileUtil.custombase.getAbsolutePath(), "ClickGui.txt");
			BufferedReader br = new BufferedReader(new FileReader(guiPos));
			List<String> linezz = Files.readAllLines(guiPos.toPath());
			for(String line : linezz) {
				String[] regex = line.split(":");
				for(Window w : Window.windows) {
					if(w.getName().equalsIgnoreCase(regex[0])) {
						w.x = Integer.parseInt(regex[2]);
						w.y = Integer.parseInt(regex[4]);
					}
				}
			}
			br.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void saveSettings() {
		try {
			File settings = new File(FileUtil.custombase.getAbsolutePath(), "Settings.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(settings));
			for(ClientModule m : ModuleManager.getModules()) {
				bw.write(m.getName() + ":");
				for(Setting<?> s : m.getSettings()) {
					bw.write(s.getName() + "-" + s.getValue() + ":");
				}
				bw.write("\r\n");
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace(); }
	}

	public static void loadSettings() {
		try {
			File settings = new File(FileUtil.custombase.getAbsolutePath(), "Settings.txt");
			BufferedReader br = new BufferedReader(new FileReader(settings));
			List<String> linezz = Files.readAllLines(settings.toPath());
			for(String line : linezz) {
				String[] regex = line.split(":");
				ClientModule m = ModuleManager.getModuleByName(regex[0]);
				for(int i = 1; i < regex.length; i++) {
					String term = regex[i];
					//A pair, of a setting name and its value
					String[] pair = term.split("-");
					Setting<?> s = m.getSettingByName(pair[0]);
					if(s instanceof SBoolean) {
						SBoolean sb = (SBoolean) s;
						sb.setValue(Boolean.parseBoolean(pair[1]));
					}
					if(s instanceof SInteger) { 
						SInteger si = (SInteger) s;
						si.setValue(Integer.parseInt(pair[1]));
					}
					if(s instanceof SDouble) {
						SDouble sd = (SDouble) s;
						sd.setValue(Double.parseDouble(pair[1]));
					}
					if(s instanceof SMode) {
						SMode sm = (SMode) s;
						sm.setValue(pair[1]); 
					}
				}
			}
			br.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void saveSubSettings() {
		try {
			File subsettings = new File(FileUtil.custombase.getAbsolutePath(), "SubSettings.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(subsettings));
			for(ClientModule m : ModuleManager.getModules()) {
				if(m.hasSettings()) {
					for(Setting<?> s : m.getSettings()) {
						if(s.hasSubSettings()) {
							for(SubSetting<?> ss : s.getSubSettings()) {
								bw.write(m.getName() + ":" + s.getName() + ":" + ss.getName() + "-" + ss.getValue() + ":");
								bw.write("\r\n");
							}
						}
					}
				}
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void loadSubSettings() {
		try {
			File subsettings = new File(FileUtil.custombase.getAbsolutePath(), "SubSettings.txt");
			BufferedReader br = new BufferedReader(new FileReader(subsettings));
			List<String> linezz = Files.readAllLines(subsettings.toPath());
			for(String line : linezz) {
				String[] regex = line.split(":");
				ClientModule m = ModuleManager.getModuleByName(regex[0]);
				Setting<?> s = m.getSettingByName(regex[1]);
				for(int i = 2; i < regex.length; i++) {
					String term = regex[i];
					String[] pair = term.split("-");
					SubSetting<?> ss = s.getSubSettingByName(pair[0]);
					if(ss instanceof SubBoolean) {
						SubBoolean sb = (SubBoolean) ss;
						sb.setValue(Boolean.parseBoolean(pair[1]));
					}
					if(ss instanceof SubInteger) {
						SubInteger si = (SubInteger) ss;
						si.setValue(Integer.parseInt(pair[1]));
					}
					if(ss instanceof SubDouble) {
						SubDouble sd = (SubDouble) ss;
						sd.setValue(Double.parseDouble(pair[1]));
					}
					if(ss instanceof SubMode) {
						SubMode sm = (SubMode) ss;
						sm.setValue(pair[1]);
					}
				}
			}
			br.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void saveActiveModules() {
		try {
			File modules = new File(FileUtil.custombase.getAbsolutePath(), "ActiveModules.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(modules));
			for(ClientModule m : ModuleManager.getModules()) {
				bw.write(m.getName() + ":");
				if(m.isEnabled()) {
					bw.write("true");
				} else {
					bw.write("false");
				}
				bw.write("\r\n");
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void loadActiveModules() {
		try {
			File modules = new File(FileUtil.custombase.getAbsolutePath(), "ActiveModules.txt");
			BufferedReader br = new BufferedReader(new FileReader(modules));
			List<String> linezz = Files.readAllLines(modules.toPath());
			for(String line : linezz) {
				String[] regex = line.split(":");
				ClientModule m = ModuleManager.getModuleByName(regex[0]);
				if(Boolean.parseBoolean(regex[1])) {
					m.enable();
				}
			}
			br.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void saveFriends() {
		try {
			File friends = new File(FileUtil.custombase.getAbsolutePath(), "Friends.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(friends));
			for(String s : FriendUtil.getFriends()) {
				bw.write(s);
				bw.write("\r\n");
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void loadFriends() {
		try {
			File friends = new File(FileUtil.custombase.getAbsolutePath(), "Friends.txt");
			BufferedReader br = new BufferedReader(new FileReader(friends));
			List<String> linezz = Files.readAllLines(friends.toPath());
			for(String line : linezz) {
				FriendUtil.addFriend(line);
			}
			br.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void saveBinds() {
		try {
			File binds = new File(FileUtil.custombase.getAbsolutePath(), "Keybinds.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(binds));
			for(ClientModule m : ModuleManager.getModules()) {
				bw.write(m.getName() + ":" + m.getKeybind().getKeyCode());
				bw.write("\r\n");
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void loadBinds() {
		try {
			File binds = new File(FileUtil.custombase.getAbsolutePath(), "Keybinds.txt");
			BufferedReader br = new BufferedReader(new FileReader(binds));
			List<String> linezz = Files.readAllLines(binds.toPath());
			for(String line : linezz) {
				String[] regex = line.split(":");
				ClientModule m = ModuleManager.getModuleByName(regex[0]);
				m.getKeybind().setKeyCode(Integer.parseInt(regex[1]));
			}
			br.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void saveKit() {
		try {
			File kit = new File(FileUtil.custombase.getAbsolutePath(), "Kit.txt");
			BufferedWriter bw = new BufferedWriter(new FileWriter(kit));
			for(int i = 0; i < 37; i++) {
				bw.write(i + ":" + Minecraft.getMinecraft().player.inventory.getStackInSlot(i).getUnlocalizedName());
				bw.write("\r\n");
			}
			bw.close();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	public static void loadKit() {
		try {
			File kit = new File(FileUtil.custombase.getAbsolutePath(), "Kit.txt");
			BufferedReader br = new BufferedReader(new FileReader(kit));
			List<String> linezz = Files.readAllLines(kit.toPath());
			br.close();
			for(String line : linezz) {
				String[] regex = line.split(":");
				if(regex[0].equalsIgnoreCase("tile.air")) continue;
				for(int i = 0; i < 37; i++) {
					if(Minecraft.getMinecraft().player.inventory.getStackInSlot(i).getUnlocalizedName().equalsIgnoreCase(regex[1])) {
						InventoryUtil.swapSlots(i, Integer.parseInt(regex[0]));
						MessageUtil.sendClientMessage("Swapping from slot " + i + " to " + regex[0]);
						break;
					}
				}
			}
		} catch (Exception e) { e.printStackTrace(); }
	}

}
