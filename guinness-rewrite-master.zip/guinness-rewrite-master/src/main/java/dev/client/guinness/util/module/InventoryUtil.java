package dev.client.guinness.util.module;

import java.util.Arrays;
import java.util.List;

import dev.client.guinness.util.Wrapper;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class InventoryUtil implements Wrapper {

	public static final List<Block> shulkers;
	public static final List<Item> helmets, chestPlates, leggings, boots;
	
	public static int find(Item item) {
		for(int i = 0; i < 9; i++) {
			ItemStack is = mc.player.inventory.getStackInSlot(i);
			if (is == ItemStack.EMPTY) continue;
			Item it = is.getItem();
			if(it.equals(item)) {
				return i;
			}
		}
		return -1;
	}
	
	public static int findInv(Item item) {
		for(int i = 0; i < 36; i++) {
			final Item slot = mc.player.inventory.getStackInSlot(i).getItem();
			if(slot.equals(item)) {
				if(i < 9) {
					i += 36;
				}
				return i;
			}
		}
		return -1;
	}
	
	public static int find(Block block) {
		for(int i = 0; i < 9; i++) {
			ItemStack is = mc.player.inventory.getStackInSlot(i);
			if (is == ItemStack.EMPTY) continue;
			Item it = is.getItem();
			if(it instanceof ItemBlock && ((ItemBlock) it).getBlock().equals(block)) {
				return i;
			}
		}
		return -1;
	}


	public static void swapSlots(int slot1, int slot2) {
		mc.playerController.windowClick(mc.player.inventoryContainer.windowId, slot1, slot2, ClickType.SWAP, mc.player);
	}
	
	static {
		shulkers = Arrays.asList(
		Blocks.BLACK_SHULKER_BOX,
		Blocks.BLUE_SHULKER_BOX,
		Blocks.BROWN_SHULKER_BOX,
		Blocks.CYAN_SHULKER_BOX,
		Blocks.GRAY_SHULKER_BOX,
		Blocks.GREEN_SHULKER_BOX,
		Blocks.LIGHT_BLUE_SHULKER_BOX,
		Blocks.LIME_SHULKER_BOX,
		Blocks.MAGENTA_SHULKER_BOX,
		Blocks.ORANGE_SHULKER_BOX,
		Blocks.PINK_SHULKER_BOX,
		Blocks.PURPLE_SHULKER_BOX,
		Blocks.RED_SHULKER_BOX,
		Blocks.SILVER_SHULKER_BOX,
		Blocks.WHITE_SHULKER_BOX,
		Blocks.YELLOW_SHULKER_BOX);

		helmets = Arrays.asList(Items.LEATHER_HELMET, Items.GOLDEN_HELMET, Items.IRON_HELMET, Items.CHAINMAIL_HELMET, Items.DIAMOND_HELMET);

		chestPlates = Arrays.asList(Items.LEATHER_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.IRON_CHESTPLATE, Items.CHAINMAIL_CHESTPLATE, Items.DIAMOND_CHESTPLATE);

		leggings = Arrays.asList(Items.LEATHER_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.IRON_LEGGINGS, Items.CHAINMAIL_LEGGINGS, Items.DIAMOND_LEGGINGS);

		boots = Arrays.asList(Items.LEATHER_BOOTS, Items.GOLDEN_BOOTS, Items.IRON_BOOTS, Items.CHAINMAIL_BOOTS, Items.DIAMOND_BOOTS);

	}


}
