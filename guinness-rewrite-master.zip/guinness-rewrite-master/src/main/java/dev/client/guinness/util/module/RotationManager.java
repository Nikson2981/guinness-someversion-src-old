package dev.client.guinness.util.module;

import dev.client.guinness.util.Wrapper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.MathHelper;

public class RotationManager implements Wrapper {


    public static float[] RotateClient(double x, double y, double z) {
        double diffX = (x + 0.5) - mc.player.posX;
        double diffY = (y + 0.5) - (mc.player.posY + (double) mc.player.getEyeHeight());
        double diffZ = (z + 0.5) - mc.player.posZ;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));

        return new float[]{
                mc.player.rotationYaw += MathHelper.wrapDegrees(yaw - mc.player.rotationYaw),
                mc.player.rotationPitch += MathHelper.wrapDegrees(pitch - mc.player.rotationPitch)
        };

    }

    public static double[] calculateLookAt(final double px, final double py, final double pz, final EntityPlayer me) {
        double dirx = me.posX - px;
        double diry = me.posY - py;
        double dirz = me.posZ - pz;
        final double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
        dirx /= len;
        diry /= len;
        dirz /= len;
        double pitch = Math.asin(diry);
        double yaw = Math.atan2(dirz, dirx);
        pitch *= 180.0 / Math.PI;
        yaw *= 180.0 / Math.PI;
        yaw += 90.0;
        return new double[]{yaw, pitch};
    }

    public static double[] calculateLookAt(final EntityPlayer target, final EntityPlayer me) {
        double dirx = me.posX - target.posX;
        double diry = me.posY - target.posY;
        double dirz = me.posZ - target.posZ;
        final double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
        dirx /= len;
        diry /= len;
        dirz /= len;
        double pitch = Math.asin(diry);
        double yaw = Math.atan2(dirz, dirx);
        pitch = pitch * 180.0 / 3.141592653589793;
        yaw = yaw * 180.0 / 3.141592653589793;
        yaw += 90.0;
        return new double[]{yaw, pitch};
    }
}
