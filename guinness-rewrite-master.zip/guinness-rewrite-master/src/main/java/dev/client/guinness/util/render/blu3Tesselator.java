package dev.client.guinness.util.render;

import dev.client.guinness.Guinness;
import dev.client.guinness.util.client.Vec2i;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

import static dev.client.guinness.util.Wrapper.mc;

public class blu3Tesselator {

    public static void drawPolygonWithCustomSizedTexture(Vec2i topLeft, Vec2i topRight, Vec2i bottomLeft, Vec2i bottomRight, float textureWidth, float textureHeight) {
        float f = 1.0F / textureWidth;
        float f1 = 1.0F / textureHeight;

        int leftHeight = bottomLeft.getY() - topLeft.getY();
        int rightHeight = bottomRight.getY() - topRight.getY();
        int bottomWidth = bottomRight.getX() - bottomLeft.getX();
        int topWidth = topRight.getX() - topLeft.getX();

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);

        bufferbuilder.pos(bottomLeft.getX(), bottomLeft.getY(), 0.0D).tex(f, (1 + leftHeight) * f1).endVertex(); // bottom left
        bufferbuilder.pos(bottomRight.getX(), bottomRight.getY(), 0.0D).tex((1 + bottomWidth) * f, (1 + rightHeight) * f1).endVertex(); // bottom right
        bufferbuilder.pos(topRight.getX(), topRight.getY(), 0.0D).tex((1 + topWidth) * f, f1).endVertex(); // top right
        bufferbuilder.pos(topLeft.getX(), topLeft.getY(), 0.0D).tex(f, f1).endVertex(); // top left
        tessellator.draw();
    }


    //drawPolygonWithCustomSizedTexture(new TesselatorVec2i(1, 1), new TesselatorVec2i(200, 20), new TesselatorVec2i(10, 200), new TesselatorVec2i(300, 300), 200, 200);

    //blu3Tesselator.drawPolygon(new TesselatorVec2i(,), new TesselatorVec2i(,), new TesselatorVec2i(,), new TesselatorVec2i(,), ColorUtil.rainbow(1, 255));

    public static void drawPolygon(Vec2i topLeft, Vec2i topRight, Vec2i bottomLeft, Vec2i bottomRight, int color) {
        float f3 = (float) (color >> 24 & 255) / 255.0F;
        float f = (float) (color >> 16 & 255) / 255.0F;
        float f1 = (float) (color >> 8 & 255) / 255.0F;
        float f2 = (float) (color & 255) / 255.0F;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        glSetup();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(f, f1, f2, f3);

        bufferbuilder.begin(7, DefaultVertexFormats.POSITION);
        bufferbuilder.pos(bottomLeft.getX(), bottomLeft.getY(), 0.0D).endVertex(); // bottom left
        bufferbuilder.pos(bottomRight.getX(), bottomRight.getY(), 0.0D).endVertex(); // bottom right
        bufferbuilder.pos(topRight.getX(), topRight.getY(), 0.0D).endVertex(); // top right
        bufferbuilder.pos(topLeft.getX(), topLeft.getY(), 0.0D).endVertex(); // top left

        tessellator.draw();
        glCleanup();
    }

    public static void glSetup() {
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
    }

    public static void glCleanup() {
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
}
